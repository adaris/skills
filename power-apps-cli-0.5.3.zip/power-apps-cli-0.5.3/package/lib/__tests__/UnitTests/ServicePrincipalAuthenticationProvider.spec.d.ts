/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export {};
//# sourceMappingURL=ServicePrincipalAuthenticationProvider.spec.d.ts.map
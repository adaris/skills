/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { jest } from '@jest/globals';
/**
 * Utility for silencing console output in specific test files
 */
export interface ConsoleMocks {
    log: jest.MockedFunction<typeof console.log>;
    error: jest.MockedFunction<typeof console.error>;
    warn: jest.MockedFunction<typeof console.warn>;
    info: jest.MockedFunction<typeof console.info>;
}
export interface OriginalConsoleMethods {
    log: typeof console.log;
    error: typeof console.error;
    warn: typeof console.warn;
    info: typeof console.info;
}
/**
 * Silences console output for the current test file
 * Call this in beforeEach or beforeAll
 */
export declare function silenceConsole(): {
    mocks: ConsoleMocks;
    restore: () => void;
};
/**
 * Higher-order function that silences console for specific methods only
 * example usage:
 * const { mocks, restore } = silenceSpecificConsole(['error', 'warn']);
 */
export declare function silenceSpecificConsole(methods: Array<'log' | 'error' | 'warn' | 'info'>): {
    mocks: Partial<ConsoleMocks>;
    restore: () => void;
};
/**
 * Utility function to assert multiple lines of console output
 *
 * @param {(jest.MockedFunction<
 *     typeof console.log | typeof console.error | typeof console.warn | typeof console.info
 *   >)} mockFn
 * @param {string[]} expectedOutputLines Lines expected to be logged
 */
export declare function expectConsoleSequence(mockFn: jest.MockedFunction<typeof console.log | typeof console.error | typeof console.warn | typeof console.info>, expectedOutputLines: string[]): void;
//# sourceMappingURL=silentConsole.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function logoutAsync(argumentProvider: ArgumentProvider): Promise<void>;

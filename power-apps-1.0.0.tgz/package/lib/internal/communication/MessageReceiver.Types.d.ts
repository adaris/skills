/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IncompatibleMessageReceiver } from './IncompatibleMessageReceiver';
import { CompatibleMessageReceiver } from './CompatibleMessageReceiver';
export type MessageReceiver = CompatibleMessageReceiver | IncompatibleMessageReceiver;
export type CompatibilityCheckerResult = {
    isCompatible: boolean;
    incompatibilityDescription?: string;
};
export interface SendMessagePlugin {
    getMessageReceiverAsync(receiverName: string, isCompatibleChecker: (versionInfo: string) => CompatibilityCheckerResult): Promise<MessageReceiver>;
}
export type CompatibleReceiverMessage = {
    isUpdate: boolean;
    message: string;
};
//# sourceMappingURL=MessageReceiver.Types.d.ts.map
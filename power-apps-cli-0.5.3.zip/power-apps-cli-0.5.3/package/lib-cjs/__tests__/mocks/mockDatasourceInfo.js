"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 * This file is auto-generated. Do not modify it manually.
 * Changes to this file may be overwritten.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.dataSourcesInfo = void 0;
exports.dataSourcesInfo = {
    contacts: {
        tableId: 'contact',
        version: '',
        primaryKey: 'contactid',
        dataSourceType: 'Connector',
        apis: {},
    },
    translatorv2: {
        tableId: '',
        version: '',
        primaryKey: '',
        dataSourceType: 'Connector',
        apis: {
            Languages: {
                path: '/{connectionId}/Languages',
                method: 'GET',
                parameters: [
                    {
                        name: 'connectionId',
                        in: 'path',
                        required: true,
                        type: 'string',
                        default: null,
                    },
                    {
                        name: 'scope',
                        in: 'query',
                        required: false,
                        type: 'string',
                        default: 'translation',
                    },
                ],
                responseInfo: {
                    '200': {
                        type: 'array',
                        format: null,
                    },
                },
            },
            Translate: {
                path: '/{connectionId}/Translate',
                method: 'POST',
                parameters: [
                    {
                        name: 'connectionId',
                        in: 'path',
                        required: true,
                        type: 'string',
                        default: null,
                    },
                    {
                        name: 'to',
                        in: 'query',
                        required: true,
                        type: 'string',
                        default: null,
                    },
                    {
                        name: 'body',
                        in: 'body',
                        required: true,
                        type: 'object',
                        default: null,
                    },
                    {
                        name: 'from',
                        in: 'query',
                        required: false,
                        type: 'string',
                        default: null,
                    },
                    {
                        name: 'category',
                        in: 'query',
                        required: false,
                        type: 'string',
                        default: null,
                    },
                    {
                        name: 'textType',
                        in: 'query',
                        required: false,
                        type: 'string',
                        default: null,
                    },
                ],
                responseInfo: {
                    '200': {
                        type: 'string',
                        format: null,
                    },
                },
            },
            Detect: {
                path: '/{connectionId}/Detect',
                method: 'POST',
                parameters: [
                    {
                        name: 'connectionId',
                        in: 'path',
                        required: true,
                        type: 'string',
                        default: null,
                    },
                    {
                        name: 'body',
                        in: 'body',
                        required: true,
                        type: 'object',
                        default: null,
                    },
                ],
                responseInfo: {
                    '200': {
                        type: 'object',
                        format: null,
                    },
                },
            },
        },
    },
    paruntimedb: {
        tableId: '',
        version: 'v2',
        primaryKey: '',
        dataSourceType: 'Connector',
        apis: {
            GetRecordById: {
                path: '/dbo.GetRecordById',
                method: 'POST',
                parameters: [
                    {
                        name: 'tinyint_col',
                        in: 'body',
                        required: false,
                        type: 'integer',
                        default: null,
                    },
                ],
                responseInfo: {},
            },
        },
    },
};
//# sourceMappingURL=mockDatasourceInfo.js.map
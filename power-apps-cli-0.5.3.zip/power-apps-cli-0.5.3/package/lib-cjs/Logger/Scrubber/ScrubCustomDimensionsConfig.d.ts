/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export type ScrubConfig = {
    scrubberName: string;
    shouldScrubValue: (value: string) => boolean;
};
export type ScrubConfigList = ScrubConfig[];
export type EventConfig = {
    /** When assigned, this will apply the given scrub config list if the event_Name matches */
    ['*']?: ScrubConfigList;
    /**
     * This configuration is a mapping of Record<operation_Name, ScrubConfigList>
     * When assigned, any event that matches the event_Name and operation_Name will be scrubbed
     */
    operations?: Record<string, ScrubConfigList>;
    /**
     * This configuration is a mapping of Record<scenarioName, ScrubConfigList>
     * When assigned, any event that matches the event_Name and scenarioName will be scrubbed
     */
    scenarios?: Record<string, ScrubConfigList>;
};
/**
 * This configuration is a mapping of Record<event_Name, EventConfig>
 */
export declare const EventsToScrubConfig: Record<string, EventConfig>;

/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IPowerOperationExecutor } from '../types';
/**
 * Initializes the PowerDataRuntime with the provided executor.
 * This function should be called once at the start of the application.
 * @param executor - The executor to be used for operations.
 * @throws Will throw an error if the executor is already initialized.
 */
export declare function initializeRuntime(executor: IPowerOperationExecutor): void;
export declare function getExecutor(): IPowerOperationExecutor;
//# sourceMappingURL=initializeRuntime.d.ts.map
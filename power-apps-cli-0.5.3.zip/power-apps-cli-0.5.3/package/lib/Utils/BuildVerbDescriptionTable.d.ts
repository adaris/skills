/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
/**
 * Formats the verb registry into a table for help output.
 * Uses simple text-based table formatting suitable for terminal display.
 */
export declare function buildVerbDescriptionTable(): string;
//# sourceMappingURL=BuildVerbDescriptionTable.d.ts.map
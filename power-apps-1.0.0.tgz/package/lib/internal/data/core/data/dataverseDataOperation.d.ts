/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IRuntimeClientProvider, IXrmContext } from '../common/types';
import { IDataOperation, IDataSourceInfo, IOperationResult } from '../types';
import { RuntimeDataSourceService } from '../metadata/runtimeDataSourceService';
export declare const ODATA_CONTEXT = "@odata.context";
export declare const ODATA_NEXT_LINK = "@odata.nextLink";
export declare const CRM_TOTAL_RECORD_COUNT = "@Microsoft.Dynamics.CRM.totalrecordcount";
export declare const CRM_TOTAL_RECORD_COUNT_LIMIT_EXCEEDED = "@Microsoft.Dynamics.CRM.totalrecordcountlimitexceeded";
export declare const CRM_GLOBAL_METADATA_VERSION = "@Microsoft.Dynamics.CRM.globalmetadataversion";
/**
 * DataverseDataOperation provides functionality for performing CRUD operations
 * against the Dataverse data source using the XRM WebApi or runtime metadata client.
 */
export declare class DataverseDataOperation {
    private readonly _xrm;
    private readonly _dataverseDataSourceService;
    private readonly _clientProvider;
    private _databaseReferences;
    constructor(xrm: IXrmContext, dataverseDataSourceService: RuntimeDataSourceService, clientProvider: IRuntimeClientProvider);
    /**
     * Creates a new record in Dataverse
     * @param tableName - The name of the table
     * @param data - The record data to create
     * @returns Promise resolving to operation result
     */
    createRecordAsync<TRequest, TResponse>(tableName: string, data: TRequest): Promise<IOperationResult<TResponse>>;
    /**
     * Updates an existing record in Dataverse
     * @param tableName - The name of the table
     * @param id - The record identifier
     * @param data - The updated record data
     * @returns Promise resolving to operation result
     */
    updateRecordAsync<TRequest, TResponse>(tableName: string, id: string, data: TRequest): Promise<IOperationResult<TResponse>>;
    /**
     * Deletes a record from Dataverse
     * @param tableName - The name of the table
     * @param id - The record identifier
     * @returns Promise resolving to operation result
     */
    deleteRecordAsync(tableName: string, id: string): Promise<IOperationResult<void>>;
    /**
     * Retrieves a single record from Dataverse
     * @param tableName - The name of the table
     * @param id - The record identifier
     * @param options - The retrieval options
     * @returns Promise resolving to operation result
     */
    retrieveRecordAsync<TResponse>(tableName: string, id: string, options: string, maxPageSize?: number): Promise<IOperationResult<TResponse>>;
    /**
     * Retrieves multiple records from Dataverse
     * @param tableName - The name of the table
     * @param options - The retrieval options
     * @param maxPageSize - Optional maximum page size
     * @returns Promise resolving to operation result
     */
    retrieveMultipleRecordsAsync<TResponse>(tableName: string, options: string, maxPageSize?: number): Promise<IOperationResult<TResponse[]>>;
    /**
     * Executes a custom Dataverse operation
     * @param operation - The operation to execute
     * @returns Promise resolving to operation result
     */
    executeAsync<TRequest, TResponse>(operation: IDataOperation<TRequest>): Promise<IOperationResult<TResponse>>;
    /**
     * Returns the database references for Dataverse, grouped by environment/database.
     * These come from the launch app response via runtime metadata client.
     */
    getDatabaseReferences(): Promise<DatabaseReferences>;
    /**
     * Loads database references from runtime metadata client (launch app response).
     */
    private _loadDatabaseReferencesFromRuntime;
    private _extractInstanceUrlFromRuntimeUrl;
    /**
     * Validates operation parameters
     * @param params - The parameters to validate
     * @throws Error if validation fails
     */
    private _validateParams;
    /**
     * Creates a success result object
     * @param data - The response data
     * @param totalCount - Optional total count for multiple record operations
     * @returns IDataOperationResult with success status
     */
    private _createSuccessResult;
    /**
     * Helper to check if XRM context is present and valid
     */
    private _hasCrm;
    /**
     * Helper to get a native data client and database reference
     */
    private _getDataClient;
    /**
     * Gets the metadata client instance
     */
    private _getMetadataClient;
    /**
     * Template method for connector-style CRUD operations to reduce duplication.
     * Handles client, dataSourceInfo, requestUrl, and error handling.
     */
    private _executeNativeDataverseOperation;
    /**
     * Helper to get the Dataverse datasourceinfo from databaseReferences
     */
    private _getDataverseDataSourceInfo;
    /**
     * Helper to construct the Dataverse API URL using instanceUrl if available, otherwise fallback to runtimeUrl.
     */
    private _getDataverseRequestUrl;
}
export interface ILinkedEnvironmentMetadata {
    resourceId: string;
    friendlyName: string;
    uniqueName: string;
    domainName: string;
    version: string;
    instanceUrl: string;
    instanceApiUrl: string;
    baseLanguage: number;
    instanceState: string;
    createdTime: string;
    platformSku: string;
}
export interface DataverseDataSourceInfo extends IDataSourceInfo {
    datasetName: string;
    referenceType?: string;
    linkedEnvironmentMetadata?: ILinkedEnvironmentMetadata;
    entitySetName?: string;
    logicalName?: string;
    isHidden?: boolean;
}
interface IDatabaseReference {
    databaseDetails: {
        referenceType: string;
        environmentName: string;
        overrideValues: {
            status: string;
            environmentVariableName: string;
        };
        linkedEnvironmentMetadata?: ILinkedEnvironmentMetadata;
    };
    dataSources: {
        [dataSourceName: string]: {
            entitySetName: string;
            logicalName: string;
            isHidden: boolean;
        };
    };
}
/**
 * Extracts the skip token from the next link URL.
 * @param nextLink - The @odata.nextLink URL containing the skip token
 * @returns The extracted skip token or undefined if not found.
 */
export declare function extractSkipToken(nextLink: string | undefined): string | undefined;
export type DatabaseReferences = {
    [key: string]: IDatabaseReference;
};
export {};
//# sourceMappingURL=dataverseDataOperation.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export {};
//# sourceMappingURL=dataverseDataOperation.spec.d.ts.map
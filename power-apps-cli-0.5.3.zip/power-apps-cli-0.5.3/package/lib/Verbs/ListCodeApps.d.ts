/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function getCodeAppsAsync(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=ListCodeApps.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArgumentProvider = void 0;
var commander_1 = require("commander");
var prompts_1 = require("@clack/prompts");
var powerapps_player_services_1 = require("@pa-client/powerapps-player-services");
var CliUtils_1 = require("./CliUtils");
var CliSettings_1 = require("./CliSettings");
var HelpStrings_1 = require("./Constants/HelpStrings");
var BuildVerbDescriptionTable_1 = require("./Utils/BuildVerbDescriptionTable");
// eslint-disable-next-line @typescript-eslint/no-require-imports, no-external-vars, @typescript-eslint/no-var-requires
var packageJson = require('../package.json');
var ArgumentProvider = /** @class */ (function () {
    function ArgumentProvider(_httpClient, _logger, _authenticationProvider) {
        var _this = this;
        var _a, _b;
        this._httpClient = _httpClient;
        this._logger = _logger;
        this._authenticationProvider = _authenticationProvider;
        this._options = {};
        this._verb = (process.argv[2] || process.env.VERB);
        this._program = new commander_1.Command();
        // If a specific verb is detected (and it's not a flag like --help), we configure the program
        // to behave as if that verb is the command itself (e.g., "power-apps-cli add-data-source").
        // This allows us to display help specific to that verb (options, description) when --help is used,
        // rather than showing the generic top-level help. We omit the [verb] argument definition here
        // because the verb is already "consumed" into the program name for this execution context.
        if (this._verb && !this._verb.startsWith('-')) {
            this._program.name("power-apps ".concat(this._verb));
        }
        else {
            this._program.name('power-apps');
            this._program.usage('[option] [command] [<args>]');
        }
        this._program.version(packageJson.version, '-v, --version', 'output the current version');
        this._program.description(HelpStrings_1.HelpStrings.Global.ProgramDescription);
        // Register custom help text to show verb table on global --help
        // This uses Commander's addHelpText hook which runs when help is displayed
        this._program.addHelpText('after', function (context) {
            // Only show verb table for global help (not verb-specific help)
            if (!_this._verb || _this._verb.startsWith('-')) {
                return '\n' + (0, BuildVerbDescriptionTable_1.buildVerbDescriptionTable)() + '\n';
            }
            return '';
        });
        var settings = (0, CliSettings_1.getSettings)();
        this._environmentId = (_a = settings.appConfig) === null || _a === void 0 ? void 0 : _a.environmentId;
        this._region = (_b = settings.appConfig) === null || _b === void 0 ? void 0 : _b.region;
        if (!this._region) {
            // Do not provide a prompt, default to prod
            this.addOption({
                flags: {
                    key: 'region',
                    alias: 'r',
                },
                env: 'CLOUD_INSTANCE',
                default: 'prod',
                description: HelpStrings_1.HelpStrings.Global.Region,
            });
        }
        // If we do not have an environmentId, add an option to get one
        if (!this._environmentId) {
            this.addOption((0, CliUtils_1.createDefaultStringOption)({
                flags: {
                    key: 'environmentId',
                    alias: 'e',
                },
                env: 'ENVIRONMENT_ID',
                message: 'Please provide the environment ID:',
                description: HelpStrings_1.HelpStrings.Global.EnvironmentId,
            }));
        }
        (0, powerapps_player_services_1.initializePlayerServices)({
            httpClient: this._httpClient,
            logger: this._logger,
            // Default region is 'prod' if not specified
            region: this._region || 'prod',
            // Do a temporary variable
            environmentName: this._environmentId || 'default',
        });
    }
    ArgumentProvider.prototype.addSwitch = function (cliOption) {
        this._createOption(cliOption, false);
    };
    ArgumentProvider.prototype.addSwitches = function (cliOptions) {
        var _this = this;
        cliOptions.forEach(function (cliOption) { return _this._createOption(cliOption, false); });
    };
    ArgumentProvider.prototype.addOption = function (cliOption) {
        this._createOption(cliOption);
    };
    ArgumentProvider.prototype.addOptions = function (cliOptions) {
        var _this = this;
        cliOptions.forEach(function (cliOption) { return _this._createOption(cliOption); });
    };
    ArgumentProvider.prototype.runVerb = function () {
        return __awaiter(this, void 0, void 0, function () {
            var args;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        // Commander needs to see only the verb-specific arguments, so strip the verb token
                        // when a verb was supplied explicitly; global flag paths skip this method entirely.
                        if (this._verb && !this._verb.startsWith('-') && process.argv[2] === this._verb) {
                            args = __spreadArray([process.argv[0], process.argv[1]], __read(process.argv.slice(3)), false);
                            this._program.parse(args);
                        }
                        else {
                            this._program.parse();
                        }
                        return [4 /*yield*/, this._getRequiredVariables()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    // Handles scenarios where only global flags (e.g., --help/--version) are provided.
    // Returns 'help' when no verb is present, 'flag' when a flag verb needs Commander handling,
    // and 'none' when execution should continue to verb-specific logic.
    ArgumentProvider.prototype.handleGlobalHelpOrFlagsAndExit = function () {
        if (!this._verb) {
            this._program.help(); // This will display help and exit
        }
        if (this._verb.startsWith('-')) {
            this._program.parse(process.argv);
        }
    };
    ArgumentProvider.prototype.getVerb = function () {
        if (!this._verb || this._verb.startsWith('-')) {
            throw new Error('No verb found');
        }
        return this._verb;
    };
    ArgumentProvider.prototype.getOption = function (key, ignorePrompt) {
        return __awaiter(this, void 0, void 0, function () {
            var settings, value, option;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        settings = (0, CliSettings_1.getSettings)();
                        value = this._program.getOptionValue(key);
                        option = this._options[key];
                        // Fallback to environment variable if not provided via CLI
                        if (value === undefined && option && option.env) {
                            value = process.env[option.env];
                        }
                        // Fallback to default value if not provided via CLI or Env
                        if (value === undefined && option && option.default !== undefined) {
                            value = option.default;
                        }
                        if (!(!value && !ignorePrompt)) return [3 /*break*/, 2];
                        if (!(settings.source === 'standalone' && option && option.customPrompt)) return [3 /*break*/, 2];
                        return [4 /*yield*/, option.customPrompt()];
                    case 1:
                        value = _a.sent();
                        if ((0, prompts_1.isCancel)(value)) {
                            console.log('Operation cancelled by user.');
                            process.exit(0);
                        }
                        _a.label = 2;
                    case 2: 
                    // Option could be undefined by design, so just return it.
                    return [2 /*return*/, value];
                }
            });
        });
    };
    ArgumentProvider.prototype.getAuthenticationProvider = function () {
        return this._authenticationProvider;
    };
    /**
     * Sets the description for the current command context.
     * This is used to display help information specific to the verb being executed.
     *
     * @param {string} description - The description to set for the program.
     */
    ArgumentProvider.prototype.setDescription = function (description) {
        this._program.description(description);
    };
    ArgumentProvider.prototype.getEnvironmentId = function () {
        return this._environmentId;
    };
    ArgumentProvider.prototype._getRequiredVariables = function () {
        return __awaiter(this, void 0, void 0, function () {
            var environmentId, region;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(this._verb !== 'telemetry')) return [3 /*break*/, 4];
                        if (!!this._environmentId) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.getOption('environmentId')];
                    case 1:
                        environmentId = _a.sent();
                        if (environmentId) {
                            this._environmentId = environmentId;
                            (0, powerapps_player_services_1.updateEnvironmentName)(this._environmentId);
                        }
                        _a.label = 2;
                    case 2:
                        if (!!this._region) return [3 /*break*/, 4];
                        return [4 /*yield*/, this.getOption('region')];
                    case 3:
                        region = _a.sent();
                        if (region) {
                            this._region = region;
                            (0, powerapps_player_services_1.updateRegion)(region);
                        }
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * @param {CliOption} cliOption
     * @param {boolean} [hasValue=true] true if the option requires a value, false for a switch such as --help
     */
    ArgumentProvider.prototype._createOption = function (cliOption, hasValue) {
        if (hasValue === void 0) { hasValue = true; }
        var option = this._program.createOption(hasValue ? this._createFlags(cliOption.flags) : this._createSwitchFlags(cliOption.flags), cliOption.description);
        // We do not set the env or default here because we want to handle it manually in getOption
        // This allows us to hide the env variable from the help text
        // Hide global options from help output when showing global help
        // This prevents --environmentId and --region from showing up in the global help
        if (!this._verb || this._verb.startsWith('-')) {
            option.hideHelp();
        }
        this._program.addOption(option);
        // Map to CliOption to be able to run custom prompt logic if needed
        this._options[option.name()] = cliOption;
    };
    ArgumentProvider.prototype._createFlags = function (flags) {
        var key = flags.key, alias = flags.alias;
        return "-".concat(alias, ", --").concat(key, " <").concat(key, ">");
    };
    ArgumentProvider.prototype._createSwitchFlags = function (flags) {
        var key = flags.key, alias = flags.alias;
        return "-".concat(alias, ", --").concat(key);
    };
    return ArgumentProvider;
}());
exports.ArgumentProvider = ArgumentProvider;
//# sourceMappingURL=ArgumentProvider.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { Region } from '@pa-client/powerapps-player-services';
import { TelemetryLocation } from './Constants';
export interface IOneDSEndpointDetails {
    /** The unique key required for the specific Aria endpoint. */
    instrumentationKey: string;
    /** The endpoint that events will go to based on the instrumentationKey. */
    collectorUrl?: string;
}
export declare class OneDSTelemetryClient {
    private _sessionId;
    private _telemetryLocation;
    private _sequenceNumber;
    private _expectedCoreSequenceNumber;
    private _discardedBatches;
    get sessionId(): string;
    set sessionId(value: string);
    private _defaultCustomDimensions;
    private _analytics;
    /**
     * Property manager lets us add data to the log entry context
     */
    private _propertyManager;
    /**
     *
     * @param region: The region
     * @param telemetryLocation: The telemetry location
     * @param tenantId: The tenant ID
     * @param ariaProjectIds: The aria project id's
     */
    constructor(region: Region, telemetryLocation: TelemetryLocation, tenantId: string | undefined, ariaProjectIds: Record<string, string>);
    /**
     * This function logs user id/geo information to the common context
     * @param tenantId
     * @param oid
     * @returns true if we can log user information, false if we cannot log user information.
     */
    identifyUser(tenantId: string, oid: string): boolean;
    /**
     * This public method logs properties into data.context object
     *
     * @param propertyName: Any valid JSON string key
     *
     * @param propertyValue: Any valid string value
     */
    setDefaultProperty(propertyName: string, propertyValue: string, isCustomDimension?: boolean): void;
    /**
     * This private method logs properties directly into data object - these
     * properties are logged as context i.e. once they're set, they show up
     * in each log entry
     *
     * @param propertyName: Any valid JSON string key
     *
     * @param propertyValue: Any valid string value
     */
    private _addToTopLevelContext;
    trackEvent(eventName: string, eventData: object): void;
    /**
     * Track an anonymous telemetry event with no EUPI for the given data
     * @param eventName The name of the event.
     * @param data The event data to send.
     */
    trackAnonymousEvent(eventName: string, eventData: object): void;
    flush(): void;
    /**
     * Tracks a summary of discarded telemetry events, reporting the top 10 most frequent discard reasons by count and by size.
     *
     * @param discardSummary - A record where the key is a string describing the discard reason and the value contains count and maxSize.
     * @param totalEvents - The total number of events in the discarded batch.
     */
    trackDiscardedTelemetrySummary(discardSummary: Record<string, {
        count: number;
        maxSize: number;
    }>, totalEvents: number): void;
    private _getProperties;
    private _getOneDSConfig;
    private _getCollectorEndpoint;
}

#!/usr/bin/env node
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
var Cli_1 = require("./Cli");
(0, Cli_1.boot)();
//# sourceMappingURL=Bin.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare function containsEmail(value: string): boolean;
export declare function containsGoogleApiKey(value: string): boolean;
export declare function containsSasKeySig(value: string): boolean;
export declare function containsSymmKey256(value: string): boolean;

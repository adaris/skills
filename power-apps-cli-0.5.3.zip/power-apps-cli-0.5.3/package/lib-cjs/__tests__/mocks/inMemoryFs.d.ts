export type InMemoryFsState = {
    module: any;
    reset: () => void;
    seedFile: (filePath: string, content: string) => void;
    readFile: (filePath: string) => string | undefined;
    ensureDirectory: (dirPath: string) => void;
    getDirectories: () => string[];
};
export declare function createInMemoryFs(): InMemoryFsState;

/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { UserTelemetrySettings } from '../Types/Cli.types';
/**
 * Resolves the effective user telemetry settings by merging defaults, user config file, and environment overrides.
 *
 * Resolution priority (highest to lowest):
 * 1. Environment variable overrides:
 *    - POWERAPPS_CLI_TELEMETRY=0/false/no/off forces `enabled: false`
 *    - PAC_CLI_TELEMETRY_OPTOUT or PAC CLI usersettings.json `telemetryEnabled: false` forces `enabled: false`
 * 2. PowerApps CLI user settings file (~/.powerapps-cli/settings.json)
 * 3. Default values: `{ enabled: true, consoleOnly: false, outputToConsole: false }`
 *
 * @returns Resolved telemetry configuration with enabled, consoleOnly, and outputToConsole flags
 */
export declare function resolveUserTelemetrySettings(): UserTelemetrySettings;

/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
/**
 * Metadata for each CLI verb used to generate help output
 */
export interface VerbMetadata {
    description: string;
}
/**
 * Central registry of all CLI verbs with their descriptions.
 * This array is used to generate the verb table in --help output.
 *
 * IMPORTANT: When adding a new verb, you must:
 * 1. Add to Verb type in Cli.types.ts
 * 2. Add case to executeVerb() switch in Cli.ts
 * 3. Add entry to this VERB_REGISTRY array
 * 4. Add entry to HelpStrings.Verbs in HelpStrings.ts
 */
export declare const VERB_HELP_REGISTRY: {
    init: {
        description: string;
    };
    push: {
        description: string;
    };
    run: {
        description: string;
    };
    'add-data-source': {
        description: string;
    };
    'list-codeapps': {
        description: string;
    };
    'list-datasets': {
        description: string;
    };
    'list-tables': {
        description: string;
    };
    'list-sqlStoredProcedures': {
        description: string;
    };
    'delete-data-source': {
        description: string;
    };
    'list-environment-variables': {
        description: string;
    };
    'list-connection-references': {
        description: string;
    };
    logout: {
        description: string;
    };
    telemetry: {
        description: string;
    };
};

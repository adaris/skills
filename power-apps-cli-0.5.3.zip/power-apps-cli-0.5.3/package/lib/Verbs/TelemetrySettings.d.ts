/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
/**
 * Modify the user telemetry settings
 * Does not resolve conflicts between options; Just writes whatever is provided
 * @param {ArgumentProvider} argumentProvider
 * @returns {Promise<void>}
 */
export declare function modifyTelemetrySettings(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=TelemetrySettings.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IAuthenticationProvider } from '../Types/Cli.types';
export declare class PacCliAuthenticationProvider implements IAuthenticationProvider {
    private _tokenCache;
    initAsync(): Promise<void>;
    getAccessTokenForResource(resource: string): Promise<string>;
    getUserTenantId(): string | undefined;
    private _getAccessTokenFromResourceInternal;
    private _requestToken;
    private _readStdIn;
}

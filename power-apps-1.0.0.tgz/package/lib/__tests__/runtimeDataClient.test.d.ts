export {};
//# sourceMappingURL=runtimeDataClient.test.d.ts.map
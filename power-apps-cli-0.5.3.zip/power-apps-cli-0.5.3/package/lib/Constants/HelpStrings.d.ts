/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare const HelpStrings: {
    Global: {
        ProgramDescription: string;
        Region: string;
        EnvironmentId: string;
    };
    Verbs: {
        'Add-data-source': {
            Description: string;
            Options: {
                ApiId: string;
                ConnectionId: string;
                ConnectionRef: string;
                ResourceName: string;
                Dataset: string;
                EnvUrl: string;
                SqlStoredProcedure: string;
                SolutionId: string;
            };
        };
        'Delete-data-source': {
            Description: string;
            Options: {
                ApiId: string;
                DataSourceName: string;
                SqlStoredProcedure: string;
            };
        };
        Init: {
            Description: string;
            Options: {
                EnvironmentId: string;
                Region: string;
                DisplayName: string;
                Description: string;
                BuildPath: string;
                FileEntryPoint: string;
                AppUrl: string;
                LogoPath: string;
            };
        };
        'List-codeapps': {
            Description: string;
        };
        'List-connection-references': {
            Description: string;
            Options: {
                SolutionId: string;
                EnvUrl: string;
            };
        };
        'List-datasets': {
            Description: string;
            Options: {
                ApiId: string;
                ConnectionId: string;
            };
        };
        'List-environment-variables': {
            Description: string;
            Options: {
                EnvUrl: string;
            };
        };
        'List-sqlStoredProcedures': {
            Description: string;
            Options: {
                ConnectionId: string;
                Dataset: string;
            };
        };
        'List-tables': {
            Description: string;
            Options: {
                ApiId: string;
                ConnectionId: string;
                Dataset: string;
            };
        };
        Logout: {
            Description: string;
        };
        Push: {
            Description: string;
            Options: {
                SolutionName: string;
            };
        };
        Run: {
            Description: string;
            Options: {
                Port: string;
                LocalAppUrl: string;
            };
        };
        Telemetry: {
            Description: string;
            Options: {
                Enable: string;
                Disable: string;
                ShowSettings: string;
                ConsoleOnly: string;
                OutputToConsole: string;
            };
        };
    };
};
//# sourceMappingURL=HelpStrings.d.ts.map
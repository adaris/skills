"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.modifyTelemetrySettings = void 0;
var Constants_1 = require("../Constants");
var fs = __importStar(require("fs"));
var path = __importStar(require("path"));
var HelpStrings_1 = require("../Constants/HelpStrings");
/**
 * Modify the user telemetry settings
 * Does not resolve conflicts between options; Just writes whatever is provided
 * @param {ArgumentProvider} argumentProvider
 * @returns {Promise<void>}
 */
function modifyTelemetrySettings(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var enableTelemetry, disableTelemetry, showSettings, consoleOnly, outputToConsole, telemetryEnabled;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    createOptionSchema(argumentProvider);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, argumentProvider.getOption('enable', true)];
                case 2:
                    enableTelemetry = _a.sent();
                    return [4 /*yield*/, argumentProvider.getOption('disable', true)];
                case 3:
                    disableTelemetry = _a.sent();
                    return [4 /*yield*/, argumentProvider.getOption('showSettings', true)];
                case 4:
                    showSettings = _a.sent();
                    return [4 /*yield*/, argumentProvider.getOption('consoleOnly', true)];
                case 5:
                    consoleOnly = _a.sent();
                    return [4 /*yield*/, argumentProvider.getOption('outputToConsole', true)];
                case 6:
                    outputToConsole = _a.sent();
                    // if all are undefined, show current settings as default behavior
                    if (enableTelemetry === undefined &&
                        disableTelemetry === undefined &&
                        consoleOnly === undefined &&
                        outputToConsole === undefined &&
                        showSettings === undefined) {
                        displayUserTelemetrySettings();
                        return [2 /*return*/];
                    }
                    // if both enable and disable are set, throw an error
                    if (enableTelemetry && disableTelemetry) {
                        throw new Error('Cannot enable and disable telemetry at the same time.');
                    }
                    if (showSettings) {
                        displayUserTelemetrySettings();
                    }
                    else {
                        telemetryEnabled = enableTelemetry ? true : disableTelemetry ? false : undefined;
                        updateUserTelemetrySettings(telemetryEnabled, consoleOnly, outputToConsole);
                    }
                    return [2 /*return*/];
            }
        });
    });
}
exports.modifyTelemetrySettings = modifyTelemetrySettings;
function createOptionSchema(argumentProvider) {
    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs.Telemetry.Description);
    argumentProvider.addSwitches([
        {
            flags: {
                key: 'enable',
                alias: 'te',
            },
            env: 'POWERAPPS_CLI_ENABLE_TELEMETRY',
            description: HelpStrings_1.HelpStrings.Verbs.Telemetry.Options.Enable,
        },
        {
            flags: {
                key: 'disable',
                alias: 'td',
            },
            env: 'POWERAPPS_CLI_DISABLE_TELEMETRY',
            description: HelpStrings_1.HelpStrings.Verbs.Telemetry.Options.Disable,
        },
        {
            flags: {
                key: 'showSettings',
                alias: 'ts',
            },
            env: 'POWERAPPS_CLI_SHOW_SETTINGS',
            description: HelpStrings_1.HelpStrings.Verbs.Telemetry.Options.ShowSettings,
        },
    ]);
    argumentProvider.addOptions([
        {
            flags: {
                key: 'consoleOnly',
                alias: 'tc',
            },
            env: 'POWERAPPS_CLI_CONSOLE_ONLY',
            description: HelpStrings_1.HelpStrings.Verbs.Telemetry.Options.ConsoleOnly,
        },
        {
            flags: {
                key: 'outputToConsole',
                alias: 'to',
            },
            env: 'POWERAPPS_CLI_OUTPUT_TO_CONSOLE',
            description: HelpStrings_1.HelpStrings.Verbs.Telemetry.Options.OutputToConsole,
        },
    ]);
}
function displayUserTelemetrySettings() {
    try {
        var userSettingsPath = path.join(Constants_1.CLI_CONFIG_DIRECTORY, Constants_1.USER_SETTINGS_FILE);
        if (fs.existsSync(userSettingsPath)) {
            var fileContent = fs.readFileSync(userSettingsPath, 'utf-8');
            var existingSettings = JSON.parse(fileContent);
            console.log('Current Telemetry Settings:');
            console.log("  Enabled: ".concat(existingSettings.enabled));
            console.log("  Console Only: ".concat(existingSettings.consoleOnly));
            console.log("  Output To Console: ".concat(existingSettings.outputToConsole));
        }
        else {
            console.log('No telemetry settings found. Using default settings.');
        }
    }
    catch (error) {
        console.error("Failed to display telemetry settings: ".concat(error.message));
    }
}
function updateUserTelemetrySettings(telemetryEnabled, consoleOnly, outputToConsole) {
    // CLI_CONFIG_DIRECTORY, USER_SETTINGS_FILE
    try {
        if (fs.existsSync(Constants_1.CLI_CONFIG_DIRECTORY) === false) {
            fs.mkdirSync(Constants_1.CLI_CONFIG_DIRECTORY, { recursive: true });
        }
        var userSettingsPath = path.join(Constants_1.CLI_CONFIG_DIRECTORY, Constants_1.USER_SETTINGS_FILE);
        var userSettings = void 0;
        if (fs.existsSync(userSettingsPath)) {
            var fileContent = fs.readFileSync(userSettingsPath, 'utf-8');
            var existingSettings = JSON.parse(fileContent);
            userSettings = {
                enabled: telemetryEnabled !== null && telemetryEnabled !== void 0 ? telemetryEnabled : existingSettings.enabled,
                consoleOnly: consoleOnly !== undefined ? consoleOnly === 'true' : existingSettings.consoleOnly,
                outputToConsole: outputToConsole !== undefined ? outputToConsole === 'true' : existingSettings.outputToConsole,
            };
        }
        else {
            userSettings = {
                enabled: telemetryEnabled !== null && telemetryEnabled !== void 0 ? telemetryEnabled : true,
                consoleOnly: consoleOnly !== undefined ? consoleOnly === 'true' : false,
                outputToConsole: outputToConsole !== undefined ? outputToConsole === 'true' : false,
            };
        }
        fs.writeFileSync(userSettingsPath, JSON.stringify(userSettings, null, 2), 'utf-8');
    }
    catch (error) {
        throw new Error("Failed to update telemetry settings: ".concat(error.message));
    }
}
//# sourceMappingURL=TelemetrySettings.js.map
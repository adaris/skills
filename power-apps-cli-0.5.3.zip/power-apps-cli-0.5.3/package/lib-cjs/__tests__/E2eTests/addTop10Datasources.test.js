"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var globals_1 = require("@jest/globals");
var fs_1 = __importDefault(require("fs"));
var path_1 = __importDefault(require("path"));
var argumentBuilder_1 = require("../helpers/argumentBuilder");
var testHelpers_1 = require("../helpers/testHelpers");
// eslint-disable-next-line no-external-vars
var CLI_PATH = path_1.default.resolve(__dirname, '..', '..', '..', 'dist', 'nomodule', 'powerapps-player-cli.js');
var TEST_FOLDER_NAME = 'addTop10Datasources';
// eslint-disable-next-line no-external-vars
var HOST_TEMPLATE_FOLDER = path_1.default.resolve(__dirname, 'host-app');
var TEMP_BASE_DIR = 'C:\\tmp\\addTop10DatasourcesTests';
// E2E test configuration - update these values for your test environment
// This config *should* come from the pipeline/some config so we can run on different environments
var TEST_CONFIG = {
    environmentId: '5c1dc2ed-bf65-e52c-ab22-ea1fc9c10106',
    region: 'prod',
    envUrl: 'https://orgd66bf470.crm.dynamics.com',
    solutionId: '',
    // the double quotes here are intentional to ensure that the CLI arg parser treats these as strings with spaces
    appDisplayName: '"E2E Test App"',
    appDescription: '"Test application for CLI E2E verification"',
};
(0, globals_1.describe)('powerapps-player-cli add top 10 datasources', function () {
    var projectRoot;
    (0, globals_1.beforeAll)(function () {
        projectRoot = (0, testHelpers_1.setupE2eTestProject)({
            cliPath: CLI_PATH,
            tempBaseDir: TEMP_BASE_DIR,
            testFolderName: TEST_FOLDER_NAME,
            hostTemplateFolder: HOST_TEMPLATE_FOLDER,
        });
    });
    (0, globals_1.afterAll)(function () {
        (0, testHelpers_1.cleanupE2eTestProject)(projectRoot);
    });
    (0, globals_1.it)('runs add-data-source commands sequentially without error', function () { return __awaiter(void 0, void 0, void 0, function () {
        var executeCodeCommand, initResult, powerConfigPath, configAfterInit, addOffice365UsersResult, configAfterAdd, addDataverseResult, addSharePointResult, addExcelResult, addOffice365GroupsResult, addKustoResult, addTeamsResult, addMsnWeatherResult, addOneDriveResult, addTranslatorResult, addPowerAppsResult;
        return __generator(this, function (_a) {
            executeCodeCommand = (0, testHelpers_1.createExecuteCodeCommand)({
                cliPath: CLI_PATH,
                workingDirectory: projectRoot,
            });
            initResult = executeCodeCommand('init', (0, argumentBuilder_1.buildInitArgs)({
                environmentId: TEST_CONFIG.environmentId,
                region: TEST_CONFIG.region,
                displayName: TEST_CONFIG.appDisplayName,
                description: TEST_CONFIG.appDescription,
            }));
            (0, globals_1.expect)(initResult.stdout).toContain('Created power.config.json');
            powerConfigPath = path_1.default.join(projectRoot, 'power.config.json');
            (0, globals_1.expect)(fs_1.default.existsSync(powerConfigPath)).toBe(true);
            configAfterInit = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterInit.environmentId).toBe(TEST_CONFIG.environmentId);
            (0, globals_1.expect)(configAfterInit.region).toBe(TEST_CONFIG.region);
            (0, globals_1.expect)(configAfterInit.appDisplayName).toBe(TEST_CONFIG.appDisplayName.replace(/"/g, ''));
            (0, globals_1.expect)(configAfterInit.description).toBe(TEST_CONFIG.appDescription.replace(/"/g, ''));
            addOffice365UsersResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'shared_office365users',
                connectionId: '2e88f1207762440c80c9f977a765d972',
            }));
            (0, globals_1.expect)(addOffice365UsersResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'office365users');
            addDataverseResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'dataverse',
                resourceName: 'contact',
            }));
            (0, globals_1.expect)(addDataverseResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'contact');
            addSharePointResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'sharepointonline',
                dataset: 'https%253A%252F%252Fmicrosoft.sharepoint.com%252Fteams%252FPowerApps7',
                resourceName: 'TestListBYOC',
                connectionId: 'a751c2579f804634934dd7aefd6db262',
            }));
            (0, globals_1.expect)(addSharePointResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'testlistbyoc');
            addExcelResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'shared_excelonlinebusiness',
                connectionId: '771b526221e3441b8d5ed3f9690606ba',
            }));
            (0, globals_1.expect)(addExcelResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'excelonlinebusiness');
            addOffice365GroupsResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'office365groups',
                connectionId: '1339caffcf6c4814ae7965f476199aca',
            }));
            (0, globals_1.expect)(addOffice365GroupsResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'office365groups');
            addKustoResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'kusto',
                connectionId: 'c43a2e0c1e71453382c94fa185d706ce',
            }));
            (0, globals_1.expect)(addKustoResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'kusto');
            addTeamsResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'teams',
                connectionId: 'shared-teams-029a72fd-4c72-461d-b84d-5621429e8993',
            }));
            (0, globals_1.expect)(addTeamsResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'teams');
            addMsnWeatherResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'msnweather',
                connectionId: '717226d2459f4635b6a17652f627bc0f',
            }));
            (0, globals_1.expect)(addMsnWeatherResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'msnweather');
            addOneDriveResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'onedriveforbusiness',
                connectionId: '25b1a3dd596c4b88bd26c24b3b0fdf5e',
            }));
            (0, globals_1.expect)(addOneDriveResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'onedriveforbusiness');
            addTranslatorResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'translatorv2',
                connectionId: '1b1443b1190b4bcb98c736f1223cb25a',
            }));
            (0, globals_1.expect)(addTranslatorResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'translatorv2');
            addPowerAppsResult = executeCodeCommand('add-data-source', (0, argumentBuilder_1.buildAddDataSourceArgs)({
                apiId: 'powerappsforappmakers',
                connectionId: 'c8669aea4451402588ea25d2cef5a0cf',
            }));
            (0, globals_1.expect)(addPowerAppsResult.stderr).toBe('');
            configAfterAdd = (0, testHelpers_1.readJson)(powerConfigPath);
            (0, globals_1.expect)(configAfterAdd.databaseReferences).toBeDefined();
            (0, testHelpers_1.validateGeneratedFiles)(projectRoot, 'powerappsforappmakers');
            return [2 /*return*/];
        });
    }); });
});
//# sourceMappingURL=addTop10Datasources.test.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
/// <reference types="jest" />
export declare const createMockLogModule: (options?: {
    silent?: boolean;
}) => {
    Log: {
        createInstance: jest.Mock<void, any[], any>;
        resetInstance: jest.Mock<void, any[], any>;
        trackEvent: jest.Mock<void, any[], any>;
        trackException: jest.Mock<void, any[], any>;
        trackMetric: jest.Mock<void, any[], any>;
        startScenario: jest.Mock<void, any[], any>;
        endScenario: jest.Mock<void, any[], any>;
        setDefaultProperties: jest.Mock<void, any[], any>;
    };
};
export declare const mockSilentLogger: {
    Log: {
        createInstance: jest.Mock<void, any[], any>;
        resetInstance: jest.Mock<void, any[], any>;
        trackEvent: jest.Mock<void, any[], any>;
        trackException: jest.Mock<void, any[], any>;
        trackMetric: jest.Mock<void, any[], any>;
        startScenario: jest.Mock<void, any[], any>;
        endScenario: jest.Mock<void, any[], any>;
        setDefaultProperties: jest.Mock<void, any[], any>;
    };
};
//# sourceMappingURL=mockLog.d.ts.map
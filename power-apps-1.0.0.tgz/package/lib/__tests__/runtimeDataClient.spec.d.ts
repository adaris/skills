export {};
//# sourceMappingURL=runtimeDataClient.spec.d.ts.map
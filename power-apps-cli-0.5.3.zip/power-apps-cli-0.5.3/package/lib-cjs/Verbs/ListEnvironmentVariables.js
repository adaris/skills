"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listAllEnvironmentVariablesAsync = void 0;
var ListEnvironmentVariables_1 = require("@microsoft/powerapps-player-actions/lib/Actions/ListEnvironmentVariables");
var powerapps_player_services_1 = require("@pa-client/powerapps-player-services");
var CliSettings_1 = require("../CliSettings");
var CliUtils_1 = require("../CliUtils");
var CliFs_1 = require("../FS/CliFs");
var HelpStrings_1 = require("../Constants/HelpStrings");
var VerbConstants_1 = require("./VerbConstants");
/**
 * Get environment variables from a Dataverse environment.
 * Expects the following arguments:
 * - envUrl: The environment URL for Dataverse data sources
 *
 * @param {ArgumentProvider} argumentProvider
 * @returns {Promise<void>}
 */
function listAllEnvironmentVariablesAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var settings, fileConfig, cliFs, playerServiceConfig, authenticationProvider, dsConfig, environmentVariableDefinitions;
        var _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    settings = (0, CliSettings_1.getSettings)();
                    fileConfig = settings.fileConfig;
                    createOptionSchema(argumentProvider);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _c.sent();
                    cliFs = new CliFs_1.CliFS({
                        cwd: process.cwd(),
                        allowCwdRead: true,
                        allowCwdWrite: true,
                    });
                    playerServiceConfig = (0, powerapps_player_services_1.getPlayerServiceConfig)();
                    authenticationProvider = argumentProvider.getAuthenticationProvider();
                    _a = {
                        vfs: cliFs,
                        authProvider: authenticationProvider,
                        region: playerServiceConfig.region,
                        environmentName: playerServiceConfig.environmentName
                    };
                    _b = {};
                    return [4 /*yield*/, argumentProvider.getOption('envUrl')];
                case 2:
                    dsConfig = (_a.actionsParams = (_b.envUrl = _c.sent(),
                        _b),
                        _a.localFilePaths = {
                            powerConfigPath: fileConfig.powerConfigPath,
                            schemaPath: fileConfig.schemaPath,
                            codeGenPath: fileConfig.codeGenPath,
                        },
                        _a.logger = (0, CliSettings_1.getCliLogger)(),
                        _a);
                    return [4 /*yield*/, (0, ListEnvironmentVariables_1.listAllEnvironmentVariablesAsync)(dsConfig)];
                case 3:
                    environmentVariableDefinitions = _c.sent();
                    console.log('\nEnvironment Variables:');
                    console.log('─'.repeat(100));
                    // printing as a list rather than as a table to avoid truncating env variable names & values
                    environmentVariableDefinitions.forEach(function (envVar) {
                        var _a, _b;
                        console.log("Schema Name: ".concat(envVar.schemaname));
                        console.log("Display Name: ".concat(envVar.displayname));
                        console.log("Type: ".concat(envVar.type));
                        console.log("Value: ".concat((_b = (_a = envVar.environmentvariabledefinition_environmentvariablevalue[0]) === null || _a === void 0 ? void 0 : _a.value) !== null && _b !== void 0 ? _b : '<No Value>'));
                        console.log('─'.repeat(100));
                    });
                    return [2 /*return*/];
            }
        });
    });
}
exports.listAllEnvironmentVariablesAsync = listAllEnvironmentVariablesAsync;
function createOptionSchema(argumentProvider) {
    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs['List-environment-variables'].Description);
    argumentProvider.addOptions([
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.EnvironmentUrl.name,
                alias: VerbConstants_1.SharedArguments.EnvironmentUrl.alias,
            },
            env: VerbConstants_1.SharedArguments.EnvironmentUrl.envVar,
            message: VerbConstants_1.SharedArguments.EnvironmentUrl.promptMessage,
            default: '',
            description: HelpStrings_1.HelpStrings.Verbs['List-environment-variables'].Options.EnvUrl,
        }),
    ]);
}
//# sourceMappingURL=ListEnvironmentVariables.js.map
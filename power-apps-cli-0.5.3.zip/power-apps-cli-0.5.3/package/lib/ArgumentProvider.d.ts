/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { Verb } from './Types/Cli.types';
import { CliOption } from './Types/Argument.types';
import { IHttpClient } from '@pa-client/powerapps-player-services/lib/Types/IHttpClient';
import { ILogger } from '@pa-client/powerapps-player-services/lib/Types/PlayerServices.types';
import { IAuthenticationProvider } from './Types/Cli.types';
export interface IArgumentProvider {
    addOption(cliOption: CliOption): void;
    addOptions(cliOptions: CliOption[]): void;
    addSwitch(cliOption: CliOption): void;
    addSwitches(cliOptions: CliOption[]): void;
    runVerb(): Promise<void>;
    getVerb(): Verb;
    handleGlobalHelpOrFlagsAndExit(): void;
    getOption<T>(key: string, ignorePrompt?: boolean): Promise<T>;
    getAuthenticationProvider(): IAuthenticationProvider;
    setDescription(description: string): void;
}
export declare class ArgumentProvider implements IArgumentProvider {
    private _httpClient;
    private _logger;
    private _authenticationProvider;
    private _environmentId;
    private _region;
    private _verb;
    private _program;
    private _options;
    constructor(_httpClient: IHttpClient, _logger: ILogger, _authenticationProvider: IAuthenticationProvider);
    addSwitch(cliOption: CliOption): void;
    addSwitches(cliOptions: CliOption[]): void;
    addOption(cliOption: CliOption): void;
    addOptions(cliOptions: CliOption[]): void;
    runVerb(): Promise<void>;
    handleGlobalHelpOrFlagsAndExit(): void;
    getVerb(): Verb;
    getOption<T>(key: string, ignorePrompt?: boolean): Promise<T>;
    getAuthenticationProvider(): IAuthenticationProvider;
    /**
     * Sets the description for the current command context.
     * This is used to display help information specific to the verb being executed.
     *
     * @param {string} description - The description to set for the program.
     */
    setDescription(description: string): void;
    getEnvironmentId(): string | undefined;
    private _getRequiredVariables;
    /**
     * @param {CliOption} cliOption
     * @param {boolean} [hasValue=true] true if the option requires a value, false for a switch such as --help
     */
    private _createOption;
    private _createFlags;
    private _createSwitchFlags;
}
//# sourceMappingURL=ArgumentProvider.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InitArguments = exports.DeleteDataSourceArguments = exports.AddDataSourceArguments = exports.SharedArguments = void 0;
/**
 * Argument definitions for CLI verbs.
 */
exports.SharedArguments = {
    Help: {
        name: 'help',
        alias: 'h',
    },
    ApiId: {
        name: 'apiId',
        alias: 'a',
        promptMessage: 'Please provide the API ID:',
        envVar: 'API_ID',
    },
    SolutionId: {
        name: 'solutionId',
        alias: 's',
        promptMessage: 'Please provide the Solution ID:',
        envVar: 'SOLUTION_ID',
    },
    EnvironmentUrl: {
        name: 'envUrl',
        alias: 'u',
        promptMessage: 'Please provide the environment URL:',
        envVar: 'ENV_URL',
    },
    ConnectionId: {
        name: 'connectionId',
        alias: 'c',
        promptMessage: 'Please provide the Connection ID:',
        envVar: 'CONNECTION_ID',
    },
    Dataset: {
        name: 'dataset',
        alias: 'd',
        promptMessage: 'Please provide the dataset:',
        envVar: 'DATASET',
    },
    SqlStoredProcedure: {
        name: 'sqlStoredProcedure',
        alias: 'sp',
        promptMessage: 'Please provide the SQL stored procedure name:',
        envVar: 'SQL_STORED_PROCEDURE',
    },
    ResourceName: {
        name: 'resourceName',
        alias: 't',
        promptMessage: 'Please provide the resource name:',
        envVar: 'TABLE',
    },
};
exports.AddDataSourceArguments = {
    ConnectionRef: {
        name: 'connectionRef',
        alias: 'cr',
        promptMessage: 'Please provide the Connection Reference:',
        envVar: 'CONNECTION_REF',
    },
};
exports.DeleteDataSourceArguments = {
    DataSourceName: {
        name: 'dataSourceName',
        alias: 'n',
        promptMessage: 'Please provide the data source or table name:',
        envVar: 'DATA_SOURCE_NAME',
    },
};
exports.InitArguments = {
    EnvironmentId: {
        name: 'environmentId',
        alias: 'e',
        promptMessage: 'Please provide the environment ID for the app:',
        envVar: 'ENVIRONMENT_ID',
    },
    Region: {
        name: 'region',
        alias: 'c',
        promptMessage: 'Please select the region for the app:',
        envVar: 'CLOUD_INSTANCE',
    },
    DisplayName: {
        name: 'displayName',
        alias: 'n',
        promptMessage: 'Please provide the display name for the app:',
        envVar: 'APP_DISPLAY_NAME',
    },
    Description: {
        name: 'description',
        alias: 'd',
        promptMessage: 'Please provide a description for the app:',
        envVar: 'APP_DESCRIPTION',
    },
    BuildPath: {
        name: 'buildPath',
        alias: 'b',
        promptMessage: 'Please provide the build path for the app:',
        envVar: 'APP_BUILD_PATH',
        initialValue: './dist',
    },
    FileEntryPoint: {
        name: 'fileEntryPoint',
        alias: 'f',
        promptMessage: 'Please provide the file entry point for the app:',
        envVar: 'APP_FILE_ENTRY_POINT',
        initialValue: 'index.html',
    },
    AppUrl: {
        name: 'appUrl',
        alias: 'l',
        promptMessage: 'Please provide the local app URL:',
        envVar: 'APP_URL',
        initialValue: 'http://localhost:3000',
    },
    LogoPath: {
        name: 'logoPath',
        alias: 'l',
        promptMessage: 'Please provide the logo path for the app:',
        envVar: 'APP_LOGO_PATH',
        initialValue: 'Default',
    },
};
//# sourceMappingURL=VerbConstants.js.map
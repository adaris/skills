"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EUGeoRegions = exports.ScenarioResults = exports.OneDSEventNames = exports.AriaProjectIds = void 0;
exports.AriaProjectIds = {
    Mooncake: '1c1d139788f74386bd95e752dd781371-04b4424b-e5c1-46ae-8312-28e9fa5832c0-6923',
    Production: '5c3a61f48d7c4522912765ae7465ab5c-fb3d6606-fe59-4d6b-9bb1-5e993d889672-7138',
    NonProduction: '3fb21f3df5c44380bf452fd710f4d50c-0e3f82aa-6d27-41d8-b727-c96b28f99992-7504',
    GccModerate: '0d7685a948a140789ac92933d3dc2d87-2dd0c1ce-8f10-41f0-a70a-2f9e51a851c8-6823',
    GccHigh: 'd31229fb23b0406790b9332e5f465dfc-a6b19a0e-170d-4570-bda5-f35e3668e162-7067',
    DoD: '41cc10dad35043adbcdace2896484ab4-5ebbc1d6-04c9-486d-a6b6-e5963cd778da-7542',
    Ex: '5c3a61f48d7c4522912765ae7465ab5c-fb3d6606-fe59-4d6b-9bb1-5e993d889672-7138',
    Rx: '5c3a61f48d7c4522912765ae7465ab5c-fb3d6606-fe59-4d6b-9bb1-5e993d889672-7138',
    EuropeanInstitution: '4593c825ce244623924d515621b569ef-fafc5a58-3014-48cd-bc81-0f39454ae4e9-7075', // No kusto, MDS / DGrep-only
};
exports.OneDSEventNames = {
    ActivityEvent: 'PowerAppsClient.Activity',
    EndScenario: 'PowerAppsClient.EndScenario',
    ErrorEvent: 'PowerAppsClient.Error',
    StartScenario: 'PowerAppsClient.StartScenario',
};
exports.ScenarioResults = {
    Success: 'Success',
    Failed: 'Failed',
    SuccessWithErrors: 'SuccessWithErrors',
};
exports.EUGeoRegions = new Set([
    'europe',
    'france',
    'germany',
    'italy',
    'poland',
    'norway',
    'sweden',
    'switzerland',
    'unitedkingdom',
]);
//# sourceMappingURL=Constants.js.map
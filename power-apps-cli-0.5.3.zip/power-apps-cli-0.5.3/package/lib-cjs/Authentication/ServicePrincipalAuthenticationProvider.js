"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServicePrincipalAuthenticationProvider = void 0;
var msal_node_1 = require("@azure/msal-node");
/**
 * note: This is meant for use in CI only since it hardcodes the authority & tenant ID.
 */
var ServicePrincipalAuthenticationProvider = /** @class */ (function () {
    function ServicePrincipalAuthenticationProvider() {
        if (!process.env.SP_CLIENT_ID || !process.env.SP_CLIENT_SECRET || !process.env.SP_TENANT_ID) {
            throw new Error('Service Principal environment variables SP_CLIENT_ID, SP_CLIENT_SECRET, and SP_TENANT_ID must be set');
        }
        this._clientId = process.env.SP_CLIENT_ID;
        this._clientSecret = process.env.SP_CLIENT_SECRET;
        this._tenantId = process.env.SP_TENANT_ID;
    }
    ServicePrincipalAuthenticationProvider.prototype.initAsync = function () {
        return __awaiter(this, void 0, void 0, function () {
            var authConfig;
            return __generator(this, function (_a) {
                authConfig = {
                    auth: {
                        clientId: this._clientId,
                        clientSecret: this._clientSecret,
                        authority: "https://login.microsoftonline.com/".concat(this._tenantId),
                    },
                };
                this._msalClient = new msal_node_1.ConfidentialClientApplication(authConfig);
                return [2 /*return*/];
            });
        });
    };
    ServicePrincipalAuthenticationProvider.prototype.getAccessTokenForResource = function (resource) {
        return __awaiter(this, void 0, void 0, function () {
            var clientCredentialRequest, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this._msalClient) {
                            throw new Error('Authentication not initialized yet');
                        }
                        clientCredentialRequest = {
                            scopes: [resource + '/.default'],
                        };
                        return [4 /*yield*/, this._msalClient.acquireTokenByClientCredential(clientCredentialRequest)];
                    case 1:
                        result = _a.sent();
                        if (!(result === null || result === void 0 ? void 0 : result.accessToken)) {
                            throw new Error('Failed to acquire token using service principal');
                        }
                        return [2 /*return*/, result.accessToken];
                }
            });
        });
    };
    ServicePrincipalAuthenticationProvider.prototype.getUserTenantId = function () {
        return this._tenantId;
    };
    return ServicePrincipalAuthenticationProvider;
}());
exports.ServicePrincipalAuthenticationProvider = ServicePrincipalAuthenticationProvider;
//# sourceMappingURL=ServicePrincipalAuthenticationProvider.js.map
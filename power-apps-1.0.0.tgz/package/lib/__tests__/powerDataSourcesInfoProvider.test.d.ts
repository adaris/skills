/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export {};
//# sourceMappingURL=powerDataSourcesInfoProvider.test.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.expectConsoleSequence = exports.silenceSpecificConsole = exports.silenceConsole = void 0;
var globals_1 = require("@jest/globals");
/**
 * Silences console output for the current test file
 * Call this in beforeEach or beforeAll
 */
function silenceConsole() {
    var original = {
        log: console.log,
        error: console.error,
        warn: console.warn,
        info: console.info,
    };
    var mocks = {
        log: globals_1.jest.fn(),
        error: globals_1.jest.fn(),
        warn: globals_1.jest.fn(),
        info: globals_1.jest.fn(),
    };
    // Replace console methods with mocks
    console.log = mocks.log;
    console.error = mocks.error;
    console.warn = mocks.warn;
    console.info = mocks.info;
    var restore = function () {
        console.log = original.log;
        console.error = original.error;
        console.warn = original.warn;
        console.info = original.info;
    };
    return { mocks: mocks, restore: restore };
}
exports.silenceConsole = silenceConsole;
/**
 * Higher-order function that silences console for specific methods only
 * example usage:
 * const { mocks, restore } = silenceSpecificConsole(['error', 'warn']);
 */
function silenceSpecificConsole(methods) {
    var original = {};
    var mocks = {};
    methods.forEach(function (method) {
        original[method] = console[method];
        mocks[method] = globals_1.jest.fn();
        console[method] = mocks[method];
    });
    var restore = function () {
        methods.forEach(function (method) {
            if (original[method]) {
                console[method] = original[method];
            }
        });
    };
    return { mocks: mocks, restore: restore };
}
exports.silenceSpecificConsole = silenceSpecificConsole;
/**
 * Utility function to assert multiple lines of console output
 *
 * @param {(jest.MockedFunction<
 *     typeof console.log | typeof console.error | typeof console.warn | typeof console.info
 *   >)} mockFn
 * @param {string[]} expectedOutputLines Lines expected to be logged
 */
function expectConsoleSequence(mockFn, expectedOutputLines) {
    // expect(mockFn).toHaveBeenCalledTimes(expectedOutputLines.length);
    expectedOutputLines.forEach(function (expectedCall, index) {
        (0, globals_1.expect)(mockFn).toHaveBeenNthCalledWith(index + 1, expectedCall);
    });
}
exports.expectConsoleSequence = expectConsoleSequence;
/* eslint-enable @typescript-eslint/no-explicit-any */
//# sourceMappingURL=silentConsole.js.map
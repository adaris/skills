/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IRuntimeClientProvider, IRuntimeDataClient, IRuntimeMetadataClient } from '../common/types';
import { IPowerOperationExecutor } from '../types';
/**
 * RuntimeClientProvider manages the lifecycle of runtime clients for data and metadata operations.
 * Implements a lazy initialization pattern for clients and ensures proper error handling.
 */
export declare class RuntimeClientProvider implements IRuntimeClientProvider {
    private _dataClient;
    private _metadataClient;
    private readonly _operationExecutor;
    constructor(powerOperationExecutor: IPowerOperationExecutor);
    /**
     * Gets or initializes the data client
     * @throws Error if client initialization fails
     * @returns Promise resolving to IRuntimeDataClient
     */
    getDataClientAsync(): Promise<IRuntimeDataClient>;
    /**
     * Gets or initializes the metadata client
     * @throws Error if client initialization fails
     * @returns Promise resolving to IRuntimeMetadataClient
     */
    getMetadataClientAsync(): Promise<IRuntimeMetadataClient>;
    /**
     * Initializes the data client
     * @returns Promise resolving to IRuntimeDataClient
     */
    private _initializeDataClient;
    /**
     * Initializes the metadata client
     * @returns Promise resolving to IRuntimeMetadataClient
     */
    private _initializeMetadataClient;
    /**
     * Resets both clients, forcing re-initialization on next use
     * Useful for testing or recovering from error states
     */
    reset(): void;
}
//# sourceMappingURL=runtimeClientProvider.d.ts.map
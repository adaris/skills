/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IAuthenticationProvider } from '../Types/Cli.types';
/**
 * note: This is meant for use in CI only since it hardcodes the authority & tenant ID.
 */
export declare class ServicePrincipalAuthenticationProvider implements IAuthenticationProvider {
    private _msalClient;
    private _clientId;
    private _clientSecret;
    private _tenantId;
    constructor();
    initAsync(): Promise<void>;
    getAccessTokenForResource(resource: string): Promise<string>;
    getUserTenantId(): string | undefined;
}
//# sourceMappingURL=ServicePrincipalAuthenticationProvider.d.ts.map
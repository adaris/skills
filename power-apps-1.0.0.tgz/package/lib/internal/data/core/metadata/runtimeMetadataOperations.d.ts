/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IRuntimeClientProvider } from '../common/types';
import { IConnectionApi, IConnectionReference, IMetadataOperations, IOperationContext } from '../common/types';
import { IOperationResult } from '../types';
/**
 * RuntimeMetadataOperations provides functionality for retrieving metadata
 * about connections and APIs.
 */
export declare class RuntimeMetadataOperations implements IMetadataOperations {
    private readonly _clientProvider;
    constructor(_clientProvider: IRuntimeClientProvider);
    getConnections(context?: IOperationContext): Promise<IOperationResult<IConnectionReference[]>>;
    getConnectionApis(_connectionId: string, context?: IOperationContext): Promise<IOperationResult<IConnectionApi[]>>;
}
//# sourceMappingURL=runtimeMetadataOperations.d.ts.map
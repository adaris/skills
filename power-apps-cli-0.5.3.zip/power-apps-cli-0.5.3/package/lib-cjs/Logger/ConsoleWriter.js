"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConsoleWriter = void 0;
var chalk_1 = __importDefault(require("chalk"));
/* eslint-disable @typescript-eslint/no-explicit-any */
// Logger function factory
function loggerFn(color, log) {
    if (log === void 0) { log = console.log.bind(console); }
    return function (scenarioName) {
        var data = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            data[_i - 1] = arguments[_i];
        }
        var time = new Date().toISOString().split('T')[1];
        var prefix = "".concat(chalk_1.default.gray(time), ": [").concat(color(scenarioName), "]: ");
        log.apply(void 0, __spreadArray([prefix], __read(data), false));
    };
}
var activity = loggerFn(chalk_1.default.white.bold);
var scenario = loggerFn(chalk_1.default.cyan.bold);
var error = loggerFn(chalk_1.default.red.bold, console.error.bind(console));
var warn = loggerFn(chalk_1.default.yellow.bold);
var ConsoleWriter = /** @class */ (function () {
    function ConsoleWriter() {
    }
    ConsoleWriter.prototype.trackActivityEvent = function (eventName, eventData) {
        activity(eventName, eventData || {});
    };
    ConsoleWriter.prototype.trackErrorEvent = function (eventName, eventData) {
        error(eventName, eventData || {});
    };
    ConsoleWriter.prototype.startScenario = function (scenarioName, startData) {
        scenario("[scenario:start] ".concat(scenarioName), startData || {});
    };
    ConsoleWriter.prototype.completeScenario = function (scenarioName, completeData) {
        scenario("[scenario:complete] ".concat(scenarioName), completeData || {});
    };
    ConsoleWriter.prototype.scenarioFailed = function (scenarioName, failureData) {
        error("[scenario:failure] ".concat(scenarioName), failureData || {});
    };
    ConsoleWriter.prototype.scenarioCompletedWithError = function (scenarioName, completeWithErrorData) {
        warn("[scenario:completeWithError] ".concat(scenarioName), completeWithErrorData || {});
    };
    ConsoleWriter.prototype.flush = function () {
        // No-op for console writer
    };
    ConsoleWriter.prototype.setCustomDimension = function (_key, _value) {
        // No-op for console writer
    };
    return ConsoleWriter;
}());
exports.ConsoleWriter = ConsoleWriter;
/* eslint-enable @typescript-eslint/no-explicit-any */
//# sourceMappingURL=ConsoleWriter.js.map
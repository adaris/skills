/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare const mockMSTeamsResponse: {
    success: boolean;
    data: (ArrayBuffer | {
        status: number;
        headers: {
            'client-request-id': string;
            'content-encoding': string;
            'Content-Type': string;
            Date: string;
            'odata-version': string;
            'Request-Id': string;
            'strict-transport-security': string;
            'timing-allow-origin': string;
            vary: string;
            'x-ms-ags-diagnostic': string;
            'x-ms-apihub-cached-response': string;
            'x-ms-apihub-obo': string;
            'x-ms-au-caller-id': string;
            'x-ms-au-creator-id': string;
            'x-ms-client-app-id': string;
            'x-ms-client-environment-id': string;
            'x-ms-client-object-id': string;
            'x-ms-client-region': string;
            'x-ms-client-session-id': string;
            'x-ms-client-tenant-id': string;
            'x-ms-dlp-ef': string;
            'x-ms-dlp-gu': string;
            'x-ms-dlp-re': string;
            'x-ms-environment-id': string;
            'x-ms-flavor': string;
            'x-ms-mip-sl': string;
            'x-ms-tenant-id': string;
            'x-ms-user-agent': string;
        };
        responseType: string;
        duration: number;
        responseSize: number;
        performanceInformation: {
            startTime: number;
            name: string;
            redirectStart: number;
            redirectEnd: number;
            fetchStart: number;
            domainLookupStart: number;
            domainLookupEnd: number;
            connectStart: number;
            connectEnd: number;
            secureConnectionStart: number;
            requestStart: number;
            responseStart: number;
            responseEnd: number;
            transferSize: number;
            nextHopProtocol: string;
        };
        sendHttpPipelinePerf: {
            sendHttpPipelinePerfTimestamps: {
                SendHttpCore: {
                    pipelineStart: number;
                    responseReceived: number;
                    pipelineEnd: number;
                };
                AppHttpClientPluginHandler: {
                    pipelineStart: number;
                    responseReceived: number;
                    pipelineEnd: number;
                };
            };
            transferSize: number;
            clientRequestId: string;
        };
    })[];
};
//# sourceMappingURL=mockTeamsConnectorResponse.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { DataSourcesInfo } from '../internal/data/core/types';
import { DataClient } from './Data.types';
export declare function initializeData(): void;
export declare function getClient(dataSourcesInfo: DataSourcesInfo): DataClient;
//# sourceMappingURL=powerAppsData.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare function getPerformanceData(): object;
//# sourceMappingURL=Performance.d.ts.map
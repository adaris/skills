/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IConnectionApi, IConnectionReference, IRuntimeMetadataClient } from '../common/types';
import { IOperationResult, IPowerOperationExecutor } from '../types';
/**
 * RuntimeMetadataClient handles metadata operations through PowerOperationExecutor
 */
export declare class RuntimeMetadataClient implements IRuntimeMetadataClient {
    private readonly _powerOperationExecutor;
    private static readonly SERVICES;
    private static readonly ACTIONS;
    constructor(_powerOperationExecutor: IPowerOperationExecutor);
    /**
     * Creates a new instance of RuntimeMetadataClient
     * @param powerOperationExecutor - The powerOperationExecutor instance
     * @returns Promise resolving to IRuntimeMetadataClient
     */
    static createInstanceAsync(powerOperationExecutor: IPowerOperationExecutor): Promise<RuntimeMetadataClient>;
    /**
     * Fetches app connection configurations
     * @returns Promise resolving to connection reference details
     * @throws Error if the operation fails
     */
    getAppConnectionConfigsAsync(): Promise<IOperationResult<IConnectionReference>>;
    /**
     * Fetches app data source configurations
     * @returns Promise resolving to connection reference details
     * @throws Error if the operation fails
     */
    getAppDataSourceConfigsAsync(): Promise<IOperationResult<IConnectionApi>>;
    /**
     * Executes a metadata operation with the given configuration
     * @param config - The operation configuration
     * @returns Promise resolving to the operation result
     * @throws Error if the operation fails
     */
    private _executeOperation;
}
//# sourceMappingURL=runtimeMetadataClient.d.ts.map
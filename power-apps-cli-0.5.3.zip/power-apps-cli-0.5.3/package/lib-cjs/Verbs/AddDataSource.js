"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addDataSourceAsync = void 0;
var prompts = __importStar(require("@clack/prompts"));
var CliUtils_1 = require("../CliUtils");
var CliSettings_1 = require("../CliSettings");
var AddDataSource_1 = require("@microsoft/powerapps-player-actions/lib/Actions/AddDataSource");
var powerapps_player_services_1 = require("@pa-client/powerapps-player-services");
var VerbConstants_1 = require("./VerbConstants");
var HelpStrings_1 = require("../Constants/HelpStrings");
/**
 * Adds a data source based on the provided environment variables.
 * It supports both Dataverse and connector data sources.
 * Expects the following environment variables:
 * - API_ID: The ID of the API (e.g., 'dataverse' or a connector ID)
 * - CONNECTION_ID?: The ID of the connection (for connector data sources)
 * - TABLE?: The table name for Dataverse or tabular connector data sources
 * - ENV_URL?: The environment URL for Dataverse data sources
 * - DATASET?: The dataset name for tabular/stored proc connector data sources
 * - SQL_STORED_PROCEDURE?: The name of the SQL stored procedure for connector data sources
 * @param config - Local file paths configuration
 * @returns Promise<void>
 */
function addDataSourceAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var settings, fileConfig, cliFs, playerServiceConfig, authenticationProvider, dsConfig;
        var _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    settings = (0, CliSettings_1.getSettings)();
                    fileConfig = settings.fileConfig, cliFs = settings.cliFs;
                    createOptionSchema(argumentProvider);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _c.sent();
                    playerServiceConfig = (0, powerapps_player_services_1.getPlayerServiceConfig)();
                    authenticationProvider = argumentProvider.getAuthenticationProvider();
                    _a = {
                        vfs: cliFs,
                        authProvider: authenticationProvider,
                        region: playerServiceConfig.region,
                        environmentName: playerServiceConfig.environmentName
                    };
                    _b = {};
                    return [4 /*yield*/, argumentProvider.getOption('apiId')];
                case 2:
                    _b.apiId = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('connectionId')];
                case 3:
                    _b.connectionId = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('resourceName')];
                case 4:
                    _b.tableName = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('dataset')];
                case 5:
                    _b.dataset = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('sqlStoredProcedure')];
                case 6:
                    _b.sqlStoredProcedure = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('envUrl')];
                case 7:
                    _b.envUrl = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('solutionId')];
                case 8:
                    _b.solutionId = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('connectionRef')];
                case 9:
                    dsConfig = (_a.actionsParams = (_b.connectionRef = _c.sent(),
                        _b),
                        _a.localFilePaths = {
                            powerConfigPath: fileConfig.powerConfigPath,
                            schemaPath: fileConfig.schemaPath,
                            codeGenPath: fileConfig.codeGenPath,
                        },
                        _a.logger = (0, CliSettings_1.getCliLogger)(),
                        _a);
                    return [4 /*yield*/, (0, AddDataSource_1.addDataSourceAsync)(dsConfig)];
                case 10:
                    _c.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.addDataSourceAsync = addDataSourceAsync;
function createOptionSchema(argumentProvider) {
    var _this = this;
    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Description);
    argumentProvider.addOptions([
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.ApiId.name,
                alias: VerbConstants_1.SharedArguments.ApiId.alias,
            },
            env: VerbConstants_1.SharedArguments.ApiId.envVar,
            message: VerbConstants_1.SharedArguments.ApiId.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.ApiId,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.ConnectionId.name,
                alias: VerbConstants_1.SharedArguments.ConnectionId.alias,
            },
            env: VerbConstants_1.SharedArguments.ConnectionId.envVar,
            message: VerbConstants_1.SharedArguments.ConnectionId.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.ConnectionId,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.AddDataSourceArguments.ConnectionRef.name,
                alias: VerbConstants_1.AddDataSourceArguments.ConnectionRef.alias,
            },
            env: VerbConstants_1.AddDataSourceArguments.ConnectionRef.envVar,
            message: VerbConstants_1.AddDataSourceArguments.ConnectionRef.promptMessage,
            default: '',
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.ConnectionRef,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.ResourceName.name,
                alias: VerbConstants_1.SharedArguments.ResourceName.alias,
            },
            env: VerbConstants_1.SharedArguments.ResourceName.envVar,
            message: VerbConstants_1.SharedArguments.ResourceName.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.ResourceName,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.Dataset.name,
                alias: VerbConstants_1.SharedArguments.Dataset.alias,
            },
            env: VerbConstants_1.SharedArguments.Dataset.envVar,
            message: VerbConstants_1.SharedArguments.Dataset.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.Dataset,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.EnvironmentUrl.name,
                alias: VerbConstants_1.SharedArguments.EnvironmentUrl.alias,
            },
            env: VerbConstants_1.SharedArguments.EnvironmentUrl.envVar,
            message: VerbConstants_1.SharedArguments.EnvironmentUrl.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.EnvUrl,
        }),
        {
            flags: {
                key: VerbConstants_1.SharedArguments.SqlStoredProcedure.name,
                alias: VerbConstants_1.SharedArguments.SqlStoredProcedure.alias,
            },
            env: VerbConstants_1.SharedArguments.SqlStoredProcedure.envVar,
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.SqlStoredProcedure,
            customPrompt: function () { return __awaiter(_this, void 0, void 0, function () {
                var hasSqlProcedure;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, prompts.confirm({
                                message: 'Are you trying to add an SQL stored procedure?',
                            })];
                        case 1:
                            hasSqlProcedure = _a.sent();
                            if (!hasSqlProcedure) return [3 /*break*/, 3];
                            return [4 /*yield*/, prompts.text({ message: VerbConstants_1.SharedArguments.SqlStoredProcedure.promptMessage })];
                        case 2: return [2 /*return*/, _a.sent()];
                        case 3: return [2 /*return*/, ''];
                    }
                });
            }); },
        },
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.SolutionId.name,
                alias: VerbConstants_1.SharedArguments.SolutionId.alias,
            },
            env: VerbConstants_1.SharedArguments.SolutionId.envVar,
            message: VerbConstants_1.SharedArguments.SolutionId.promptMessage,
            default: '',
            description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options.SolutionId,
        }),
    ]);
}
//# sourceMappingURL=AddDataSource.js.map
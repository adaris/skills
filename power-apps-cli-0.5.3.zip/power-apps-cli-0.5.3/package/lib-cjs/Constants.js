"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.USER_SETTINGS_FILE = exports.MS_CLIENT_REQUESTID = exports.AUTH_CACHE_DIRECTORY = exports.CLI_CONFIG_DIRECTORY = exports.WORKING_DIRECTORY = exports.APP_CONFIG_FILE = void 0;
var os = __importStar(require("os"));
var path = __importStar(require("path"));
exports.APP_CONFIG_FILE = 'power.config.json';
exports.WORKING_DIRECTORY = process.env.WORKING_DIRECTORY || process.cwd();
exports.CLI_CONFIG_DIRECTORY = path.join(os.homedir(), '.powerapps-cli');
exports.AUTH_CACHE_DIRECTORY = path.join(exports.CLI_CONFIG_DIRECTORY, 'cache', 'auth');
exports.MS_CLIENT_REQUESTID = 'x-ms-client-request-id';
exports.USER_SETTINGS_FILE = 'userSettings.json';
//# sourceMappingURL=Constants.js.map
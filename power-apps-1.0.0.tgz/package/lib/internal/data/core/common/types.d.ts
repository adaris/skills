/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { DataSourcesInfo, IOperationResult } from '../types';
/**
 * Base interface for operation context
 */
export interface IOperationContext {
    isExecuteAsync?: boolean;
    clientConfig?: IClientConfig;
    operationName?: string;
    correlationId?: string;
    timestamp?: Date;
    responseInfo?: Record<string, IApiResponseInfo>;
    batchId?: string;
    datasetName?: string;
    isDataVerseOperation?: boolean;
}
export interface IApiResponseInfo {
    type?: string | null;
    format?: string | null;
}
/**
 * Base interface for client configuration
 */
export interface IClientConfig {
    baseUrl?: string;
    timeout?: number;
    retryAttempts?: number;
}
/**
 * Interface for HTTP request configuration
 */
export interface IHttpRequestConfig {
    url: string;
    method: HttpMethod;
    apiId: string;
    tableName: string;
    headers?: {
        [key: string]: string;
    };
    body?: string;
}
/**
 * Interface for HTTP request headers
 */
export interface IHttpHeaders {
    Accept: string;
    'x-ms-protocol-semantics': string;
    ServiceNamespace: string;
    Authorization: string;
    'x-ms-pa-client-custom-headers-options': string;
    'x-ms-enable-selects': string;
    'x-ms-pa-client-telemetry-options': string;
    'x-ms-pa-client-telemetry-additional-data': string;
    BatchInfo?: string;
}
/**
 * HTTP methods supported by the client
 */
export declare enum HttpMethod {
    GET = "GET",
    POST = "POST",
    PUT = "PUT",
    DELETE = "DELETE",
    PATCH = "PATCH"
}
/**
 * Interface for OData response format
 * @template T The type of data in the response
 */
export interface ODataResponse<T> {
    '@odata.context'?: string;
    value: T;
}
/**
 * Interface for metadata operation configuration
 */
export interface IMetadataOperationConfig {
    service: string;
    action: string;
    params?: unknown[];
}
/**
 * Interface for operation execution result
 */
export type OperationExecutionResponse = [Record<string, object>, ArrayBuffer];
/**
 * Type alias for possible response data formats
 */
export type ResponseData = Record<string, unknown> | ArrayBuffer;
/**
 * Type alias for request body in data operations
 */
export type RequestBody = Record<string, unknown>;
/**
 * Interface for API definition details
 */
export interface IApiDefinition {
    path: string;
    method: string;
    parameters: Array<{
        name: string;
        in: string;
        required: boolean;
        type: string;
    }>;
}
/**
 * Interface for connection API details
 */
export interface IConnectionApi {
    path: string;
    method?: string;
    parameters?: string[];
}
/**
 * Interface for connection reference details
 */
export interface IConnectionReference {
    apiId?: string;
    connectionName?: string;
    datasetName?: string;
    datasetNameOverride?: string;
    isShareableConnection?: string;
    runtimePolicyName?: string;
    runtimeUrl?: string;
}
/**
 * Interface for table schema information
 */
export interface ITableSchema {
    name: string;
    displayName?: string;
    fields: Record<string, IFieldSchema>;
}
/**
 * Interface for field schema information
 */
export interface IFieldSchema {
    name: string;
    type: string;
    required?: boolean;
    maxLength?: number;
    defaultValue?: unknown;
}
/**
 * Interface for Dataverse-specific requests
 */
export interface IDataverseRequest {
    /** HTTP method for the request */
    method: string;
    /** Request path */
    path: string;
    /** Optional request headers */
    headers?: Record<string, string>;
    /** Optional request body */
    body?: unknown;
}
/**
 * Supported data source types in the PowerDataRuntime
 */
export declare enum DataSources {
    /** Dataverse data source */
    Dataverse = "Dataverse",
    /** Generic connector data source */
    Connector = "Connector"
}
/**
 * Interface for metadata operations
 */
export interface IMetadataOperations {
    /**
     * Gets available connections
     */
    getConnections(context?: IOperationContext): Promise<IOperationResult<IConnectionReference[]>>;
    /**
     * Gets APIs available for a connection
     */
    getConnectionApis(connectionId: string, context?: IOperationContext): Promise<IOperationResult<IConnectionApi[]>>;
}
/**
 * Interface for runtime client provider
 */
export interface IRuntimeClientProvider {
    getDataClientAsync(config?: IClientConfig): Promise<IRuntimeDataClient>;
    getMetadataClientAsync(config?: IClientConfig): Promise<IRuntimeMetadataClient>;
}
/**
 * Interface for runtime data client
 */
export interface IRuntimeDataClient {
    createDataAsync<TRequest, TResponse>(url: string, connectionApi: string, serviceNamespace: string, body: TRequest, context?: IOperationContext): Promise<IOperationResult<TResponse>>;
    updateDataAsync<TRequest, TResponse>(url: string, connectionApi: string, serviceNamespace: string, body: TRequest, context?: IOperationContext): Promise<IOperationResult<TResponse>>;
    deleteDataAsync(url: string, connectionApi: string, serviceNamespace: string, context?: IOperationContext): Promise<IOperationResult<void>>;
    retrieveDataAsync<TResponse>(url: string, connectionApi: string, serviceNamespace: string, method: HttpMethod, headers?: {
        [key: string]: string;
    }, body?: unknown, context?: IOperationContext): Promise<IOperationResult<TResponse>>;
}
/**
 * Interface for runtime metadata client
 */
export interface IRuntimeMetadataClient {
    getAppConnectionConfigsAsync(context?: IOperationContext): Promise<IOperationResult<IConnectionReference>>;
    getAppDataSourceConfigsAsync(context?: IOperationContext): Promise<IOperationResult<IConnectionApi>>;
}
/**
 * Interface for PowerDataSourcesInfoProvider
 */
export interface IPowerDataSourcesInfoProvider {
    getDataSourcesInfo(): Promise<DataSourcesInfo>;
}
/**
 * Interface defining the XRM context shape
 */
export interface IXrmContext {
    context: {
        getClientUrl(): string;
        getVersion(): string;
    };
    WebApi: {
        createRecord<TRequest, TResponse>(entityLogicalName: string, data: TRequest): Promise<TResponse>;
        updateRecord<TRequest, TResponse>(entityLogicalName: string, id: string, data: Partial<TRequest>): Promise<TResponse>;
        deleteRecord(entityLogicalName: string, id: string): Promise<void>;
        retrieveRecord<TResponse>(entityLogicalName: string, id: string, options?: string): Promise<TResponse>;
        retrieveMultipleRecords<TResponse>(entityLogicalName: string, options?: string, maxPageSize?: number): Promise<TResponse>;
        execute<TRequest, TResponse>(request: TRequest): Promise<TResponse>;
    };
}
//# sourceMappingURL=types.d.ts.map
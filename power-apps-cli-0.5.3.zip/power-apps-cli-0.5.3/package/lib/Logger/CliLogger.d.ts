/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IHttpClient } from '@pa-client/powerapps-player-services';
import { ILogger, Scenario } from '@pa-client/powerapps-player-services/lib/Types/PlayerServices.types';
import { CliSettings, IAuthenticationProvider } from '../Types/Cli.types';
/**
 * Logger implementation for the CLI
 * The logger depends on the CLISettings, HttpClient and authenticationProvider to initialize the OneDS writer
 */
export declare class CliLogger implements ILogger {
    private _telemetryWriters;
    private constructor();
    static create(cliSettings: CliSettings, httpClient: IHttpClient, authenticationProvider: IAuthenticationProvider): Promise<CliLogger>;
    setCustomDimension(_key: string, _value: string): void;
    trackActivityEvent(eventName: string, eventData?: object): void;
    trackErrorEvent(eventName: string, eventData?: object): void;
    trackScenario(eventName: string, eventData?: object): Scenario;
    stringifyError(err: unknown): string | null | undefined;
    flush(): Promise<void>;
}
//# sourceMappingURL=CliLogger.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare const mockDataverseResponse: {
    success: boolean;
    data: (ArrayBuffer | {
        status: number;
        headers: {
            allow: string;
            authactivityid: string;
            'cache-control': string;
            'content-encoding': string;
            'Content-Type': string;
        };
    })[];
};
//# sourceMappingURL=mockDataverseRetrieveMultipleResponse.d.ts.map
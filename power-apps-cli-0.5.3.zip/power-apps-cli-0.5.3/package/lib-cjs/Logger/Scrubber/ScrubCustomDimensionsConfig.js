"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsToScrubConfig = void 0;
var ScrubUtils_1 = require("./ScrubUtils");
var EmailScrubConfig = {
    scrubberName: 'email',
    shouldScrubValue: ScrubUtils_1.containsEmail,
};
var GoogleApiKeyScrubConfig = {
    scrubberName: 'googleApiKey',
    shouldScrubValue: ScrubUtils_1.containsGoogleApiKey,
};
var SasKeySigScrubConfig = {
    scrubberName: 'sasKeySig',
    shouldScrubValue: ScrubUtils_1.containsSasKeySig,
};
var SymmKey256ScrubConfig = {
    scrubberName: 'symmKey256',
    shouldScrubValue: ScrubUtils_1.containsSymmKey256,
};
/** A scrub config list for handling events with sas keys. Currently this just scrubs the sig */
var SasKeyScrubConfigList = [SasKeySigScrubConfig];
/**
 * This configuration is a mapping of Record<event_Name, EventConfig>
 */
exports.EventsToScrubConfig = {
    'AppHostClientSDK.getCanvasAppMetadataAsync': {
        '*': SasKeyScrubConfigList,
    },
    'AppModuleMetadataProvider.getCanvasAppMetadataAsync.Failure': {
        '*': SasKeyScrubConfigList,
    },
    'AppModuleMetadataProvider.getRootAppMetadataAsync.Failure': {
        '*': SasKeyScrubConfigList,
    },
    CustomPageInlineRendering: {
        '*': SasKeyScrubConfigList,
    },
    'DefaultCanvasAppContainer.renderAsync': {
        '*': SasKeyScrubConfigList,
    },
    'FilePluginService.GetFileOrDirectory': {
        '*': SasKeyScrubConfigList,
    },
    'Player.CanvasAppGlue.openErrorDialog': {
        '*': SasKeyScrubConfigList,
    },
    'PlayerCordovaPlugin.onPluginRequestFailure': {
        '*': SasKeyScrubConfigList,
    },
    'PowerAppsClient.Activity': {
        operations: {
            'App.disposeAsync': SasKeyScrubConfigList,
            'GlobalControlProperty.setModelValueInternal': SasKeyScrubConfigList,
            'IDataRuntime.reportRuntimeError': SasKeyScrubConfigList,
            'IDataRuntime.tryCreateGatedReportRuntimeError': [GoogleApiKeyScrubConfig, SasKeySigScrubConfig],
            'PassThroughWebUriResolver.getAsBinaryAsync': SasKeyScrubConfigList,
            'PerEndpointRetryPipeline._xhrWithRetryAsync': SasKeyScrubConfigList,
            'Player.AppCatalog.GetAppDetailByIDSuccess': SasKeyScrubConfigList,
            'Player.CanvasAppGlue.exitAppHost': SasKeyScrubConfigList,
            'Player.CustomBranding.RPResponse': SasKeyScrubConfigList,
            'Player.CustomBranding.Save': SasKeyScrubConfigList,
            'Player.PublishedApp.Open.AppInfo': SasKeyScrubConfigList,
            'Player.PublishedApp.WebServer.Start': SasKeyScrubConfigList,
            'PlayerLifecycle.WebPlayer.Play.ErrorPage': SasKeyScrubConfigList,
            'PowerAppsClient.PcfComponent.Failure': SasKeyScrubConfigList,
            'PowerAppsClient.Performance.PerformanceObserver': SasKeyScrubConfigList,
            'PowerAppsEmbedding.Automation.Player': SasKeyScrubConfigList,
            'CachedQueryDataProvider._onDataDownloaded': [EmailScrubConfig],
            'CachedQueryDataProvider._getDataForExpiredCacheAsync': [EmailScrubConfig],
        },
    },
    'PowerAppsClient.AllApps.App.DismissedWithError': {
        '*': SasKeyScrubConfigList,
    },
    'PowerAppsClient.App.GalleryPagingManagerError': {
        '*': SasKeyScrubConfigList,
    },
    'PowerAppsClient.ControlsActivity': {
        operations: {
            'Attachments.OnView': SasKeyScrubConfigList,
        },
    },
    'PowerAppsClient.EndScenario': {
        scenarios: {
            'PowerAppsClient.Scenario.ContextLoadApp': SasKeyScrubConfigList,
            'PowerAppsClient.Scenario.DocumentVmInitialize': SasKeyScrubConfigList,
            'PowerAppsClient.Scenario.ScreenCreation': SasKeyScrubConfigList,
            'PlayerLifecycle.PlayerSDK.PlayApp.LoadApp.CreateAppFrame': SasKeyScrubConfigList,
            'PlayerLifecycle.PlayerSDK.PlayApp.LoadApp': SasKeyScrubConfigList,
            'PlayerLifecycle.PlayerSDK.PlayApp.LoadMetadata.FetchAppPackageMetadata': SasKeyScrubConfigList,
            'PlayerLifecycle.PlayerSDK.PlayApp': SasKeyScrubConfigList,
            'PlayerLifecycle.WebPlayer.Play.PlayApp': SasKeyScrubConfigList,
            'PlayerLifecycle.WebPlayer.Play': SasKeyScrubConfigList,
            'PowerAppsClient.Scenario.CachedQueryDataProviderNotify': [EmailScrubConfig],
        },
    },
    'PowerAppsClient.Error': {
        operations: {
            'AppInfoParser.parseAppInfo': SasKeyScrubConfigList,
            'AppLifecyclePlugin.notifyAppFailed': SasKeyScrubConfigList,
            'AttachmentsView._viewItem': SasKeyScrubConfigList,
            'BaseWebPlayerHost._onAppFailure': SasKeyScrubConfigList,
            'Context.loadAppAsync': SasKeyScrubConfigList,
            'DocumentViewModel.initializeAsync': SasKeyScrubConfigList,
            'GeneratedCode.ReportAndContinue': SasKeyScrubConfigList,
            'MediaRuntime.getMediaAsBinaryAsync': SasKeyScrubConfigList,
            'NestedAppModuleMetadataProvider.getCanvasAppMetadataAsync.Failure': SasKeyScrubConfigList,
            'Player.SessionSummary.Failure': SasKeyScrubConfigList,
            'PlayerLaunchService.playerLaunchAppAsync': SasKeyScrubConfigList,
            'PlayerPublishedApp._onInitializationError': SasKeyScrubConfigList,
            'PowerAppsClient.PublishedApp.ErrorLoadingScript': SasKeyScrubConfigList,
            'PublishedAppHostActions.handleErrorDuringInstall': SasKeyScrubConfigList,
            'PublishedAppInstance.runAllScreensInitFnsAsync': SasKeyScrubConfigList,
            'RNSendHttpPipeline._performXhrRequestAsync': [SymmKey256ScrubConfig],
            'RequirementsManager.loadRequirement': SasKeyScrubConfigList,
            'runtimebase._onCallFailed': SasKeyScrubConfigList,
            'Text._validateTextWithCharacters': SasKeyScrubConfigList,
            'Url.constructor': SasKeyScrubConfigList,
        },
    },
    'PowerAppsClient.Functions.InternalError': {
        '*': SasKeyScrubConfigList,
    },
    'PowerAppsClient.MessageDialog.Dismissed': {
        operations: {
            'Studio.Reducers.STUDIO_UPDATE_CONNECTION_TABLES_LOADING_ERROR_INFO': SasKeyScrubConfigList,
        },
    },
    'PowerAppsClient.MessageDialog.ShowAsync': {
        operations: {
            'Studio.Reducers.STUDIO_UPDATE_CONNECTION_TABLES_LOADING_ERROR_INFO': SasKeyScrubConfigList,
        },
    },
    'PowerAppsClient.StartScenario': {
        scenarios: {
            'PowerAppsClient.Scenario.CachedQueryDataProviderNotify': [EmailScrubConfig],
        },
    },
    'PowerAppsClient.Verbose': {
        operations: {
            'ReactRedux.HandleActionsWithReset': SasKeyScrubConfigList,
        },
    },
    'PowerAppsClient.WebPlayer.Load': {
        operations: {
            'PowerAppsClient._notifyAppFailed': SasKeyScrubConfigList,
            'PowerAppsClient.AppDetailsRetriever._getAppDetailsInternal.Failure': SasKeyScrubConfigList,
            'PowerAppsClient.ResourcePathResolution': SasKeyScrubConfigList,
        },
    },
    'PublishedAppLoader.ScriptError': {
        operations: {
            'GlobalErrorHandler:UnhandledError': SasKeyScrubConfigList,
            'PowerAppsClient.AppDetailsRetriever._getAppDetailsInternal.Failure': SasKeyScrubConfigList,
        },
    },
    'RuntimeTelemetry.logException': {
        '*': SasKeyScrubConfigList,
    },
    'TestOrchestrator.setupTestsAsync': {
        '*': SasKeyScrubConfigList,
    },
};
//# sourceMappingURL=ScrubCustomDimensionsConfig.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { Response as HttpClientResponse, IHttpClient, RequestConfig } from '@pa-client/powerapps-player-services/lib/Types/IHttpClient';
import { IAuthenticationProvider } from '../Types/Cli.types';
export declare class CliHttpClient implements IHttpClient {
    private _authenticationProvider;
    constructor(_authenticationProvider: IAuthenticationProvider);
    get<T = unknown>(url: string, config?: RequestConfig): Promise<HttpClientResponse<T>>;
    post<T = unknown>(url: string, config?: RequestConfig): Promise<HttpClientResponse<T>>;
    patch<T = unknown>(url: string, config?: RequestConfig): Promise<HttpClientResponse<T>>;
    put<T = unknown>(url: string, config?: RequestConfig): Promise<HttpClientResponse<T>>;
    private _sendRequestAsync;
    private _parseResponse;
    private _transformHeaders;
}

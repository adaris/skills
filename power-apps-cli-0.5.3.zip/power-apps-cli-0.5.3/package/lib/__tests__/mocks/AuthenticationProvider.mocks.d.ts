/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IAuthenticationProvider } from '../../Types/Cli.types';
export declare function getMockAuthenticationProvider(): IAuthenticationProvider;
//# sourceMappingURL=AuthenticationProvider.mocks.d.ts.map
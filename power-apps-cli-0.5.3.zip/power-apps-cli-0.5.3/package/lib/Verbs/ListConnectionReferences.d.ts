/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function listConnectionReferences(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=ListConnectionReferences.d.ts.map
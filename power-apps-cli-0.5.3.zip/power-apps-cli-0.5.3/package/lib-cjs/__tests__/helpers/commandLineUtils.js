"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyCanRunNPM = exports.runNpxCommandInDirectory = exports.runNpmCommandInDirectory = exports.runCliCommandAllowFailure = exports.runCliCommand = exports.formatCliInvocation = exports.DEFAULT_COMMAND_TIMEOUT_MS = exports.DEFAULT_COMMAND_MAX_BUFFER = exports.testDir = void 0;
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var child_process_1 = require("child_process");
var path = __importStar(require("path"));
var process_1 = __importDefault(require("process"));
// Get current directory for test files - use process.cwd() and resolve to this file's directory
exports.testDir = path.resolve(process_1.default.cwd(), 'src', '__tests__');
var DEFAULT_COMMAND_TIMEOUT_MS = 300000;
exports.DEFAULT_COMMAND_TIMEOUT_MS = DEFAULT_COMMAND_TIMEOUT_MS;
var DEFAULT_COMMAND_MAX_BUFFER = 10 * 1024 * 1024;
exports.DEFAULT_COMMAND_MAX_BUFFER = DEFAULT_COMMAND_MAX_BUFFER;
// Store the npm executable path once verified
var npmPath = null;
/**
 * Runs an npm command in a specific directory
 * @param {string[]} args - The npm command to run (without 'npm' prefix)
 * @param {CommandOptions} [options={}] - Options for running the command
 * @returns {Promise<string>} - Promise resolving with command output
 */
function runNpmCommandInDirectory(args, options) {
    if (options === void 0) { options = {}; }
    return __awaiter(this, void 0, void 0, function () {
        var workingDirectory, _a, timeout, cwd, command, result, stderr, stdout_1, stdout, errorMessage;
        return __generator(this, function (_b) {
            workingDirectory = options.workingDirectory, _a = options.timeout, timeout = _a === void 0 ? 60000 : _a;
            if (!npmPath) {
                verifyCanRunNPM();
                if (!npmPath) {
                    throw new Error('NPM path not initialized. Call verifyCanRunNPM() first.');
                }
            }
            cwd = workingDirectory ? path.resolve(workingDirectory) : exports.testDir;
            try {
                command = "".concat(npmPath, " ").concat(args.join(' '));
                result = (0, child_process_1.spawnSync)(command, {
                    cwd: cwd,
                    timeout: timeout,
                    encoding: 'utf-8',
                    shell: true,
                    stdio: 'pipe',
                });
                if (result === null || result === void 0 ? void 0 : result.error) {
                    throw result.error;
                }
                if ((result === null || result === void 0 ? void 0 : result.status) !== 0) {
                    stderr = result.stderr ? result.stderr.toString().trim() : '';
                    stdout_1 = result.stdout ? result.stdout.toString().trim() : '';
                    throw new Error(stderr || stdout_1 || 'npm command failed');
                }
                stdout = (result === null || result === void 0 ? void 0 : result.stdout) ? result.stdout.toString().trim() : '';
                return [2 /*return*/, stdout];
            }
            catch (error) {
                errorMessage = error.message;
                throw new Error(errorMessage);
            }
            return [2 /*return*/];
        });
    });
}
exports.runNpmCommandInDirectory = runNpmCommandInDirectory;
/**
 * Runs an npx command in a specific directory
 * @param {string[]} args - The npx command to run (without 'npx' prefix)
 * @param {CommandOptions} [options={}] - Options for running the command
 * @returns {Promise<string>} - Promise resolving with command output
 */
function runNpxCommandInDirectory(args, options) {
    if (options === void 0) { options = {}; }
    return __awaiter(this, void 0, void 0, function () {
        var workingDirectory, _a, timeout, cwd, command, result, stderr, stdout_2, stdout, errorMessage;
        return __generator(this, function (_b) {
            workingDirectory = options.workingDirectory, _a = options.timeout, timeout = _a === void 0 ? 60000 : _a;
            cwd = workingDirectory ? path.resolve(workingDirectory) : exports.testDir;
            try {
                command = "npx ".concat(args.join(' '));
                result = (0, child_process_1.spawnSync)(command, {
                    cwd: cwd,
                    timeout: timeout,
                    encoding: 'utf-8',
                    shell: true,
                    stdio: 'pipe',
                });
                if (result.error) {
                    throw result.error;
                }
                if (result.status !== 0) {
                    stderr = result.stderr ? result.stderr.toString().trim() : '';
                    stdout_2 = result.stdout ? result.stdout.toString().trim() : '';
                    throw new Error(stderr || stdout_2 || 'npx command failed');
                }
                stdout = result.stdout ? result.stdout.toString().trim() : '';
                return [2 /*return*/, stdout];
            }
            catch (error) {
                errorMessage = error.message;
                throw new Error(errorMessage);
            }
            return [2 /*return*/];
        });
    });
}
exports.runNpxCommandInDirectory = runNpxCommandInDirectory;
function verifyCanRunNPM() {
    try {
        // Try different approaches for Windows
        if (process_1.default.platform === 'win32') {
            // Method 1: Try with shell option
            try {
                var result = (0, child_process_1.spawnSync)('npm', ['--version'], {
                    shell: true,
                    timeout: 10000,
                    encoding: 'utf8',
                });
                if (result.status === 0) {
                    npmPath = 'npm';
                    return true;
                }
            }
            catch (_a) {
                // Continue to next method
            }
            // Method 2: Try npm.cmd directly
            try {
                var result = (0, child_process_1.spawnSync)('npm.cmd', ['--version'], { timeout: 10000, encoding: 'utf8' });
                if (result.status === 0 && !result.error) {
                    npmPath = 'npm.cmd';
                    return true;
                }
            }
            catch (_b) {
                // Continue to next method
            }
            // Method 3: Try with full path
            try {
                var fullPath = 'C:\\Program Files\\nodejs\\npm.cmd';
                var result = (0, child_process_1.spawnSync)(fullPath, ['--version'], { timeout: 10000, encoding: 'utf8' });
                if (result.status === 0 && !result.error) {
                    npmPath = fullPath;
                    return true;
                }
            }
            catch (_c) {
                // Continue
            }
        }
        else {
            // Non-Windows platforms
            var result = (0, child_process_1.spawnSync)('npm', ['--version'], { timeout: 10000, encoding: 'utf8' });
            if (result.status === 0 && !result.error) {
                npmPath = 'npm';
                return true;
            }
        }
    }
    catch (e) {
        console.log('NPM is not available in the current environment.', e);
    }
    return false;
}
exports.verifyCanRunNPM = verifyCanRunNPM;
function formatCliInvocation(cliPath, verb, args) {
    if (args === void 0) { args = []; }
    var quotedArgs = __spreadArray([cliPath, verb], __read(args), false).map(function (value) {
        return /\s/.test(value) ? "\"".concat(value.replace(/"/g, '\\"'), "\"") : value;
    });
    return "node ".concat(quotedArgs.join(' '));
}
exports.formatCliInvocation = formatCliInvocation;
/**
 * Executes a CLI command and returns the result along with the stdout and stderr.
 *
 * @param options - The CLI command options containing execution parameters
 * @param options.cliPath - The path to the CLI executable
 * @param options.verb - The CLI verb/command to execute
 * @param options.cwd - The current working directory for the command execution
 * @param options.args - Optional array of command-line arguments (defaults to empty array)
 * @param options.env - Optional environment variables to merge with process.env
 * @param options.timeoutMs - Optional timeout in milliseconds (defaults to DEFAULT_COMMAND_TIMEOUT_MS)
 * @param options.maxBuffer - Optional maximum buffer size (defaults to DEFAULT_COMMAND_MAX_BUFFER)
 * @returns A {@link CliCommandResult} object containing stdout, stderr, the formatted invocation command
 */
function runCliCommand(options) {
    var _a, _b;
    var cliPath = options.cliPath, verb = options.verb, cwd = options.cwd, _c = options.args, args = _c === void 0 ? [] : _c, env = options.env, timeoutMs = options.timeoutMs, maxBuffer = options.maxBuffer;
    var invocation = formatCliInvocation(cliPath, verb, args);
    // Set environment variables to disable TTY features
    var testEnv = __assign(__assign(__assign({}, process_1.default.env), env), { CI: 'true', NO_COLOR: '1', FORCE_COLOR: '0', NODE_ENV: 'test', TERM: 'dumb', FORCE_TTY: '0' });
    var command = formatCliInvocation(cliPath, verb, args);
    var result = (0, child_process_1.spawnSync)(command, {
        cwd: cwd,
        env: testEnv,
        encoding: 'utf-8',
        stdio: 'pipe',
        shell: true,
        timeout: timeoutMs !== null && timeoutMs !== void 0 ? timeoutMs : DEFAULT_COMMAND_TIMEOUT_MS,
        maxBuffer: maxBuffer !== null && maxBuffer !== void 0 ? maxBuffer : DEFAULT_COMMAND_MAX_BUFFER,
    });
    if (result.error) {
        throw result.error;
    }
    if (result.status !== 0) {
        throw new Error("CLI command '".concat(invocation, "' failed with exit code ").concat(result.status, ".\nSTDOUT:\n").concat(result.stdout, "\nSTDERR:\n").concat(result.stderr));
    }
    return {
        stdout: (_a = result.stdout) !== null && _a !== void 0 ? _a : '',
        stderr: (_b = result.stderr) !== null && _b !== void 0 ? _b : '',
        command: invocation,
    };
}
exports.runCliCommand = runCliCommand;
/**
 * Executes a CLI command and returns the result along with the exit code, allowing for command failures.
 *
 * @param options - The CLI command options containing execution parameters
 * @param options.cliPath - The path to the CLI executable
 * @param options.verb - The CLI verb/command to execute
 * @param options.cwd - The current working directory for the command execution
 * @param options.args - Optional array of command-line arguments (defaults to empty array)
 * @param options.env - Optional environment variables to merge with process.env
 * @param options.timeoutMs - Optional timeout in milliseconds (defaults to DEFAULT_COMMAND_TIMEOUT_MS)
 * @param options.maxBuffer - Optional maximum buffer size (defaults to DEFAULT_COMMAND_MAX_BUFFER)
 * @returns A {@link CliCommandResultWithExitCode} object containing stdout, stderr, the formatted invocation command, and the exit code
 */
function runCliCommandAllowFailure(options) {
    var _a, _b;
    var cliPath = options.cliPath, verb = options.verb, cwd = options.cwd, _c = options.args, args = _c === void 0 ? [] : _c, env = options.env, timeoutMs = options.timeoutMs, maxBuffer = options.maxBuffer;
    var invocation = formatCliInvocation(cliPath, verb, args);
    var testEnv = __assign(__assign(__assign({}, process_1.default.env), env), { CI: 'true', NO_COLOR: '1', FORCE_COLOR: '0', NODE_ENV: 'test', TERM: 'dumb', FORCE_TTY: '0' });
    var quote = function (str) { return "\"".concat(str, "\""); };
    var command = __spreadArray([quote(process_1.default.execPath), quote(cliPath), verb], __read(args), false).join(' ');
    var result = (0, child_process_1.spawnSync)(command, {
        cwd: cwd,
        env: testEnv,
        encoding: 'utf-8',
        stdio: 'pipe',
        shell: true,
        timeout: timeoutMs !== null && timeoutMs !== void 0 ? timeoutMs : DEFAULT_COMMAND_TIMEOUT_MS,
        maxBuffer: maxBuffer !== null && maxBuffer !== void 0 ? maxBuffer : DEFAULT_COMMAND_MAX_BUFFER,
    });
    return {
        stdout: (_a = result.stdout) !== null && _a !== void 0 ? _a : '',
        stderr: (_b = result.stderr) !== null && _b !== void 0 ? _b : '',
        command: invocation,
        exitCode: result.status !== null ? result.status : result.signal ? "signal: ".concat(result.signal) : -1,
    };
}
exports.runCliCommandAllowFailure = runCliCommandAllowFailure;
//# sourceMappingURL=commandLineUtils.js.map
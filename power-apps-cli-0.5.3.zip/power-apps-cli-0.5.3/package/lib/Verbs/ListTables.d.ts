/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function listTablesAsync(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=ListTables.d.ts.map
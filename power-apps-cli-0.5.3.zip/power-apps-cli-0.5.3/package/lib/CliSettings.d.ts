/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { CliSettings, LocalFilePaths } from './Types/Cli.types';
import { ILogger } from '@pa-client/powerapps-player-services';
/**
 *
 * @param {boolean} [skipInteractivePrompts=false] - Whether the argument provider should skip interactive prompts
 * @param {LocalFilePaths} [fileConfig={
 *     powerConfigPath: `${WORKING_DIRECTORY}/${APP_CONFIG_FILE}`,
 *     schemaPath: `${WORKING_DIRECTORY}/.power/schemas`,
 *     codeGenPath: `${WORKING_DIRECTORY}/src`,
 *   }]
 * @param {ILogger} logger
 */
export declare function initializeCliSettings(skipInteractivePrompts?: boolean, fileConfig?: LocalFilePaths): Promise<CliSettings>;
export declare function setCliLogger(logger: ILogger): void;
export declare function getCliLogger(): ILogger;
export declare function getSettings(): CliSettings;
//# sourceMappingURL=CliSettings.d.ts.map
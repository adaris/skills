"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteDataSourceAsync = void 0;
var prompts = __importStar(require("@clack/prompts"));
var DeleteDataSource_1 = require("@microsoft/powerapps-player-actions/lib/Actions/DeleteDataSource");
var powerapps_player_services_1 = require("@pa-client/powerapps-player-services");
var CliSettings_1 = require("../CliSettings");
var CliUtils_1 = require("../CliUtils");
var VerbConstants_1 = require("./VerbConstants");
var HelpStrings_1 = require("../Constants/HelpStrings");
function deleteDataSourceAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var settings, fileConfig, cliFs, playerServiceConfig, authenticationProvider, config;
        var _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    settings = (0, CliSettings_1.getSettings)();
                    fileConfig = settings.fileConfig, cliFs = settings.cliFs;
                    createOptionSchema(argumentProvider);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _c.sent();
                    playerServiceConfig = (0, powerapps_player_services_1.getPlayerServiceConfig)();
                    authenticationProvider = argumentProvider.getAuthenticationProvider();
                    _a = {
                        vfs: cliFs,
                        authProvider: authenticationProvider,
                        region: playerServiceConfig.region,
                        environmentName: playerServiceConfig.environmentName,
                        localFilePaths: fileConfig
                    };
                    _b = {};
                    return [4 /*yield*/, argumentProvider.getOption('apiId')];
                case 2:
                    _b.apiId = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('dataSourceName')];
                case 3:
                    _b.dataSourceName = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('sqlStoredProcedure')];
                case 4:
                    config = (_a.actionsParams = (_b.sqlStoredProcedure = _c.sent(),
                        _b),
                        _a.logger = (0, CliSettings_1.getCliLogger)(),
                        _a);
                    return [2 /*return*/, (0, DeleteDataSource_1.deleteDataSourceAsync)(config)];
            }
        });
    });
}
exports.deleteDataSourceAsync = deleteDataSourceAsync;
function createOptionSchema(argumentProvider) {
    var _this = this;
    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs['Delete-data-source'].Description);
    argumentProvider.addOptions([
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.DeleteDataSourceArguments.DataSourceName.name,
                alias: VerbConstants_1.DeleteDataSourceArguments.DataSourceName.alias,
            },
            env: VerbConstants_1.DeleteDataSourceArguments.DataSourceName.envVar
                ? VerbConstants_1.DeleteDataSourceArguments.DataSourceName.envVar
                : VerbConstants_1.SharedArguments.ResourceName.envVar,
            message: VerbConstants_1.DeleteDataSourceArguments.DataSourceName.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['Delete-data-source'].Options.DataSourceName,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.ApiId.name,
                alias: VerbConstants_1.SharedArguments.ApiId.alias,
            },
            env: VerbConstants_1.SharedArguments.ApiId.envVar,
            message: VerbConstants_1.SharedArguments.ApiId.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['Delete-data-source'].Options.ApiId,
        }),
        {
            flags: {
                key: VerbConstants_1.SharedArguments.SqlStoredProcedure.name,
                alias: VerbConstants_1.SharedArguments.SqlStoredProcedure.alias,
            },
            env: VerbConstants_1.SharedArguments.SqlStoredProcedure.envVar,
            description: HelpStrings_1.HelpStrings.Verbs['Delete-data-source'].Options.SqlStoredProcedure,
            customPrompt: function () { return __awaiter(_this, void 0, void 0, function () {
                var hasSqlProcedure;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, prompts.confirm({ message: 'Do you have an SQL procedure?' })];
                        case 1:
                            hasSqlProcedure = _a.sent();
                            if (!hasSqlProcedure) return [3 /*break*/, 3];
                            return [4 /*yield*/, prompts.text({ message: VerbConstants_1.SharedArguments.SqlStoredProcedure.promptMessage })];
                        case 2: return [2 /*return*/, _a.sent()];
                        case 3: return [2 /*return*/, ''];
                    }
                });
            }); },
        },
    ]);
}
//# sourceMappingURL=DeleteDataSource.js.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var globals_1 = require("@jest/globals");
var buffer_1 = require("buffer");
var child_process_1 = require("child_process");
var path = __importStar(require("path"));
var commandLineUtils_1 = require("../helpers/commandLineUtils");
// Mock the child_process module and console.log
globals_1.jest.mock('child_process');
globals_1.jest.spyOn(console, 'log').mockImplementation(function () { });
(0, globals_1.describe)('commandLineUtils', function () {
    var consoleLogSpy = globals_1.jest.spyOn(console, 'log');
    (0, globals_1.beforeEach)(function () {
        globals_1.jest.clearAllMocks();
    });
    (0, globals_1.describe)('runNpmCommandInDirectory', function () {
        (0, globals_1.it)('should execute npm command successfully', function () { return __awaiter(void 0, void 0, void 0, function () {
            var expectedOutput, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        expectedOutput = 'command output';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from(expectedOutput),
                            stderr: buffer_1.Buffer.from(''),
                            status: 0,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, commandLineUtils_1.runNpmCommandInDirectory)(['install'])];
                    case 1:
                        result = _a.sent();
                        (0, globals_1.expect)(result).toBe(expectedOutput);
                        (0, globals_1.expect)(child_process_1.spawnSync).toHaveBeenNthCalledWith(2, globals_1.expect.stringContaining('npm'), globals_1.expect.objectContaining({
                            cwd: commandLineUtils_1.testDir,
                            timeout: 60000,
                            encoding: 'utf-8',
                            shell: true,
                            stdio: 'pipe',
                        }));
                        (0, globals_1.expect)(consoleLogSpy).not.toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should use custom working directory when provided', function () { return __awaiter(void 0, void 0, void 0, function () {
            var customDir;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        customDir = '/custom/dir';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from('output'),
                            stderr: buffer_1.Buffer.from(''),
                            status: 0,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, commandLineUtils_1.runNpmCommandInDirectory)(['install'], { workingDirectory: customDir })];
                    case 1:
                        _a.sent();
                        (0, globals_1.expect)(child_process_1.spawnSync).toHaveBeenCalledWith(globals_1.expect.stringContaining('npm'), globals_1.expect.objectContaining({
                            cwd: path.resolve(customDir),
                            timeout: 60000,
                        }));
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should use custom timeout when provided', function () { return __awaiter(void 0, void 0, void 0, function () {
            var customTimeout;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        customTimeout = 120000;
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from('output'),
                            stderr: buffer_1.Buffer.from(''),
                            status: 0,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, commandLineUtils_1.runNpmCommandInDirectory)(['install'], { timeout: customTimeout })];
                    case 1:
                        _a.sent();
                        (0, globals_1.expect)(child_process_1.spawnSync).toHaveBeenCalledWith(globals_1.expect.stringContaining('npm'), globals_1.expect.objectContaining({
                            cwd: commandLineUtils_1.testDir,
                            timeout: customTimeout,
                        }));
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should reject with error when command fails', function () { return __awaiter(void 0, void 0, void 0, function () {
            var errorMessage;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        errorMessage = 'Command failed';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from(''),
                            stderr: buffer_1.Buffer.from(errorMessage),
                            status: 1,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, globals_1.expect)((0, commandLineUtils_1.runNpmCommandInDirectory)(['invalid'])).rejects.toThrow()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should use error message when stderr is empty', function () { return __awaiter(void 0, void 0, void 0, function () {
            var errorMessage;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        errorMessage = 'Command failed';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from(''),
                            stderr: buffer_1.Buffer.from(errorMessage),
                            status: 1,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, globals_1.expect)((0, commandLineUtils_1.runNpmCommandInDirectory)(['invalid'])).rejects.toThrow()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
    });
    (0, globals_1.describe)('runNpxCommandInDirectory', function () {
        (0, globals_1.it)('should execute npx command successfully', function () { return __awaiter(void 0, void 0, void 0, function () {
            var expectedOutput, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        expectedOutput = 'command output';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from(expectedOutput),
                            stderr: buffer_1.Buffer.from(''),
                            status: 0,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, commandLineUtils_1.runNpxCommandInDirectory)(['create-react-app'])];
                    case 1:
                        result = _a.sent();
                        (0, globals_1.expect)(result).toBe(expectedOutput);
                        (0, globals_1.expect)(child_process_1.spawnSync).toHaveBeenCalledWith(globals_1.expect.stringContaining('npx'), globals_1.expect.objectContaining({
                            cwd: commandLineUtils_1.testDir,
                            timeout: 60000,
                        }));
                        (0, globals_1.expect)(consoleLogSpy).not.toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should use custom working directory when provided', function () { return __awaiter(void 0, void 0, void 0, function () {
            var customDir;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        customDir = '/custom/dir';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from('output'),
                            stderr: buffer_1.Buffer.from(''),
                            status: 0,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, commandLineUtils_1.runNpxCommandInDirectory)(['command'], { workingDirectory: customDir })];
                    case 1:
                        _a.sent();
                        (0, globals_1.expect)(child_process_1.spawnSync).toHaveBeenCalledWith(globals_1.expect.stringContaining('npx'), globals_1.expect.objectContaining({
                            cwd: path.resolve(customDir),
                            timeout: 60000,
                        }));
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should use custom timeout when provided', function () { return __awaiter(void 0, void 0, void 0, function () {
            var customTimeout;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        customTimeout = 120000;
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from('output'),
                            stderr: buffer_1.Buffer.from(''),
                            status: 0,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, commandLineUtils_1.runNpxCommandInDirectory)(['command'], { timeout: customTimeout })];
                    case 1:
                        _a.sent();
                        (0, globals_1.expect)(child_process_1.spawnSync).toHaveBeenCalledWith(globals_1.expect.stringContaining('npx'), globals_1.expect.objectContaining({
                            cwd: commandLineUtils_1.testDir,
                            timeout: customTimeout,
                        }));
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should reject with error when command fails', function () { return __awaiter(void 0, void 0, void 0, function () {
            var errorMessage;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        errorMessage = 'Command failed';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from(''),
                            stderr: buffer_1.Buffer.from(errorMessage),
                            status: 1,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, globals_1.expect)((0, commandLineUtils_1.runNpxCommandInDirectory)(['invalid'])).rejects.toThrow()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('should use error message when stderr is empty', function () { return __awaiter(void 0, void 0, void 0, function () {
            var errorMessage;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        errorMessage = 'Command failed';
                        child_process_1.spawnSync.mockReturnValue({
                            stdout: buffer_1.Buffer.from(''),
                            stderr: buffer_1.Buffer.from(errorMessage),
                            status: 1,
                            error: undefined,
                        });
                        return [4 /*yield*/, (0, globals_1.expect)((0, commandLineUtils_1.runNpxCommandInDirectory)(['invalid'])).rejects.toThrow()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
    });
});
//# sourceMappingURL=commandLineUtils.test.js.map
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.boot = void 0;
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var ArgumentProvider_1 = require("./ArgumentProvider");
var PacCliAuthenticationProvider_1 = require("./Authentication/PacCliAuthenticationProvider");
var CliSettings_1 = require("./CliSettings");
var CliHttpClient_1 = require("./HttpClient/CliHttpClient");
var CliLogger_1 = require("./Logger/CliLogger");
var Verbs_1 = require("./Verbs");
var ListEnvironmentVariables_1 = require("./Verbs/ListEnvironmentVariables");
var TelemetrySettings_1 = require("./Verbs/TelemetrySettings");
var logger;
var exitCode = 0;
function boot() {
    return __awaiter(this, void 0, void 0, function () {
        var isPacCli, isTestRun, cliSettings, authenticationProvider, ServicePrincipalAuthenticationProvider, NodeMsalAuthenticationProvider, httpClient, argumentProvider, verb, error_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 11, 12, 15]);
                    isPacCli = process.env.IS_PAC_CLI === 'true';
                    isTestRun = process.env.CI === 'true';
                    return [4 /*yield*/, (0, CliSettings_1.initializeCliSettings)(isPacCli || isTestRun, undefined)];
                case 1:
                    cliSettings = _a.sent();
                    authenticationProvider = void 0;
                    if (!isPacCli) return [3 /*break*/, 2];
                    authenticationProvider = new PacCliAuthenticationProvider_1.PacCliAuthenticationProvider();
                    return [3 /*break*/, 6];
                case 2:
                    if (!isTestRun) return [3 /*break*/, 4];
                    return [4 /*yield*/, Promise.resolve().then(function () { return __importStar(require('./Authentication/ServicePrincipalAuthenticationProvider')); })];
                case 3:
                    ServicePrincipalAuthenticationProvider = (_a.sent()).ServicePrincipalAuthenticationProvider;
                    authenticationProvider = new ServicePrincipalAuthenticationProvider();
                    return [3 /*break*/, 6];
                case 4: return [4 /*yield*/, Promise.resolve().then(function () { return __importStar(require('./Authentication/NodeMsalAuthenticationProvider')); })];
                case 5:
                    NodeMsalAuthenticationProvider = (_a.sent()).NodeMsalAuthenticationProvider;
                    authenticationProvider = new NodeMsalAuthenticationProvider();
                    _a.label = 6;
                case 6: return [4 /*yield*/, authenticationProvider.initAsync()];
                case 7:
                    _a.sent();
                    httpClient = new CliHttpClient_1.CliHttpClient(authenticationProvider);
                    return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, httpClient, authenticationProvider)];
                case 8:
                    // The CLI logger might need to use httpClient and environment info during its initialization
                    // So we create it after the httpClient and authenticationProvider are ready
                    logger = _a.sent();
                    (0, CliSettings_1.setCliLogger)(logger);
                    argumentProvider = new ArgumentProvider_1.ArgumentProvider(httpClient, logger, authenticationProvider);
                    argumentProvider.handleGlobalHelpOrFlagsAndExit();
                    return [4 /*yield*/, argumentProvider.getVerb()];
                case 9:
                    verb = _a.sent();
                    return [4 /*yield*/, executeVerb({ verb: verb, argumentProvider: argumentProvider })];
                case 10:
                    _a.sent();
                    return [3 /*break*/, 15];
                case 11:
                    error_1 = _a.sent();
                    console.error("Error during CLI execution: ".concat(error_1));
                    exitCode = 1;
                    return [3 /*break*/, 15];
                case 12:
                    if (!logger) return [3 /*break*/, 14];
                    return [4 /*yield*/, logger.flush()];
                case 13:
                    _a.sent();
                    _a.label = 14;
                case 14:
                    process.exit(exitCode);
                    return [7 /*endfinally*/];
                case 15: return [2 /*return*/];
            }
        });
    });
}
exports.boot = boot;
function executeVerb(config) {
    return __awaiter(this, void 0, void 0, function () {
        var verb, argumentProvider, _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    verb = config.verb, argumentProvider = config.argumentProvider;
                    _a = verb;
                    switch (_a) {
                        case 'init': return [3 /*break*/, 1];
                        case 'list-codeapps': return [3 /*break*/, 3];
                        case 'add-data-source': return [3 /*break*/, 5];
                        case 'list-datasets': return [3 /*break*/, 7];
                        case 'list-tables': return [3 /*break*/, 9];
                        case 'list-sqlStoredProcedures': return [3 /*break*/, 11];
                        case 'delete-data-source': return [3 /*break*/, 13];
                        case 'logout': return [3 /*break*/, 15];
                        case 'list-environment-variables': return [3 /*break*/, 17];
                        case 'list-connection-references': return [3 /*break*/, 19];
                        case 'push': return [3 /*break*/, 21];
                        case 'run': return [3 /*break*/, 23];
                        case 'telemetry': return [3 /*break*/, 25];
                    }
                    return [3 /*break*/, 27];
                case 1: return [4 /*yield*/, (0, Verbs_1.initAsync)(argumentProvider)];
                case 2:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 3: return [4 /*yield*/, (0, Verbs_1.getCodeAppsAsync)(argumentProvider)];
                case 4:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 5: return [4 /*yield*/, (0, Verbs_1.addDataSourceAsync)(argumentProvider)];
                case 6:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 7: return [4 /*yield*/, (0, Verbs_1.listDatasetsAsync)(argumentProvider)];
                case 8:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 9: return [4 /*yield*/, (0, Verbs_1.listTablesAsync)(argumentProvider)];
                case 10:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 11: return [4 /*yield*/, (0, Verbs_1.listSqlStoredProceduresAsync)(argumentProvider)];
                case 12:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 13: return [4 /*yield*/, (0, Verbs_1.deleteDataSourceAsync)(argumentProvider)];
                case 14:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 15: return [4 /*yield*/, (0, Verbs_1.logoutAsync)(argumentProvider)];
                case 16:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 17: return [4 /*yield*/, (0, ListEnvironmentVariables_1.listAllEnvironmentVariablesAsync)(argumentProvider)];
                case 18:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 19: return [4 /*yield*/, (0, Verbs_1.listConnectionReferences)(argumentProvider)];
                case 20:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 21: return [4 /*yield*/, (0, Verbs_1.pushAsync)(argumentProvider)];
                case 22:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 23: return [4 /*yield*/, (0, Verbs_1.runAsync)(argumentProvider)];
                case 24:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 25: return [4 /*yield*/, (0, TelemetrySettings_1.modifyTelemetrySettings)(argumentProvider)];
                case 26:
                    _b.sent();
                    return [3 /*break*/, 28];
                case 27:
                    unsupportedVerb(verb);
                    _b.label = 28;
                case 28: return [2 /*return*/];
            }
        });
    });
}
// Helper function ensures compile time checking for exhaustive verb handling
function unsupportedVerb(verb) {
    throw new Error("The verb \"".concat(verb, "\" is not supported."));
}
//# sourceMappingURL=Cli.js.map
import { Region } from '@pa-client/powerapps-player-services/lib/Types/PlayerServices.types';
import { CliOption, DefaultStringOption } from './Types/Argument.types';
export declare function getRegion(region: string): Region;
export declare function createDefaultStringOption(options: DefaultStringOption): CliOption<string>;
export declare function isGuid(value: string): boolean;
export declare function createPlayUrl(region: Region, environmentId: string, appId: string, localAppUrl?: string, localConnectionsUrl?: string): string;

/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
/**
 * Get environment variables from a Dataverse environment.
 * Expects the following arguments:
 * - envUrl: The environment URL for Dataverse data sources
 *
 * @param {ArgumentProvider} argumentProvider
 * @returns {Promise<void>}
 */
export declare function listAllEnvironmentVariablesAsync(argumentProvider: ArgumentProvider): Promise<void>;

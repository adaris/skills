"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
var globals_1 = require("@jest/globals");
var fs = __importStar(require("fs"));
var LoggerSettings_1 = require("../../Logger/LoggerSettings");
globals_1.jest.mock('fs', function () { return ({
    existsSync: globals_1.jest.fn(),
    readFileSync: globals_1.jest.fn(),
}); });
var mockedFs = fs;
/**
 * Test matrix for resolveUserTelemetrySettings:
 *
 * | POWERAPPS_CLI_TELEMETRY env | POWERAPPS CLI user file | PAC_CLI_TELEMETRY_OPTOUT | PAC CLI user file              | Expected result                                            |
 * |-------------------|-------------------------|----------------------------------------|---------------------------------|-----------------------------------------------------------|
 * | not set           | missing                  | not set                                | missing                        | defaults: enabled true, console false, consoleOnly false  |
 * | not set           | enabled=false            | not set                                | missing                        | disabled (file wins)                                      |
 * | not set           | consoleOnly=true         | not set                                | missing                        | consoleOnly                                               |
 * | not set           | outputToConsole=true     | not set                                | missing                        | OneDS + Console (integration check via CliLogger)         |
 * | 0       | any                      | not set                                | any                            | forced disabled (env override wins)                       |
 * | 1       | any                      | not set                                | any                            | no-op (truthy doesn't force enable)                       |
 * | not set           | any                      | truthy                                 | any                            | forced disabled (PAC env wins)                            |
 * | not set           | enabled=true             | not set                                | telemetryEnabled=false         | forced disabled (PAC file wins)                           |
 * | not set           | enabled=true             | not set                                | telemetryEnabled=true          | enabled (both agree)                                      |
 * | not set           | enabled=false, consoleOnly=true | not set                       | missing                        | disabled + consoleOnly honored                            |
 * | 0       | enabled=true             | not set                                | missing                        | forced disabled (env wins over file)                      |
 * | not set           | enabled=true             | PAC_OPTOUT=1                           | missing                        | forced disabled (PAC env wins over file)                  |
 * | not set           | enabled=true             | not set                                | missing telemetryEnabled field | enabled (file controls, PAC undefined)                    |
 * | not set           | any                      | not set (LOCALAPPDATA missing)         | n/a                            | PAC check returns undefined, no crash                     |
 * | POWERAPPS=0       | any                      | PAC_OPTOUT=1                           | any                            | disabled (both overrides agree)                           |
 * | not set           | {"enabled": null}        | not set                                | missing                        | enabled=true (null in file falls back to default)         |
 * | ' 0 ' (spaces)    | any                      | not set                                | any                            | forced disabled (falsy env is trimmed)                    |
 */
(0, globals_1.describe)('resolveUserTelemetrySettings', function () {
    var originalEnv = process.env;
    (0, globals_1.beforeEach)(function () {
        globals_1.jest.clearAllMocks();
        process.env = __assign({}, originalEnv);
        delete process.env.POWERAPPS_CLI_TELEMETRY;
        delete process.env.PAC_CLI_TELEMETRY_OPTOUT;
        delete process.env.LOCALAPPDATA;
        mockedFs.existsSync.mockReturnValue(false);
    });
    (0, globals_1.afterAll)(function () {
        process.env = originalEnv;
    });
    (0, globals_1.it)('returns defaults when cli settings file does not exist', function () {
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings).toEqual({ enabled: true, consoleOnly: false, outputToConsole: false });
        (0, globals_1.expect)(mockedFs.readFileSync).not.toHaveBeenCalled();
    });
    (0, globals_1.it)('merges values from cli settings when file is valid', function () {
        var mockSettings = { enabled: false, consoleOnly: true, outputToConsole: true };
        mockedFs.existsSync.mockReturnValue(true);
        mockedFs.readFileSync.mockReturnValue(JSON.stringify(mockSettings));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings).toEqual(mockSettings);
        (0, globals_1.expect)(mockedFs.readFileSync).toHaveBeenCalledTimes(1);
    });
    (0, globals_1.it)('respects POWERAPPS_CLI_TELEMETRY env override (falsy forces disabled)', function () {
        process.env.POWERAPPS_CLI_TELEMETRY = '0';
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.it)('ignores truthy POWERAPPS_CLI_TELEMETRY env (no-op)', function () {
        process.env.POWERAPPS_CLI_TELEMETRY = '1';
        mockedFs.existsSync.mockReturnValue(true);
        mockedFs.readFileSync.mockReturnValue(JSON.stringify({ enabled: false }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.it)('respects PAC_CLI telemetry opt-out env flag', function () {
        process.env.PAC_CLI_TELEMETRY_OPTOUT = 'true';
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.it)('disables telemetry when PAC CLI usersettings disables it', function () {
        process.env.LOCALAPPDATA = 'C:\\temp';
        mockedFs.existsSync.mockReturnValueOnce(false).mockReturnValueOnce(true);
        mockedFs.readFileSync.mockReturnValueOnce(JSON.stringify({ telemetryEnabled: false }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.it)('enables when both CLI and PAC files agree on enabled', function () {
        process.env.LOCALAPPDATA = 'C:\\temp';
        mockedFs.existsSync.mockReturnValueOnce(true).mockReturnValueOnce(true);
        mockedFs.readFileSync
            .mockReturnValueOnce(JSON.stringify({ enabled: true }))
            .mockReturnValueOnce(JSON.stringify({ telemetryEnabled: true }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(true);
    });
    (0, globals_1.it)('honors consoleOnly even when disabled', function () {
        mockedFs.existsSync.mockReturnValue(true);
        mockedFs.readFileSync.mockReturnValue(JSON.stringify({ enabled: false, consoleOnly: true }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
        (0, globals_1.expect)(settings.consoleOnly).toBe(true);
    });
    (0, globals_1.it)('env override wins over CLI file enabled', function () {
        process.env.POWERAPPS_CLI_TELEMETRY = '0';
        mockedFs.existsSync.mockReturnValue(true);
        mockedFs.readFileSync.mockReturnValue(JSON.stringify({ enabled: true }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.it)('PAC env override wins over CLI file enabled', function () {
        process.env.PAC_CLI_TELEMETRY_OPTOUT = '1';
        mockedFs.existsSync.mockReturnValue(true);
        mockedFs.readFileSync.mockReturnValue(JSON.stringify({ enabled: true }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.it)('handles missing telemetryEnabled field in PAC file', function () {
        process.env.LOCALAPPDATA = 'C:\\temp';
        mockedFs.existsSync.mockReturnValueOnce(false).mockReturnValueOnce(true);
        mockedFs.readFileSync.mockReturnValueOnce(JSON.stringify({}));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(true);
    });
    (0, globals_1.it)('handles missing LOCALAPPDATA without crashing', function () {
        mockedFs.existsSync.mockReturnValue(true);
        mockedFs.readFileSync.mockReturnValue(JSON.stringify({ enabled: false }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
        (0, globals_1.expect)(mockedFs.readFileSync).toHaveBeenCalledTimes(1);
    });
    (0, globals_1.it)('handles multiple overrides forcing disabled', function () {
        process.env.POWERAPPS_CLI_TELEMETRY = '0';
        process.env.PAC_CLI_TELEMETRY_OPTOUT = '1';
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.it)('ignores missing PAC CLI usersettings', function () {
        process.env.LOCALAPPDATA = 'C:\\temp';
        mockedFs.existsSync.mockReturnValueOnce(true).mockReturnValueOnce(false);
        mockedFs.readFileSync.mockReturnValueOnce(JSON.stringify({ enabled: true }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(true);
        (0, globals_1.expect)(mockedFs.readFileSync).toHaveBeenCalledTimes(1);
    });
    (0, globals_1.it)('falls back to default when file contains null values', function () {
        mockedFs.existsSync.mockReturnValue(true);
        mockedFs.readFileSync.mockReturnValue(JSON.stringify({ enabled: null, consoleOnly: true, outputToConsole: null }));
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(true);
        (0, globals_1.expect)(settings.consoleOnly).toBe(true);
        (0, globals_1.expect)(settings.outputToConsole).toBe(false);
    });
    (0, globals_1.it)('trims whitespace from env vars', function () {
        process.env.POWERAPPS_CLI_TELEMETRY = ' 0 ';
        var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
        (0, globals_1.expect)(settings.enabled).toBe(false);
    });
    (0, globals_1.describe)('failure modes', function () {
        (0, globals_1.afterEach)(function () {
            globals_1.jest.restoreAllMocks();
        });
        (0, globals_1.it)('warns on malformed CLI user settings', function () {
            var warnSpy = globals_1.jest.spyOn(console, 'warn').mockImplementation(function () { return undefined; });
            mockedFs.existsSync.mockReturnValue(true);
            mockedFs.readFileSync.mockReturnValue('{ invalid json');
            var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
            (0, globals_1.expect)(settings.enabled).toBe(true);
            (0, globals_1.expect)(warnSpy).toHaveBeenCalled();
            var _a = __read(warnSpy.mock.calls[0], 2), message = _a[0], detail = _a[1];
            (0, globals_1.expect)(message).toBe('Failed to read CLI telemetry settings:');
            (0, globals_1.expect)(detail).toEqual(globals_1.expect.stringMatching(/Expected|Unexpected/));
        });
        (0, globals_1.it)('warns on malformed PAC CLI user settings', function () {
            var warnSpy = globals_1.jest.spyOn(console, 'warn').mockImplementation(function () { return undefined; });
            process.env.LOCALAPPDATA = 'C:\\temp';
            mockedFs.existsSync.mockReturnValueOnce(false).mockReturnValueOnce(true);
            mockedFs.readFileSync.mockReturnValueOnce('{ invalid');
            var settings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
            (0, globals_1.expect)(settings.enabled).toBe(true);
            (0, globals_1.expect)(warnSpy).toHaveBeenCalled();
            var _a = __read(warnSpy.mock.calls[0], 2), message = _a[0], detail = _a[1];
            (0, globals_1.expect)(message).toBe('Failed to read PAC CLI telemetry settings:');
            (0, globals_1.expect)(detail).toEqual(globals_1.expect.stringMatching(/Expected|Unexpected/));
        });
    });
});
//# sourceMappingURL=LoggerSettings.test.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ITelemetryWriter } from '../Types/LoggerTypes.types';
export declare class ConsoleWriter implements ITelemetryWriter {
    trackActivityEvent(eventName: string, eventData?: object): void;
    trackErrorEvent(eventName: string, eventData?: object): void;
    startScenario(scenarioName: string, startData?: object): void;
    completeScenario(scenarioName: string, completeData?: object): void;
    scenarioFailed(scenarioName: string, failureData?: object): void;
    scenarioCompletedWithError(scenarioName: string, completeWithErrorData?: object): void;
    flush(): void;
    setCustomDimension(_key: string, _value: string): void;
}
//# sourceMappingURL=ConsoleWriter.d.ts.map
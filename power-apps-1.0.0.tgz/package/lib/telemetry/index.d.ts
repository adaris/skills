/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export type { Logger } from './Logger.types';
//# sourceMappingURL=index.d.ts.map
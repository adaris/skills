/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { DataSourcesInfo, IOperationResult } from '../types';
/**
 * Deletes a record from the specified table.
 * @param dataSourcesInfo - The data sources information.
 * @param tableName - The name of the table to delete the record from.
 * @param recordId - The ID of the record to delete.
 * @returns A promise that resolves to the result of the delete operation.
 */
export declare function deleteRecordAsync(dataSourcesInfo: DataSourcesInfo, tableName: string, recordId: string): Promise<IOperationResult<void>>;
//# sourceMappingURL=deleteRecord.d.ts.map
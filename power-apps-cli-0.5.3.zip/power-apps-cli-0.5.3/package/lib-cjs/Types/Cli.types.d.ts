/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
import { PowerAppsRepoConfig } from '@microsoft/powerapps-player-actions/lib/Config/Config.types';
import { CliFS } from '../FS/CliFs';
export interface IAuthenticationProvider {
    initAsync(): Promise<void>;
    getAccessTokenForResource(resource: string): Promise<string>;
    getUserTenantId(): string | undefined;
}
export type Verb = 'init' | 'push' | 'run' | 'add-data-source' | 'list-codeapps' | 'list-datasets' | 'list-tables' | 'list-sqlStoredProcedures' | 'delete-data-source' | 'list-environment-variables' | 'list-connection-references' | 'logout' | 'telemetry';
export type CliSettings = {
    source: 'pac-cli' | 'standalone';
    fileConfig: LocalFilePaths;
    cliFs: CliFS;
    appConfig?: PowerAppsRepoConfig;
};
export type LocalFilePaths = {
    powerConfigPath: string;
    schemaPath: string;
    codeGenPath: string;
};
export type ExecuteVerbConfig = {
    verb: Verb;
    argumentProvider: ArgumentProvider;
};
export type UserTelemetrySettings = {
    enabled: boolean;
    consoleOnly: boolean;
    outputToConsole: boolean;
};

"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createExecuteCodeCommandAllowFailure = exports.createExecuteCodeCommand = exports.cleanupE2eTestProject = exports.setupE2eTestProject = exports.validateGeneratedFiles = exports.copyDirRecursive = exports.readJson = exports.copyHostTemplateApp = exports.cleanupTestFolder = exports.createTestFolder = void 0;
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var globals_1 = require("@jest/globals");
var fs_1 = __importDefault(require("fs"));
var path_1 = __importDefault(require("path"));
var process_1 = __importDefault(require("process"));
var commandLineUtils_1 = require("./commandLineUtils");
// Test helpers for power-data-runtime tests
/**
 * Creates a test folder relative to the current working directory.
 *
 * @param {string} folderName
 * @returns {string}
 */
function createTestFolder(folderName) {
    var testFolderPath = path_1.default.join(commandLineUtils_1.testDir, folderName);
    if (!fs_1.default.existsSync(testFolderPath)) {
        fs_1.default.mkdirSync(testFolderPath, { recursive: true });
        // change to the test folder
    }
    // if the folder already exists, we will use it
    process_1.default.chdir(testFolderPath);
    return testFolderPath;
}
exports.createTestFolder = createTestFolder;
/**
 * Cleans up the test folder by removing it and all its contents.
 *
 * @param {string} folderName
 */
function cleanupTestFolder(folderName) {
    var testFolder = path_1.default.join(commandLineUtils_1.testDir, folderName);
    if (fs_1.default.existsSync(testFolder)) {
        fs_1.default.rmSync(testFolder, { recursive: true, force: true });
    }
    // change back to the original working directory
    process_1.default.chdir(path_1.default.resolve(commandLineUtils_1.testDir, '..'));
}
exports.cleanupTestFolder = cleanupTestFolder;
/**
 * Copies a host template app from source to destination directory.
 *
 * @param {string} source - Source directory path
 * @param {string} destination - Destination directory path
 */
function copyHostTemplateApp(source, destination) {
    if (fs_1.default.existsSync(source) && fs_1.default.readdirSync(source).length > 0) {
        fs_1.default.cpSync(source, destination, { recursive: true });
    }
}
exports.copyHostTemplateApp = copyHostTemplateApp;
function readJson(filePath) {
    return JSON.parse(fs_1.default.readFileSync(filePath, 'utf-8'));
}
exports.readJson = readJson;
/**
 * Recursively copies a directory and its contents from source to destination.
 *
 * @param {string} src - Source directory path
 * @param {string} dest - Destination directory path
 */
function copyDirRecursive(src, dest) {
    var e_1, _a;
    if (!fs_1.default.existsSync(dest)) {
        fs_1.default.mkdirSync(dest, { recursive: true });
    }
    var entries = fs_1.default.readdirSync(src, { withFileTypes: true });
    try {
        for (var entries_1 = __values(entries), entries_1_1 = entries_1.next(); !entries_1_1.done; entries_1_1 = entries_1.next()) {
            var entry = entries_1_1.value;
            var srcPath = path_1.default.join(src, entry.name);
            var destPath = path_1.default.join(dest, entry.name);
            if (entry.isDirectory()) {
                copyDirRecursive(srcPath, destPath);
            }
            else {
                fs_1.default.copyFileSync(srcPath, destPath);
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (entries_1_1 && !entries_1_1.done && (_a = entries_1.return)) _a.call(entries_1);
        }
        finally { if (e_1) throw e_1.error; }
    }
}
exports.copyDirRecursive = copyDirRecursive;
/**
 * Validates that generated model and service files exist for a given data source.
 * Generated files follow the pattern: {DataSourceName}Model.ts and {DataSourceName}Service.ts
 * located in the generated/models and generated/services directories respectively.
 *
 * @param {string} projectRoot - Root directory of the test project
 * @param {string} dataSourceName - Name of the data source (will be capitalized for file names)
 * @throws {AssertionError} if files don't exist or have invalid content
 */
function validateGeneratedFiles(projectRoot, dataSourceName) {
    var generatedModelsDir = path_1.default.join(projectRoot, 'generated', 'models');
    var generatedServicesDir = path_1.default.join(projectRoot, 'generated', 'services');
    // Check if generated directories exist
    (0, globals_1.expect)(fs_1.default.existsSync(generatedModelsDir)).toBe(true);
    (0, globals_1.expect)(fs_1.default.existsSync(generatedServicesDir)).toBe(true);
    // Construct expected file names (capitalize first letter of data source name)
    var capitalizedName = dataSourceName.charAt(0).toUpperCase() + dataSourceName.slice(1);
    var modelFileName = "".concat(capitalizedName, "Model.ts");
    var serviceFileName = "".concat(capitalizedName, "Service.ts");
    var modelFilePath = path_1.default.join(generatedModelsDir, modelFileName);
    var serviceFilePath = path_1.default.join(generatedServicesDir, serviceFileName);
    // Validate model file exists and has content
    (0, globals_1.expect)(fs_1.default.existsSync(modelFilePath)).toBe(true);
    var modelContent = fs_1.default.readFileSync(modelFilePath, 'utf-8');
    (0, globals_1.expect)(modelContent.length).toBeGreaterThan(0);
    (0, globals_1.expect)(modelContent).toContain('Copyright (C) Microsoft Corporation');
    // Validate service file exists and has content
    (0, globals_1.expect)(fs_1.default.existsSync(serviceFilePath)).toBe(true);
    var serviceContent = fs_1.default.readFileSync(serviceFilePath, 'utf-8');
    (0, globals_1.expect)(serviceContent.length).toBeGreaterThan(0);
    (0, globals_1.expect)(serviceContent).toContain('Copyright (C) Microsoft Corporation');
}
exports.validateGeneratedFiles = validateGeneratedFiles;
/**
 * Sets up an E2E test project by creating a temporary directory and copying host template files.
 * Performs CLI and npm availability checks.
 *
 * @param {object} config - Configuration object
 * @param {string} config.cliPath - Path to the CLI entry point
 * @param {string} config.tempBaseDir - Base directory for temporary test folders (e.g., 'C:\\tmp\\...')
 * @param {string} config.testFolderName - Name/prefix for the test folder
 * @param {string} config.hostTemplateFolder - Path to the host template folder to copy to the test folder
 * @returns {string} The path to the created project root directory
 * @throws {Error} if CLI path doesn't exist or npm is not available
 */
function setupE2eTestProject(config) {
    var _a;
    if (!fs_1.default.existsSync((_a = config.cliPath) !== null && _a !== void 0 ? _a : 
    // eslint-disable-next-line no-external-vars
    path_1.default.resolve(__dirname, '..', '..', '..', 'dist', 'nomodule', 'powerapps-player-cli.js'))) {
        throw new Error("The built CLI entry point at ".concat(config.cliPath, " was not found. Run 'npm run bundle' before executing the E2E suite."));
    }
    if (!(0, commandLineUtils_1.verifyCanRunNPM)()) {
        throw new Error('NPM executable is not available on PATH. Install Node.js/npm before running E2E tests.');
    }
    // Create test folder with timestamp to ensure uniqueness
    var timestamp = Date.now();
    var projectRoot = path_1.default.join(config.tempBaseDir, "".concat(config.testFolderName, "_").concat(timestamp));
    if (!fs_1.default.existsSync(projectRoot)) {
        fs_1.default.mkdirSync(projectRoot, { recursive: true });
    }
    // Copy the host template folder if it exists
    if (fs_1.default.existsSync(config.hostTemplateFolder)) {
        copyDirRecursive(config.hostTemplateFolder, projectRoot);
    }
    return projectRoot;
}
exports.setupE2eTestProject = setupE2eTestProject;
/**
 * Cleans up an E2E test project by removing the temporary directory and all its contents.
 *
 * @param {string} projectRoot - Root directory of the test project to clean up
 */
function cleanupE2eTestProject(projectRoot) {
    if (projectRoot && fs_1.default.existsSync(projectRoot)) {
        fs_1.default.rmSync(projectRoot, { recursive: true, force: true });
    }
}
exports.cleanupE2eTestProject = cleanupE2eTestProject;
/**
 * Creates a function that executes CLI commands with predefined configuration.
 * Isolates the stdout and stderr for each executor instance.
 *
 * @param {object} options - Configuration options for command execution
 * @param {string} [options.cliPath] - Path to the CLI entry point (defaults to dist/nomodule/powerapps-player-cli.js)
 * @param {string} options.workingDirectory - Working directory for command execution
 * @param {NodeJS.ProcessEnv} [options.envOverrides] - Environment variable overrides
 *
 * @returns {(verb: string, args?: string[]) => CliCommandResult} Command executor function
 */
function createExecuteCodeCommand(options) {
    var _a;
    var projectRoot = options.workingDirectory, envOverrides = options.envOverrides;
    var cliPath = (_a = options.cliPath) !== null && _a !== void 0 ? _a : 
    // eslint-disable-next-line no-external-vars
    path_1.default.resolve(__dirname, '..', '..', '..', 'dist', 'nomodule', 'powerapps-player-cli.js');
    var sharedOptions = {
        env: __assign({ CI: 'true' }, envOverrides),
        cliPath: cliPath,
        cwd: projectRoot,
        timeoutMs: commandLineUtils_1.DEFAULT_COMMAND_TIMEOUT_MS,
        maxBuffer: commandLineUtils_1.DEFAULT_COMMAND_MAX_BUFFER,
    };
    return function (verb, args) {
        if (args === void 0) { args = []; }
        var result = (0, commandLineUtils_1.runCliCommand)(__assign(__assign({}, sharedOptions), { verb: verb, args: args }));
        return result;
    };
}
exports.createExecuteCodeCommand = createExecuteCodeCommand;
/**
 * Creates a command executor that allows CLI command failures without throwing.
 * Useful for testing error scenarios and validating error handling.
 *
 * @param {object} options - Configuration object
 * @param {string} [options.cliPath] - Path to the CLI entry point (defaults to dist/nomodule/powerapps-player-cli.js)
 * @param {string} options.workingDirectory - Working directory for command execution
 * @param {NodeJS.ProcessEnv} [options.envOverrides] - Environment variable overrides
 * @returns {(verb: string, args?: string[]) => CliCommandResultWithExitCode  executor function
 */
function createExecuteCodeCommandAllowFailure(options) {
    var _a;
    var projectRoot = options.workingDirectory, envOverrides = options.envOverrides;
    var cliPath = (_a = options.cliPath) !== null && _a !== void 0 ? _a : 
    // eslint-disable-next-line no-external-vars
    path_1.default.resolve(__dirname, '..', '..', '..', 'dist', 'nomodule', 'powerapps-player-cli.js');
    var sharedOptions = {
        env: __assign({ CI: 'true' }, envOverrides),
        cliPath: cliPath,
        cwd: projectRoot,
        timeoutMs: commandLineUtils_1.DEFAULT_COMMAND_TIMEOUT_MS,
        maxBuffer: commandLineUtils_1.DEFAULT_COMMAND_MAX_BUFFER,
    };
    return function (verb, args) {
        if (args === void 0) { args = []; }
        var result = (0, commandLineUtils_1.runCliCommandAllowFailure)(__assign(__assign({}, sharedOptions), { verb: verb, args: args }));
        return result;
    };
}
exports.createExecuteCodeCommandAllowFailure = createExecuteCodeCommandAllowFailure;
//# sourceMappingURL=testHelpers.js.map
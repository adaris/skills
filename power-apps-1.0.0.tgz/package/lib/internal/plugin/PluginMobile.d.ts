/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
declare global {
    namespace cordova {
        function exec(success: (data: any) => any, fail: (err: any) => any, service: string, action: string, args?: any[]): void;
    }
}
export declare function executePlugin(pluginName: string, pluginAction: string, params?: unknown[]): void;
export declare function executePluginAsync<T = unknown>(pluginName: string, pluginAction: string, params?: unknown[]): Promise<T>;
export declare function initializeMobilePlugins(): Promise<void>;
export declare function isMobilePlayer(): boolean;
//# sourceMappingURL=PluginMobile.d.ts.map
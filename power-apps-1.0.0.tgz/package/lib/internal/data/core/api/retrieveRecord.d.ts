/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { DataSourcesInfo, IOperationOptions, IOperationResult } from '../types';
/**
 * Retrieves a record from the specified table.
 * @param tableName - The name of the table to retrieve the record from.
 * @param recordId - The ID of the record to retrieve.
 * @param options - Optional operation options.
 * @returns A promise that resolves to the retrieved record.
 */
export declare function retrieveRecordAsync<TResult>(dataSourcesInfo: DataSourcesInfo, tableName: string, recordId: string, options?: IOperationOptions): Promise<IOperationResult<TResult>>;
//# sourceMappingURL=retrieveRecord.d.ts.map
/// <reference types="jest" />
import { RuntimeDataSourceService } from '../../internal/data/core/metadata/runtimeDataSourceService';
export declare const testDir: string;
export declare function getMockDataClient(overrides?: Record<string, unknown>): {
    createDataAsync: jest.Mock<any, any, any>;
    updateDataAsync: jest.Mock<any, any, any>;
    deleteDataAsync: jest.Mock<any, any, any>;
    retrieveDataAsync: jest.Mock<any, any, any>;
};
export declare function getMockMetadataClient(connectionReferences: object, overrides?: Record<string, unknown>): {
    getAppConnectionConfigsAsync: jest.Mock<any, any, any>;
    getAppDataSourceConfigsAsync: jest.Mock<any, any, any>;
};
export declare function getMockClientProvider(dataClient: object, metadataClient: object, overrides?: Record<string, unknown>): {
    getDataClientAsync: jest.Mock<any, any, any>;
    getMetadataClientAsync: jest.Mock<any, any, any>;
};
export declare function getMockConnectionsService(dataSourceInfo: object, overrides?: Record<string, unknown>): RuntimeDataSourceService;
export declare function suppressConsoleErrorTelemetryLogger(): void;
/**
 * Converts a JavaScript object to an ArrayBuffer for simulating HTTP response bodies in tests
 * This is needed because Jest does not support TextEncoder/Decoder in Node.js environment
 * @param data The object to convert
 * @returns ArrayBuffer containing the JSON string representation
 */
export declare function createMockArrayBuffer(data: any): ArrayBuffer;
//# sourceMappingURL=testHelpers.d.ts.map
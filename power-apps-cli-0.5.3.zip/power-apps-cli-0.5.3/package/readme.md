# @microsoft/power-apps-cli

Internal CLI for @microsoft/power-apps. Not meant to be installed without the other package also installed with an app.

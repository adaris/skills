/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare const AriaProjectIds: {
    Mooncake: string;
    Production: string;
    NonProduction: string;
    GccModerate: string;
    GccHigh: string;
    DoD: string;
    Ex: string;
    Rx: string;
    EuropeanInstitution: string;
};
export declare const OneDSEventNames: {
    ActivityEvent: string;
    EndScenario: string;
    ErrorEvent: string;
    StartScenario: string;
};
export declare const ScenarioResults: {
    Success: string;
    Failed: string;
    SuccessWithErrors: string;
};
export declare const EUGeoRegions: Set<string>;
export type TelemetryLocation = 'global' | 'eu';
//# sourceMappingURL=Constants.d.ts.map
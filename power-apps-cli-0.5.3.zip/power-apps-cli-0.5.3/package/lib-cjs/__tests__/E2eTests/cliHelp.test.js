"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * The goal of these tests is to verify that the CLI help output is shown correctly
 * in various scenarios, including when no verb is provided, when the help verb
 * is explicitly requested, and when help for a specific verb is requested.
 */
var globals_1 = require("@jest/globals");
var HelpStrings_1 = require("../../Constants/HelpStrings");
var VerbRegistry_1 = require("../../Constants/VerbRegistry");
var testHelpers_1 = require("../helpers/testHelpers");
var TEST_FOLDER_NAME = 'cliHelpTests';
var TEMP_BASE_DIR = 'C\\tmp\\cliHelpTests';
// Central list of verbs whose --help we want to validate.
// '' represents "no verb" (top-level/global help).
var VERBS_UNDER_TEST = [
    {
        verb: '',
        usage: 'Usage: power-apps [option] [command] [<args>]',
        expectedText: HelpStrings_1.HelpStrings.Global.ProgramDescription,
    },
    {
        verb: 'init',
        usage: 'Usage: power-apps init',
        expectedText: HelpStrings_1.HelpStrings.Verbs.Init.Description,
        options: HelpStrings_1.HelpStrings.Verbs.Init.Options,
    },
    {
        verb: 'add-data-source',
        usage: 'Usage: power-apps add-data-source',
        expectedText: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Description,
        options: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Options,
    },
    {
        verb: 'delete-data-source',
        usage: 'Usage: power-apps delete-data-source',
        expectedText: HelpStrings_1.HelpStrings.Verbs['Delete-data-source'].Description,
        options: HelpStrings_1.HelpStrings.Verbs['Delete-data-source'].Options,
    },
    {
        verb: 'list-codeapps',
        usage: 'Usage: power-apps list-codeapps',
        expectedText: HelpStrings_1.HelpStrings.Verbs['List-codeapps'].Description,
    },
    {
        verb: 'list-sqlStoredProcedures',
        usage: 'Usage: power-apps list-sqlStoredProcedures',
        expectedText: HelpStrings_1.HelpStrings.Verbs['List-sqlStoredProcedures'].Description,
        options: HelpStrings_1.HelpStrings.Verbs['List-sqlStoredProcedures'].Options,
    },
    {
        verb: 'list-datasets',
        usage: 'Usage: power-apps list-datasets',
        expectedText: HelpStrings_1.HelpStrings.Verbs['List-datasets'].Description,
        options: HelpStrings_1.HelpStrings.Verbs['List-datasets'].Options,
    },
    {
        verb: 'list-tables',
        usage: 'Usage: power-apps list-tables',
        expectedText: HelpStrings_1.HelpStrings.Verbs['List-tables'].Description,
        options: HelpStrings_1.HelpStrings.Verbs['List-tables'].Options,
    },
    {
        verb: 'list-environment-variables',
        usage: 'Usage: power-apps list-environment-variables',
        expectedText: HelpStrings_1.HelpStrings.Verbs['List-environment-variables'].Description,
        options: HelpStrings_1.HelpStrings.Verbs['List-environment-variables'].Options,
    },
    {
        verb: 'list-connection-references',
        usage: 'Usage: power-apps list-connection-references',
        expectedText: HelpStrings_1.HelpStrings.Verbs['List-connection-references'].Description,
        options: HelpStrings_1.HelpStrings.Verbs['List-connection-references'].Options,
    },
    {
        verb: 'logout',
        usage: 'Usage: power-apps logout',
        expectedText: HelpStrings_1.HelpStrings.Verbs.Logout.Description,
    },
    {
        verb: 'push',
        usage: 'Usage: power-apps push',
        expectedText: HelpStrings_1.HelpStrings.Verbs.Push.Description,
        options: HelpStrings_1.HelpStrings.Verbs.Push.Options,
    },
    {
        verb: 'run',
        usage: 'Usage: power-apps run',
        expectedText: HelpStrings_1.HelpStrings.Verbs.Run.Description,
        options: HelpStrings_1.HelpStrings.Verbs.Run.Options,
    },
];
(0, globals_1.describe)('power-apps help output', function () {
    var projectRoot;
    var originalEnv = __assign({}, process.env);
    var setValidEnv = function () {
        process.env.SP_CLIENT_ID = 'client-id';
        process.env.SP_CLIENT_SECRET = 'client-secret';
        process.env.SP_TENANT_ID = 'tenant-id';
    };
    (0, globals_1.beforeEach)(function () {
        process.env = __assign({}, originalEnv);
        setValidEnv();
    });
    (0, globals_1.afterAll)(function () {
        process.env = originalEnv;
    });
    (0, globals_1.beforeAll)(function () {
        projectRoot = (0, testHelpers_1.setupE2eTestProject)({
            tempBaseDir: TEMP_BASE_DIR,
            testFolderName: TEST_FOLDER_NAME,
            hostTemplateFolder: '', // No host template for this test
        });
    });
    (0, globals_1.afterAll)(function () {
        (0, testHelpers_1.cleanupE2eTestProject)(projectRoot);
    });
    (0, globals_1.it)('shows help when no verb is passed', function () {
        var _a = (0, testHelpers_1.createExecuteCodeCommand)({
            workingDirectory: projectRoot,
        })('', []), stdout = _a.stdout, stderr = _a.stderr;
        (0, globals_1.expect)(stderr).toBe('');
        (0, globals_1.expect)(stdout.length > 0).toBe(true);
        // Normalize whitespace to handle line wrapping in help output
        var normalizedOutput = stdout.replace(/\s+/g, ' ');
        var normalizedDescription = HelpStrings_1.HelpStrings.Global.ProgramDescription.replace(/\s+/g, ' ');
        (0, globals_1.expect)(normalizedOutput).toContain(normalizedDescription);
    });
    (0, globals_1.it)('global help does not include global option descriptions', function () {
        var executeCodeCommand = (0, testHelpers_1.createExecuteCodeCommand)({
            workingDirectory: projectRoot,
        });
        var stdout = executeCodeCommand('', ['--help']).stdout;
        // Normalize whitespace to handle line wrapping in help output
        var normalizedOutput = stdout.replace(/\s+/g, ' ');
        var normalizedRegion = HelpStrings_1.HelpStrings.Global.Region.replace(/\s+/g, ' ');
        var normalizedEnvId = HelpStrings_1.HelpStrings.Global.EnvironmentId.replace(/\s+/g, ' ');
        // Global options should be hidden from global help
        (0, globals_1.expect)(normalizedOutput).not.toContain(normalizedRegion);
        (0, globals_1.expect)(normalizedOutput).not.toContain(normalizedEnvId);
    });
    (0, globals_1.it)('global help includes verb table with all verbs', function () {
        var executeCodeCommand = (0, testHelpers_1.createExecuteCodeCommand)({
            workingDirectory: projectRoot,
        });
        var stdout = executeCodeCommand('', ['--help']).stdout;
        // Verify the "Available Commands:" header appears
        (0, globals_1.expect)(stdout).toContain('Available Commands:');
        (0, globals_1.expect)(stdout).toContain('Command');
        (0, globals_1.expect)(stdout).toContain('Description');
        // Verify each verb from the registry appears in the help output
        // Note: VERB_REGISTRY is guaranteed to be complete via compile-time type checks
        Object.entries(VerbRegistry_1.VERB_HELP_REGISTRY).forEach(function (_a) {
            var _b = __read(_a, 2), verb = _b[0], verbMetadata = _b[1];
            (0, globals_1.expect)(stdout).toContain(verb);
            (0, globals_1.expect)(stdout).toContain(verbMetadata.description);
        });
    });
    (0, globals_1.describe)('--help for each verb', function () {
        globals_1.it.each(VERBS_UNDER_TEST)('prints help for %s', function (_a) {
            var verb = _a.verb, usage = _a.usage, expectedText = _a.expectedText, options = _a.options;
            var executeCodeCommand = (0, testHelpers_1.createExecuteCodeCommand)({
                workingDirectory: projectRoot,
            });
            var _b = verb === '' ? executeCodeCommand('', ['--help']) : executeCodeCommand(verb, ['--help']), stdout = _b.stdout, stderr = _b.stderr;
            (0, globals_1.expect)(stderr).toBe('');
            (0, globals_1.expect)(stdout.length > 0).toBe(true);
            // Verify the expected usage line appears in help output.
            (0, globals_1.expect)(stdout).toContain(usage);
            // Normalize whitespace to handle line wrapping in help output
            var normalizedOutput = stdout.replace(/\s+/g, ' ');
            // Verify the expected description text appears in help output.
            if (expectedText) {
                var normalizedExpected = expectedText.replace(/\s+/g, ' ');
                (0, globals_1.expect)(normalizedOutput).toContain(normalizedExpected);
            }
            // Verify all option descriptions appear in help output.
            if (options) {
                Object.values(options).forEach(function (optionDesc) {
                    var normalizedOption = optionDesc.replace(/\s+/g, ' ');
                    (0, globals_1.expect)(normalizedOutput).toContain(normalizedOption);
                });
            }
        });
    });
});
//# sourceMappingURL=cliHelp.test.js.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listDatasetsAsync = void 0;
var ListDatasets_1 = require("@microsoft/powerapps-player-actions/lib/Actions/ListDatasets");
var powerapps_player_services_1 = require("@pa-client/powerapps-player-services");
var CliSettings_1 = require("../CliSettings");
var CliUtils_1 = require("../CliUtils");
var HelpStrings_1 = require("../Constants/HelpStrings");
var CliFs_1 = require("../FS/CliFs");
var VerbConstants_1 = require("./VerbConstants");
function listDatasetsAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var settings, fileConfig, cliFs, playerServiceConfig, authenticationProvider, dsConfig, datasets;
        var _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    settings = (0, CliSettings_1.getSettings)();
                    fileConfig = settings.fileConfig;
                    createOptionSchema(argumentProvider);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _c.sent();
                    cliFs = new CliFs_1.CliFS({
                        cwd: process.cwd(),
                        allowCwdRead: true,
                        allowCwdWrite: true,
                    });
                    playerServiceConfig = (0, powerapps_player_services_1.getPlayerServiceConfig)();
                    authenticationProvider = argumentProvider.getAuthenticationProvider();
                    _a = {
                        vfs: cliFs,
                        authProvider: authenticationProvider,
                        region: playerServiceConfig.region,
                        environmentName: playerServiceConfig.environmentName
                    };
                    _b = {};
                    return [4 /*yield*/, argumentProvider.getOption('apiId')];
                case 2:
                    _b.apiId = _c.sent();
                    return [4 /*yield*/, argumentProvider.getOption('connectionId')];
                case 3:
                    dsConfig = (_a.actionsParams = (_b.connectionId = _c.sent(),
                        _b),
                        _a.localFilePaths = {
                            powerConfigPath: fileConfig.powerConfigPath,
                            schemaPath: fileConfig.schemaPath,
                            codeGenPath: fileConfig.codeGenPath,
                        },
                        _a.logger = (0, CliSettings_1.getCliLogger)(),
                        _a);
                    return [4 /*yield*/, (0, ListDatasets_1.listDatasetsAsync)(dsConfig)];
                case 4:
                    datasets = _c.sent();
                    // Display header information
                    console.log('\n' + '='.repeat(80));
                    console.log("Datasets for ".concat(dsConfig.actionsParams.apiId));
                    console.log("Connection: ".concat(dsConfig.actionsParams.connectionId));
                    console.log('='.repeat(80));
                    // Display column headers
                    console.log('\n' + 'Display Name'.padEnd(40) + 'Name');
                    console.log('-'.repeat(80));
                    // Display each dataset
                    datasets.value.forEach(function (dataset) {
                        var name = dataset.Name;
                        var displayName = (dataset.DisplayName || '<No Display Name>').substring(0, 38).padEnd(40);
                        console.log(displayName + name);
                    });
                    console.log('-'.repeat(80));
                    return [2 /*return*/];
            }
        });
    });
}
exports.listDatasetsAsync = listDatasetsAsync;
function createOptionSchema(argumentProvider) {
    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs['List-datasets'].Description);
    argumentProvider.addOptions([
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.ApiId.name,
                alias: VerbConstants_1.SharedArguments.ApiId.alias,
            },
            env: VerbConstants_1.SharedArguments.ApiId.envVar,
            message: VerbConstants_1.SharedArguments.ApiId.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['List-datasets'].Options.ApiId,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.SharedArguments.ConnectionId.name,
                alias: VerbConstants_1.SharedArguments.ConnectionId.alias,
            },
            env: VerbConstants_1.SharedArguments.ConnectionId.envVar,
            message: VerbConstants_1.SharedArguments.ConnectionId.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs['List-datasets'].Options.ConnectionId,
        }),
    ]);
}
//# sourceMappingURL=ListDatasets.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { Logger } from './Logger.types';
export declare function setupLogger(logger: Logger): Promise<void>;
//# sourceMappingURL=LoggerManager.d.ts.map
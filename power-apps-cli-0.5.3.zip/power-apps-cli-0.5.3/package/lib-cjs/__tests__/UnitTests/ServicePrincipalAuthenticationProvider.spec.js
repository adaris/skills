"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var globals_1 = require("@jest/globals");
var acquireTokenByClientCredentialMock = 
// eslint-disable-next-line @typescript-eslint/no-explicit-any
globals_1.jest.fn();
globals_1.jest.mock('@azure/msal-node', function () { return ({
    __esModule: true,
    ConfidentialClientApplication: globals_1.jest.fn(),
}); });
var msal_node_1 = require("@azure/msal-node");
var ServicePrincipalAuthenticationProvider_1 = require("../../Authentication/ServicePrincipalAuthenticationProvider");
var MockedConfidentialClientApplication = msal_node_1.ConfidentialClientApplication;
(0, globals_1.describe)('ServicePrincipalAuthenticationProvider', function () {
    var originalEnv = __assign({}, process.env);
    var setValidEnv = function () {
        process.env.SP_CLIENT_ID = 'client-id';
        process.env.SP_CLIENT_SECRET = 'client-secret';
        process.env.SP_TENANT_ID = 'tenant-id';
    };
    (0, globals_1.beforeEach)(function () {
        acquireTokenByClientCredentialMock.mockReset();
        MockedConfidentialClientApplication.mockReset();
        MockedConfidentialClientApplication.mockImplementation(function () { return ({
            acquireTokenByClientCredential: acquireTokenByClientCredentialMock,
        }); });
        process.env = __assign({}, originalEnv);
        delete process.env.SP_CLIENT_ID;
        delete process.env.SP_CLIENT_SECRET;
        delete process.env.SP_TENANT_ID;
    });
    (0, globals_1.afterAll)(function () {
        process.env = originalEnv;
    });
    (0, globals_1.it)('throws when required environment variables are absent', function () {
        (0, globals_1.expect)(function () { return new ServicePrincipalAuthenticationProvider_1.ServicePrincipalAuthenticationProvider(); }).toThrow('Service Principal environment variables SP_CLIENT_ID, SP_CLIENT_SECRET, and SP_TENANT_ID must be set');
    });
    (0, globals_1.describe)('with valid environment configuration', function () {
        (0, globals_1.beforeEach)(function () {
            setValidEnv();
        });
        (0, globals_1.it)('initializes MSAL with the expected authority and credentials', function () { return __awaiter(void 0, void 0, void 0, function () {
            var provider;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        provider = new ServicePrincipalAuthenticationProvider_1.ServicePrincipalAuthenticationProvider();
                        return [4 /*yield*/, provider.initAsync()];
                    case 1:
                        _a.sent();
                        (0, globals_1.expect)(MockedConfidentialClientApplication).toHaveBeenCalledWith({
                            auth: {
                                clientId: 'client-id',
                                clientSecret: 'client-secret',
                                authority: 'https://login.microsoftonline.com/tenant-id',
                            },
                        });
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('acquires and returns an access token for the requested resource', function () { return __awaiter(void 0, void 0, void 0, function () {
            var provider, token;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        acquireTokenByClientCredentialMock.mockResolvedValueOnce({ accessToken: 'token-value' });
                        provider = new ServicePrincipalAuthenticationProvider_1.ServicePrincipalAuthenticationProvider();
                        return [4 /*yield*/, provider.initAsync()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, provider.getAccessTokenForResource('https://resource')];
                    case 2:
                        token = _a.sent();
                        (0, globals_1.expect)(acquireTokenByClientCredentialMock).toHaveBeenCalledWith({
                            scopes: ['https://resource/.default'],
                        });
                        (0, globals_1.expect)(token).toBe('token-value');
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('throws when MSAL returns no access token', function () { return __awaiter(void 0, void 0, void 0, function () {
            var provider;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        acquireTokenByClientCredentialMock.mockResolvedValueOnce(undefined);
                        provider = new ServicePrincipalAuthenticationProvider_1.ServicePrincipalAuthenticationProvider();
                        return [4 /*yield*/, provider.initAsync()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, (0, globals_1.expect)(provider.getAccessTokenForResource('https://resource')).rejects.toThrow('Failed to acquire token using service principal')];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('throws if getAccessTokenForResource is called before initAsync', function () { return __awaiter(void 0, void 0, void 0, function () {
            var provider;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        provider = new ServicePrincipalAuthenticationProvider_1.ServicePrincipalAuthenticationProvider();
                        return [4 /*yield*/, (0, globals_1.expect)(provider.getAccessTokenForResource('https://resource')).rejects.toThrow('Authentication not initialized yet')];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
    });
});
//# sourceMappingURL=ServicePrincipalAuthenticationProvider.spec.js.map
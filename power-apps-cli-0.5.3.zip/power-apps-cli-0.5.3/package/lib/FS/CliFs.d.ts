/// <reference types="node" />
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { Vfs, VfsConfig, VfsFileStats, WriteFileOptions } from '@microsoft/powerapps-player-actions/lib/Types/Vfs.types';
export declare class CliFS implements Vfs {
    private readonly cwd;
    constructor(config: VfsConfig);
    rmdir(dirPath: string): Promise<void>;
    /**
     * Normalize and resolve a path within the VFS context
     */
    private normalizePath;
    /**
     * Validate path for read access
     */
    private validateReadPath;
    /**
     * Validate path for write access
     */
    private validateWritePath;
    getCwd(): string;
    getAbsolutePath(relativePath: string): string;
    readFile(inputPath: string, encoding?: BufferEncoding): Promise<string>;
    writeFile(inputPath: string, content: string, options?: WriteFileOptions): Promise<void>;
    appendFile(inputPath: string, content: string): Promise<void>;
    readdir(inputPath: string): Promise<string[]>;
    mkdir(inputPath: string, options?: {
        recursive?: boolean;
    }): Promise<void>;
    exists(inputPath: string): Promise<boolean>;
    stat(inputPath: string): Promise<VfsFileStats>;
    isFile(inputPath: string): Promise<boolean>;
    isDirectory(inputPath: string): Promise<boolean>;
    resolve(...paths: string[]): string;
    join(...paths: string[]): string;
    relative(from: string, to: string): string;
    basename(inputPath: string): string;
    dirname(inputPath: string): string;
    unlink(inputPath: string): Promise<void>;
}
//# sourceMappingURL=CliFs.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var globals_1 = require("@jest/globals");
var CliLogger_1 = require("../../Logger/CliLogger");
var LoggerSettings_1 = require("../../Logger/LoggerSettings");
var ConsoleWriter_1 = require("../../Logger/ConsoleWriter");
var OneDSWriter_1 = require("../../Logger/OneDSWriter");
var CliSettings_1 = require("../../CliSettings");
var HttpClient_mocks_1 = require("@pa-client/powerapps-player-services/lib/__tests__/mocks/HttpClient.mocks");
var AuthenticationProvider_mocks_1 = require("../mocks/AuthenticationProvider.mocks");
var PowerAppsRpService_1 = require("@pa-client/powerapps-player-services/lib/Services/PowerAppsRp/PowerAppsRpService");
var fs = __importStar(require("fs"));
var config = {
    powerConfigPath: 'C:\\temp\\cliLogger\\power.config.json',
    schemaPath: 'C:\\temp\\cliLogger\\schema',
    codeGenPath: 'C:\\temp\\cliLogger\\src',
};
var mockPowerConfig = {
    appId: '',
    appDisplayName: 'cliLoggerApp',
    region: 'prod',
    environmentId: 'mockEnvId',
};
var cliSettings;
var mockHTTPClient = (0, HttpClient_mocks_1.getMockHttpClient)();
var mockAuthProvider = (0, AuthenticationProvider_mocks_1.getMockAuthenticationProvider)();
var createMockTelemetryWriter = function () { return ({
    trackActivityEvent: globals_1.jest.fn(),
    trackErrorEvent: globals_1.jest.fn(),
    startScenario: globals_1.jest.fn(),
    completeScenario: globals_1.jest.fn(),
    scenarioFailed: globals_1.jest.fn(),
    scenarioCompletedWithError: globals_1.jest.fn(),
    setCustomDimension: globals_1.jest.fn(),
    flush: globals_1.jest.fn(),
}); };
var consoleWriterInstances = [];
var oneDSWriterInstances = [];
globals_1.jest.mock('../../Logger/LoggerSettings', function () { return ({
    __esModule: true,
    resolveUserTelemetrySettings: globals_1.jest.fn(),
}); });
globals_1.jest.mock('../../Logger/ConsoleWriter', function () { return ({
    __esModule: true,
    ConsoleWriter: globals_1.jest.fn(function () {
        var instance = createMockTelemetryWriter();
        consoleWriterInstances.push(instance);
        return instance;
    }),
}); });
globals_1.jest.mock('../../Logger/OneDSWriter', function () { return ({
    __esModule: true,
    OneDSWriter: globals_1.jest.fn(function () {
        var instance = createMockTelemetryWriter();
        oneDSWriterInstances.push(instance);
        return instance;
    }),
}); });
globals_1.jest.mock('@pa-client/powerapps-player-services/lib/Services/PowerAppsRp/PowerAppsRpService', function () { return ({
    __esModule: true,
    getEnvironmentByName: globals_1.jest.fn(),
}); });
var mockedResolve = LoggerSettings_1.resolveUserTelemetrySettings;
var ConsoleWriterMock = ConsoleWriter_1.ConsoleWriter;
var OneDSWriterMock = OneDSWriter_1.OneDSWriter;
var mockedGetEnvironmentByName = PowerAppsRpService_1.getEnvironmentByName;
var getInternalWriters = function (instance) {
    return instance._telemetryWriters;
};
var setInternalWriters = function (instance, writers) {
    instance._telemetryWriters = writers;
};
(0, globals_1.describe)('CliLogger', function () {
    var defaultSettings = { enabled: false, consoleOnly: false, outputToConsole: false };
    (0, globals_1.beforeAll)(function () { return __awaiter(void 0, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    fs.mkdirSync('C:\\temp\\cliLogger', { recursive: true });
                    fs.writeFileSync(config.powerConfigPath, JSON.stringify(mockPowerConfig), 'utf-8');
                    return [4 /*yield*/, (0, CliSettings_1.initializeCliSettings)(true, config)];
                case 1:
                    cliSettings = _a.sent();
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.beforeEach)(function () {
        globals_1.jest.clearAllMocks();
        consoleWriterInstances.length = 0;
        oneDSWriterInstances.length = 0;
        mockedResolve.mockReturnValue(defaultSettings);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        mockedGetEnvironmentByName.mockResolvedValue(null);
    });
    (0, globals_1.describe)('trackActivityEvent', function () {
        (0, globals_1.it)('calls telemetry writer when logging is enabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger, writerInstance;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        writerInstance = oneDSWriterInstances[0];
                        logger.trackActivityEvent('testEvent', { key: 'value' });
                        (0, globals_1.expect)(writerInstance).toBeDefined();
                        (0, globals_1.expect)(writerInstance.trackActivityEvent).toHaveBeenCalledWith('testEvent', { key: 'value' });
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('skips writers when telemetry is disabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: false, consoleOnly: false, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        logger.trackActivityEvent('testEvent', {});
                        (0, globals_1.expect)(OneDSWriterMock).not.toHaveBeenCalled();
                        (0, globals_1.expect)(ConsoleWriterMock).not.toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('respects writer state changes at runtime', function () { return __awaiter(void 0, void 0, void 0, function () {
            var mockWriter, logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockWriter = createMockTelemetryWriter();
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        setInternalWriters(logger, [mockWriter]);
                        logger.trackActivityEvent('event1', {});
                        (0, globals_1.expect)(mockWriter.trackActivityEvent).toHaveBeenCalledTimes(1);
                        setInternalWriters(logger, []);
                        logger.trackActivityEvent('event2', {});
                        (0, globals_1.expect)(mockWriter.trackActivityEvent).toHaveBeenCalledTimes(1);
                        setInternalWriters(logger, [mockWriter]);
                        logger.trackActivityEvent('event3', {});
                        (0, globals_1.expect)(mockWriter.trackActivityEvent).toHaveBeenCalledTimes(2);
                        return [2 /*return*/];
                }
            });
        }); });
    });
    (0, globals_1.describe)('trackErrorEvent', function () {
        (0, globals_1.it)('calls telemetry writer when logging is enabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger, writerInstance;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        writerInstance = oneDSWriterInstances[0];
                        logger.trackErrorEvent('errorEvent', { error: 'test' });
                        (0, globals_1.expect)(writerInstance.trackErrorEvent).toHaveBeenCalledWith('errorEvent', { error: 'test' });
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('skips writers when telemetry is disabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: false, consoleOnly: false, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        logger.trackErrorEvent('errorEvent', {});
                        (0, globals_1.expect)(OneDSWriterMock).not.toHaveBeenCalled();
                        (0, globals_1.expect)(ConsoleWriterMock).not.toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('respects writer state changes at runtime', function () { return __awaiter(void 0, void 0, void 0, function () {
            var mockWriter, logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockWriter = createMockTelemetryWriter();
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        setInternalWriters(logger, [mockWriter]);
                        logger.trackErrorEvent('error1', {});
                        (0, globals_1.expect)(mockWriter.trackErrorEvent).toHaveBeenCalledTimes(1);
                        setInternalWriters(logger, []);
                        logger.trackErrorEvent('error2', {});
                        (0, globals_1.expect)(mockWriter.trackErrorEvent).toHaveBeenCalledTimes(1);
                        setInternalWriters(logger, [mockWriter]);
                        logger.trackErrorEvent('error3', {});
                        (0, globals_1.expect)(mockWriter.trackErrorEvent).toHaveBeenCalledTimes(2);
                        return [2 /*return*/];
                }
            });
        }); });
    });
    (0, globals_1.describe)('trackScenario', function () {
        (0, globals_1.it)('creates active scenarios when telemetry is enabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger, writerInstance, scenario;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        writerInstance = oneDSWriterInstances[0];
                        scenario = logger.trackScenario('testScenario', { data: 'test' });
                        (0, globals_1.expect)(writerInstance.startScenario).toHaveBeenCalledWith('testScenario', globals_1.expect.objectContaining({ data: 'test' }));
                        (0, globals_1.expect)(scenario.scenarioId).not.toBe('disabled');
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('returns no-op scenario when telemetry is disabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger, scenario;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        scenario = logger.trackScenario('testScenario');
                        (0, globals_1.expect)(scenario.scenarioId).toBe('disabled');
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('no-op scenario methods do not call writers', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger, scenario;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        scenario = logger.trackScenario('testScenario');
                        scenario.complete({ result: 'success' });
                        scenario.failure({ reason: 'test' });
                        scenario.completeWithError({ error: 'test error' });
                        // nothing to assert besides no throw
                        (0, globals_1.expect)(scenario.scenarioId).toBe('disabled');
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('invokes scenario completion handlers when enabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var mockWriter, logger, scenario;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockWriter = createMockTelemetryWriter();
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        setInternalWriters(logger, [mockWriter]);
                        scenario = logger.trackScenario('testScenario');
                        scenario.complete({ result: 'success' });
                        (0, globals_1.expect)(mockWriter.completeScenario).toHaveBeenCalled();
                        scenario.failure({ reason: 'failure' });
                        (0, globals_1.expect)(mockWriter.scenarioFailed).toHaveBeenCalled();
                        scenario.completeWithError({ error: 'boom' });
                        (0, globals_1.expect)(mockWriter.scenarioCompletedWithError).toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
    });
    (0, globals_1.describe)('Multiple telemetry writers', function () {
        (0, globals_1.it)('calls all writers when logging is enabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var writer1, writer2, logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        writer1 = createMockTelemetryWriter();
                        writer2 = createMockTelemetryWriter();
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        setInternalWriters(logger, [writer1, writer2]);
                        logger.trackActivityEvent('testEvent', {});
                        (0, globals_1.expect)(writer1.trackActivityEvent).toHaveBeenCalled();
                        (0, globals_1.expect)(writer2.trackActivityEvent).toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('skips all writers when telemetry is disabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var writer1, writer2, logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        writer1 = createMockTelemetryWriter();
                        writer2 = createMockTelemetryWriter();
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        setInternalWriters(logger, []);
                        logger.trackActivityEvent('testEvent', {});
                        (0, globals_1.expect)(writer1.trackActivityEvent).not.toHaveBeenCalled();
                        (0, globals_1.expect)(writer2.trackActivityEvent).not.toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
    });
    (0, globals_1.describe)('stringifyError', function () {
        var logger;
        (0, globals_1.beforeEach)(function () { return __awaiter(void 0, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('returns undefined for falsy values', function () {
            (0, globals_1.expect)(logger.stringifyError(null)).toBeUndefined();
            (0, globals_1.expect)(logger.stringifyError(undefined)).toBeUndefined();
            (0, globals_1.expect)(logger.stringifyError(false)).toBeUndefined();
            (0, globals_1.expect)(logger.stringifyError(0)).toBeUndefined();
            (0, globals_1.expect)(logger.stringifyError('')).toBeUndefined();
        });
        (0, globals_1.it)('formats Error objects', function () {
            var error = new Error('test message');
            var result = logger.stringifyError(error);
            (0, globals_1.expect)(result).toContain('Error');
            (0, globals_1.expect)(result).toContain('test message');
        });
        (0, globals_1.it)('includes stack trace when available', function () {
            var error = new Error('with stack');
            var result = logger.stringifyError(error);
            (0, globals_1.expect)(result).toBeDefined();
        });
        (0, globals_1.it)('stringifies objects', function () {
            var obj = { key: 'value', number: 42 };
            var result = logger.stringifyError(obj);
            (0, globals_1.expect)(result).toBe(JSON.stringify(obj));
        });
        (0, globals_1.it)('falls back to String() when JSON.stringify fails', function () {
            var circularObj = { key: 'value' };
            circularObj.self = circularObj;
            var result = logger.stringifyError(circularObj);
            (0, globals_1.expect)(typeof result).toBe('string');
        });
    });
    (0, globals_1.describe)('wiring up telemetry writers', function () {
        (0, globals_1.it)('creates console-only logger when consoleOnly flag is set', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: true, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).not.toHaveBeenCalled();
                        (0, globals_1.expect)(ConsoleWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(getInternalWriters(logger)).toEqual([consoleWriterInstances[0]]);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('creates OneDS writer when telemetry is enabled', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(ConsoleWriterMock).not.toHaveBeenCalled();
                        (0, globals_1.expect)(getInternalWriters(logger)).toEqual([oneDSWriterInstances[0]]);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('adds console writer when outputToConsole is true', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: true });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(ConsoleWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(getInternalWriters(logger)).toEqual([oneDSWriterInstances[0], consoleWriterInstances[0]]);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('creates console writer when telemetry disabled but outputToConsole true', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: false, consoleOnly: false, outputToConsole: true });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).not.toHaveBeenCalled();
                        (0, globals_1.expect)(ConsoleWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(getInternalWriters(logger)).toEqual([consoleWriterInstances[0]]);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('creates no writers when telemetry disabled and no console output', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: false, consoleOnly: false, outputToConsole: false });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(getInternalWriters(logger)).toHaveLength(0);
                        (0, globals_1.expect)(ConsoleWriterMock).not.toHaveBeenCalled();
                        (0, globals_1.expect)(OneDSWriterMock).not.toHaveBeenCalled();
                        return [2 /*return*/];
                }
            });
        }); });
    });
    (0, globals_1.describe)('getEnvironmentByName behavior', function () {
        (0, globals_1.it)('creates OneDS writer with EU location when environment is in EU region', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        mockedGetEnvironmentByName.mockResolvedValueOnce({
                            id: 'mockEnvId',
                            name: 'mockEnv',
                            properties: {
                                location: 'norway',
                                cluster: {
                                    geoShortName: 'EUR',
                                    environment: 'Prod',
                                    category: 'Prod',
                                    number: '001',
                                    uriSuffix: 'crm4.dynamics.com',
                                },
                            },
                        });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledWith(globals_1.expect.any(String), // sessionId
                        'prod', // region
                        'eu', // telemetryLocation
                        'mockEnvId', // environmentId
                        '', // appId
                        'EUR' // geoShortName
                        );
                        (0, globals_1.expect)(getInternalWriters(logger)).toHaveLength(1);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('creates OneDS writer with global location when environment is not in EU region', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        mockedGetEnvironmentByName.mockResolvedValueOnce({
                            id: 'mockEnvId',
                            name: 'mockEnv',
                            properties: {
                                location: 'westus',
                                cluster: {
                                    geoShortName: 'NAM',
                                    environment: 'Prod',
                                    category: 'Prod',
                                    number: '001',
                                    uriSuffix: 'crm.dynamics.com',
                                },
                            },
                        });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledWith(globals_1.expect.any(String), // sessionId
                        'prod', // region
                        'global', // telemetryLocation
                        'mockEnvId', // environmentId
                        '', // appId
                        'NAM' // geoShortName
                        );
                        (0, globals_1.expect)(getInternalWriters(logger)).toHaveLength(1);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('handles null environment metadata gracefully', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        mockedGetEnvironmentByName.mockResolvedValueOnce(null);
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledWith(globals_1.expect.any(String), // sessionId
                        'prod', // region
                        'global', // telemetryLocation (default)
                        'mockEnvId', // environmentId
                        '', // appId
                        undefined // geoShortName
                        );
                        (0, globals_1.expect)(getInternalWriters(logger)).toHaveLength(1);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('handles environment metadata without cluster information', function () { return __awaiter(void 0, void 0, void 0, function () {
            var logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        mockedGetEnvironmentByName.mockResolvedValueOnce({
                            id: 'mockEnvId',
                            name: 'mockEnv',
                            properties: {
                                location: 'westus',
                            },
                        });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledTimes(1);
                        (0, globals_1.expect)(OneDSWriterMock).toHaveBeenCalledWith(globals_1.expect.any(String), 'prod', 'global', 'mockEnvId', '', undefined // no cluster geoShortName
                        );
                        (0, globals_1.expect)(getInternalWriters(logger)).toHaveLength(1);
                        return [2 /*return*/];
                }
            });
        }); });
        (0, globals_1.it)('handles getEnvironmentByName errors and falls back gracefully', function () { return __awaiter(void 0, void 0, void 0, function () {
            var consoleErrorSpy, logger;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        mockedResolve.mockReturnValueOnce({ enabled: true, consoleOnly: false, outputToConsole: false });
                        mockedGetEnvironmentByName.mockRejectedValueOnce(new Error('Network error'));
                        consoleErrorSpy = globals_1.jest.spyOn(console, 'error').mockImplementation(function () { });
                        return [4 /*yield*/, CliLogger_1.CliLogger.create(cliSettings, mockHTTPClient, mockAuthProvider)];
                    case 1:
                        logger = _a.sent();
                        (0, globals_1.expect)(consoleErrorSpy).toHaveBeenCalledWith('CliLogger: failed to initialize OneDS telemetry writer', globals_1.expect.any(Error));
                        (0, globals_1.expect)(OneDSWriterMock).not.toHaveBeenCalled();
                        (0, globals_1.expect)(getInternalWriters(logger)).toHaveLength(0);
                        consoleErrorSpy.mockRestore();
                        return [2 /*return*/];
                }
            });
        }); });
    });
});
//# sourceMappingURL=CliLogger.test.js.map
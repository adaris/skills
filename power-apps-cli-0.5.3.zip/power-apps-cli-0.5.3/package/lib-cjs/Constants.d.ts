/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare const APP_CONFIG_FILE = "power.config.json";
export declare const WORKING_DIRECTORY: string;
export declare const CLI_CONFIG_DIRECTORY: string;
export declare const AUTH_CACHE_DIRECTORY: string;
export declare const MS_CLIENT_REQUESTID = "x-ms-client-request-id";
export declare const USER_SETTINGS_FILE = "userSettings.json";

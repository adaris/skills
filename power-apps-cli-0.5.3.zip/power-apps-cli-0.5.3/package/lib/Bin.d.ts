#!/usr/bin/env node
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export {};
//# sourceMappingURL=Bin.d.ts.map
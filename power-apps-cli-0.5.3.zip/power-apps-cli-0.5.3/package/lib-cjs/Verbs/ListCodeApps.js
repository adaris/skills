"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCodeAppsAsync = void 0;
var PowerAppsRpService_1 = require("@pa-client/powerapps-player-services/lib/Services/PowerAppsRp/PowerAppsRpService");
var HelpStrings_1 = require("../Constants/HelpStrings");
function getCodeAppsAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var codeApps, filteredCodeApps;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs['List-codeapps'].Description);
                    // No options, so can just run directly
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    // No options, so can just run directly
                    _a.sent();
                    return [4 /*yield*/, (0, PowerAppsRpService_1.listAppsAsync)()];
                case 2:
                    codeApps = _a.sent();
                    filteredCodeApps = codeApps
                        .filter(function (app) { return app.appType === 'CodeApp'; })
                        .map(function (app) { return ({
                        appId: app.name,
                        name: app.properties.displayName,
                    }); });
                    if (filteredCodeApps.length === 0) {
                        console.log('No code apps found.');
                        return [2 /*return*/];
                    }
                    // Create a formatted table
                    console.log('\nCode Apps:');
                    console.log('─'.repeat(80));
                    console.log('App ID'.padEnd(40) + 'Display Name');
                    console.log('─'.repeat(80));
                    filteredCodeApps.forEach(function (app) {
                        var appId = app.appId.length > 38 ? app.appId.substring(0, 35) + '...' : app.appId;
                        var displayName = app.name || '<No Name>';
                        console.log(appId.padEnd(40) + displayName);
                    });
                    console.log('─'.repeat(80));
                    console.log("Total: ".concat(filteredCodeApps.length, " code app(s) found\n"));
                    return [2 /*return*/];
            }
        });
    });
}
exports.getCodeAppsAsync = getCodeAppsAsync;
//# sourceMappingURL=ListCodeApps.js.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var globals_1 = require("@jest/globals");
var fs = __importStar(require("fs"));
var path = __importStar(require("path"));
var TelemetrySettings_1 = require("../../Verbs/TelemetrySettings");
var Constants_1 = require("../../Constants");
var MockArgumentProvider_1 = require("../mocks/MockArgumentProvider");
// Hijack fs so the telemetry verb never touches the real disk during tests.
// We pull the helper via requireActual because Jest hoists mock factories and we still want
// the type information plus a fresh in-memory store per test suite. The __state escape hatch
// is only used inside this file to reset/inspect the fake filesystem between cases.
globals_1.jest.mock('fs', function () {
    var createInMemoryFs = globals_1.jest.requireActual('../mocks/inMemoryFs').createInMemoryFs;
    var state = createInMemoryFs();
    return __assign(__assign({}, state.module), { __state: state });
});
var fsMock = fs;
var mockFsState = fsMock.__state;
var USER_SETTINGS_PATH = path.join(Constants_1.CLI_CONFIG_DIRECTORY, Constants_1.USER_SETTINGS_FILE);
(0, globals_1.describe)('modifyTelemetrySettings', function () {
    var consoleLogSpy;
    var consoleErrorSpy;
    (0, globals_1.beforeEach)(function () {
        mockFsState.reset();
        consoleLogSpy = globals_1.jest.spyOn(console, 'log').mockImplementation(function () { return undefined; });
        consoleErrorSpy = globals_1.jest.spyOn(console, 'error').mockImplementation(function () { return undefined; });
    });
    (0, globals_1.afterEach)(function () {
        consoleLogSpy.mockRestore();
        consoleErrorSpy.mockRestore();
    });
    (0, globals_1.it)('throws when both enable and disable switches are set', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        enable: true,
                        disable: true,
                        showSettings: undefined,
                        consoleOnly: 'false',
                        outputToConsole: 'false',
                    });
                    return [4 /*yield*/, (0, globals_1.expect)((0, TelemetrySettings_1.modifyTelemetrySettings)(provider)).rejects.toThrow('Cannot enable and disable telemetry at the same time.')];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('shows telemetry settings without writing when showSettings flag is provided', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    mockFsState.seedFile(USER_SETTINGS_PATH, JSON.stringify({ enabled: false, consoleOnly: true, outputToConsole: false }));
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        showSettings: true,
                        consoleOnly: 'false',
                        outputToConsole: 'false',
                    });
                    return [4 /*yield*/, (0, TelemetrySettings_1.modifyTelemetrySettings)(provider)];
                case 1:
                    _a.sent();
                    (0, globals_1.expect)(mockFsState.module.readFileSync).toHaveBeenCalledWith(USER_SETTINGS_PATH, 'utf-8');
                    (0, globals_1.expect)(mockFsState.module.writeFileSync).not.toHaveBeenCalled();
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('logs an error if showSettings cannot read the stored settings', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        showSettings: true,
                    });
                    mockFsState.module.existsSync.mockReturnValueOnce(true);
                    mockFsState.module.readFileSync.mockImplementationOnce(function () {
                        throw new Error('read failure');
                    });
                    return [4 /*yield*/, (0, TelemetrySettings_1.modifyTelemetrySettings)(provider)];
                case 1:
                    _a.sent();
                    (0, globals_1.expect)(consoleErrorSpy).toHaveBeenCalledWith('Failed to display telemetry settings: read failure');
                    (0, globals_1.expect)(mockFsState.module.writeFileSync).not.toHaveBeenCalled();
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('creates telemetry settings file when directory is missing', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        enable: true,
                        consoleOnly: 'true',
                        outputToConsole: 'false',
                    });
                    return [4 /*yield*/, (0, TelemetrySettings_1.modifyTelemetrySettings)(provider)];
                case 1:
                    _a.sent();
                    (0, globals_1.expect)(mockFsState.module.mkdirSync).toHaveBeenCalledWith(Constants_1.CLI_CONFIG_DIRECTORY, { recursive: true });
                    (0, globals_1.expect)(mockFsState.module.writeFileSync).toHaveBeenCalledWith(USER_SETTINGS_PATH, JSON.stringify({ enabled: true, consoleOnly: true, outputToConsole: false }, null, 2), 'utf-8');
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('merges existing enabled flag when toggles are omitted', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider, persisted;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    mockFsState.seedFile(USER_SETTINGS_PATH, JSON.stringify({ enabled: false, consoleOnly: false, outputToConsole: false }));
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        consoleOnly: 'false',
                        outputToConsole: 'true',
                    });
                    return [4 /*yield*/, (0, TelemetrySettings_1.modifyTelemetrySettings)(provider)];
                case 1:
                    _a.sent();
                    persisted = mockFsState.readFile(USER_SETTINGS_PATH);
                    (0, globals_1.expect)(persisted).toBeDefined();
                    (0, globals_1.expect)(JSON.parse(persisted)).toEqual({
                        enabled: false,
                        consoleOnly: false,
                        outputToConsole: true,
                    });
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('preserves console settings when they are not provided', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider, persisted;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    mockFsState.seedFile(USER_SETTINGS_PATH, JSON.stringify({ enabled: false, consoleOnly: true, outputToConsole: false }));
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        enable: true,
                    });
                    return [4 /*yield*/, (0, TelemetrySettings_1.modifyTelemetrySettings)(provider)];
                case 1:
                    _a.sent();
                    persisted = mockFsState.readFile(USER_SETTINGS_PATH);
                    (0, globals_1.expect)(persisted).toBeDefined();
                    (0, globals_1.expect)(JSON.parse(persisted)).toEqual({
                        enabled: true,
                        consoleOnly: true,
                        outputToConsole: false,
                    });
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('surface fs write failures with context', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        disable: true,
                        consoleOnly: 'false',
                        outputToConsole: 'false',
                    });
                    mockFsState.module.writeFileSync.mockImplementationOnce(function () {
                        throw new Error('disk full');
                    });
                    return [4 /*yield*/, (0, globals_1.expect)((0, TelemetrySettings_1.modifyTelemetrySettings)(provider)).rejects.toThrow('Failed to update telemetry settings: disk full')];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('bubbles JSON parse failures when existing settings are corrupt', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    mockFsState.seedFile(USER_SETTINGS_PATH, '{ invalid json');
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        disable: true,
                        consoleOnly: 'false',
                        outputToConsole: 'false',
                    });
                    return [4 /*yield*/, (0, globals_1.expect)((0, TelemetrySettings_1.modifyTelemetrySettings)(provider)).rejects.toThrow('Failed to update telemetry settings:')];
                case 1:
                    _a.sent();
                    (0, globals_1.expect)(mockFsState.module.writeFileSync).not.toHaveBeenCalled();
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.it)('throws when the telemetry directory cannot be created', function () { return __awaiter(void 0, void 0, void 0, function () {
        var provider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    provider = new MockArgumentProvider_1.MockArgumentProvider({
                        enable: true,
                        consoleOnly: 'false',
                        outputToConsole: 'false',
                    });
                    mockFsState.module.existsSync.mockImplementationOnce(function () { return false; });
                    mockFsState.module.mkdirSync.mockImplementationOnce(function () {
                        throw new Error('permission denied');
                    });
                    return [4 /*yield*/, (0, globals_1.expect)((0, TelemetrySettings_1.modifyTelemetrySettings)(provider)).rejects.toThrow('Failed to update telemetry settings: permission denied')];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); });
});
//# sourceMappingURL=TelemetrySettings.test.js.map
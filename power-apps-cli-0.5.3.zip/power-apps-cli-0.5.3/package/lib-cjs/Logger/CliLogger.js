"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CliLogger = void 0;
var initializePlayerServices_1 = require("@pa-client/powerapps-player-services/lib/initializePlayerServices");
var PowerAppsRpService_1 = require("@pa-client/powerapps-player-services/lib/Services/PowerAppsRp/PowerAppsRpService");
var crypto_1 = require("crypto");
var ConsoleWriter_1 = require("./ConsoleWriter");
var Constants_1 = require("./Constants");
var LoggerSettings_1 = require("./LoggerSettings");
var OneDSWriter_1 = require("./OneDSWriter");
/**
 * Utility method to create a Scenario
 *
 * @param {ITelemetryWriter[]} telemetryWriters
 * @param {string} name
 * @param {object} [data]
 * @returns {Scenario}
 */
function createScenarioLogger(telemetryWriters, name, data) {
    var scenarioGuid = (0, crypto_1.randomUUID)();
    var _start = Date.now();
    try {
        telemetryWriters.forEach(function (writer) {
            return writer.startScenario(name, __assign(__assign({ scenarioGuid: scenarioGuid }, data), { scenarioStartTime: _start }));
        });
    }
    catch (_a) {
        // No-op. Telemetry failures should not block CLI operations
    }
    var base = {
        scenarioId: scenarioGuid,
        complete: function (completeData) {
            try {
                telemetryWriters.forEach(function (writer) {
                    return writer.completeScenario(name, __assign({ scenarioGuid: scenarioGuid, elapsedTime: Date.now() - _start, totalElapsedTime: Date.now() - _start }, completeData));
                });
            }
            catch (_a) {
                // No-op. Telemetry failures should not block CLI operations
            }
        },
        failure: function (failureData) {
            try {
                telemetryWriters.forEach(function (writer) {
                    return writer.scenarioFailed(name, __assign({ scenarioGuid: scenarioGuid, elapsedTime: Date.now() - _start, totalElapsedTime: Date.now() - _start }, failureData));
                });
            }
            catch (_a) {
                // No-op. Telemetry failures should not block CLI operations
            }
        },
        completeWithError: function (dataWithErr) {
            try {
                telemetryWriters.forEach(function (writer) {
                    return writer.scenarioCompletedWithError(name, __assign({ scenarioGuid: scenarioGuid, elapsedTime: Date.now() - _start, totalElapsedTime: Date.now() - _start }, dataWithErr));
                });
            }
            catch (_a) {
                // No-op. Telemetry failures should not block CLI operations
            }
        },
    };
    base._start = _start;
    return base;
}
/**
 * Logger implementation for the CLI
 * The logger depends on the CLISettings, HttpClient and authenticationProvider to initialize the OneDS writer
 */
var CliLogger = /** @class */ (function () {
    function CliLogger(telemetryWriters) {
        this._telemetryWriters = [];
        this._telemetryWriters = telemetryWriters;
    }
    CliLogger.create = function (cliSettings, httpClient, authenticationProvider) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        return __awaiter(this, void 0, void 0, function () {
            var environmentId, region, appId, sessionId, telemetryWriters, userTelemetrySettings, addConsoleWriter, metadata, telemetryLocation, error_1, instance;
            return __generator(this, function (_j) {
                switch (_j.label) {
                    case 0:
                        environmentId = (_a = cliSettings.appConfig) === null || _a === void 0 ? void 0 : _a.environmentId;
                        region = (_b = cliSettings.appConfig) === null || _b === void 0 ? void 0 : _b.region;
                        appId = (_c = cliSettings.appConfig) === null || _c === void 0 ? void 0 : _c.appId;
                        sessionId = (0, crypto_1.randomUUID)();
                        telemetryWriters = [];
                        userTelemetrySettings = (0, LoggerSettings_1.resolveUserTelemetrySettings)();
                        addConsoleWriter = function () { return telemetryWriters.push(new ConsoleWriter_1.ConsoleWriter()); };
                        if (userTelemetrySettings.consoleOnly) {
                            addConsoleWriter();
                            return [2 /*return*/, new CliLogger(telemetryWriters)];
                        }
                        if (!(userTelemetrySettings.enabled && region && environmentId)) return [3 /*break*/, 4];
                        _j.label = 1;
                    case 1:
                        _j.trys.push([1, 3, , 4]);
                        // Initialize player services to get environment metadata
                        (0, initializePlayerServices_1.initializePlayerServices)({
                            httpClient: httpClient,
                            environmentName: ((_d = cliSettings.appConfig) === null || _d === void 0 ? void 0 : _d.environmentId) || 'default',
                            region: ((_e = cliSettings.appConfig) === null || _e === void 0 ? void 0 : _e.region) || 'prod',
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        });
                        return [4 /*yield*/, (0, PowerAppsRpService_1.getEnvironmentByName)(environmentId)];
                    case 2:
                        metadata = _j.sent();
                        telemetryLocation = 'global';
                        if (((_f = metadata === null || metadata === void 0 ? void 0 : metadata.properties) === null || _f === void 0 ? void 0 : _f.location) && Constants_1.EUGeoRegions.has(metadata.properties.location)) {
                            telemetryLocation = 'eu';
                        }
                        telemetryWriters.push(new OneDSWriter_1.OneDSWriter(sessionId, region, telemetryLocation, environmentId, appId !== null && appId !== void 0 ? appId : '', (_h = (_g = metadata === null || metadata === void 0 ? void 0 : metadata.properties) === null || _g === void 0 ? void 0 : _g.cluster) === null || _h === void 0 ? void 0 : _h.geoShortName));
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _j.sent();
                        console.error('CliLogger: failed to initialize OneDS telemetry writer', error_1);
                        return [3 /*break*/, 4];
                    case 4:
                        if (userTelemetrySettings.outputToConsole) {
                            addConsoleWriter();
                        }
                        instance = new CliLogger(telemetryWriters);
                        if (authenticationProvider.getUserTenantId()) {
                            // At this point if the auth provider has fetched a token, we can set the tenantId dimension
                            instance.setCustomDimension('tenantId', authenticationProvider.getUserTenantId());
                        }
                        return [2 /*return*/, instance];
                }
            });
        });
    };
    CliLogger.prototype.setCustomDimension = function (_key, _value) {
        try {
            if (!_key || !_value) {
                return;
            }
            this._telemetryWriters.forEach(function (writer) {
                writer.setCustomDimension(_key, _value);
            });
        }
        catch (_a) {
            // No-op. Telemetry failures should not block CLI operations
        }
    };
    CliLogger.prototype.trackActivityEvent = function (eventName, eventData) {
        try {
            if (this._telemetryWriters.length === 0) {
                return;
            }
            this._telemetryWriters.forEach(function (writer) { return writer.trackActivityEvent(eventName, eventData); });
        }
        catch (_a) {
            // No-op. Telemetry failures should not block CLI operations
        }
    };
    CliLogger.prototype.trackErrorEvent = function (eventName, eventData) {
        try {
            if (this._telemetryWriters.length === 0) {
                return;
            }
            this._telemetryWriters.forEach(function (writer) { return writer.trackErrorEvent(eventName, eventData); });
        }
        catch (_a) {
            // No-op. Telemetry failures should not block CLI operations
        }
    };
    CliLogger.prototype.trackScenario = function (eventName, eventData) {
        try {
            if (this._telemetryWriters.length === 0) {
                // Return a no-op scenario so callers don't have to check telemetry state
                return {
                    scenarioId: 'disabled',
                    complete: function () { return undefined; },
                    failure: function () { return undefined; },
                    completeWithError: function () { return undefined; },
                };
            }
            return createScenarioLogger(this._telemetryWriters, eventName, eventData);
        }
        catch (_a) {
            // No-op. Telemetry failures should not block CLI operations
            return {
                scenarioId: 'error',
                complete: function () { return undefined; },
                failure: function () { return undefined; },
                completeWithError: function () { return undefined; },
            };
        }
    };
    CliLogger.prototype.stringifyError = function (err) {
        if (!err) {
            return undefined;
        }
        if (err instanceof Error) {
            return "".concat(err.name, ": ").concat(err.message).concat(err.stack ? '\n' + err.stack : '');
        }
        try {
            return JSON.stringify(err);
        }
        catch (_a) {
            return String(err);
        }
    };
    CliLogger.prototype.flush = function () {
        return Promise.all(this._telemetryWriters.map(function (writer) { return writer.flush(); })).then(function () { return undefined; });
    };
    return CliLogger;
}());
exports.CliLogger = CliLogger;
//# sourceMappingURL=CliLogger.js.map
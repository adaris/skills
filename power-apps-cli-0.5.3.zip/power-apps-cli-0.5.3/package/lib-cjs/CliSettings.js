"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSettings = exports.getCliLogger = exports.setCliLogger = exports.initializeCliSettings = void 0;
var Constants_1 = require("./Constants");
var ConfigManager_1 = require("@microsoft/powerapps-player-actions/lib/Config/ConfigManager");
var CliFs_1 = require("./FS/CliFs");
var VfsManager_1 = require("@microsoft/powerapps-player-actions/lib/VfsManager");
var _cliSettings;
var _logger;
/**
 *
 * @param {boolean} [skipInteractivePrompts=false] - Whether the argument provider should skip interactive prompts
 * @param {LocalFilePaths} [fileConfig={
 *     powerConfigPath: `${WORKING_DIRECTORY}/${APP_CONFIG_FILE}`,
 *     schemaPath: `${WORKING_DIRECTORY}/.power/schemas`,
 *     codeGenPath: `${WORKING_DIRECTORY}/src`,
 *   }]
 * @param {ILogger} logger
 */
function initializeCliSettings(skipInteractivePrompts, fileConfig) {
    if (skipInteractivePrompts === void 0) { skipInteractivePrompts = false; }
    if (fileConfig === void 0) { fileConfig = {
        powerConfigPath: "".concat(Constants_1.WORKING_DIRECTORY, "/").concat(Constants_1.APP_CONFIG_FILE),
        schemaPath: "".concat(Constants_1.WORKING_DIRECTORY, "/.power/schemas"),
        codeGenPath: "".concat(Constants_1.WORKING_DIRECTORY, "/src"),
    }; }
    return __awaiter(this, void 0, void 0, function () {
        var cliFs, appConfig, error_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    cliFs = new CliFs_1.CliFS({
                        cwd: process.cwd(),
                        allowCwdRead: true,
                        allowCwdWrite: true,
                    });
                    // Set VFS at initialize to read the config
                    (0, VfsManager_1.setVfs)(cliFs);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, (0, ConfigManager_1.readRepoConfig)(fileConfig.powerConfigPath)];
                case 2:
                    appConfig = _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _a.sent();
                    return [3 /*break*/, 4];
                case 4:
                    _cliSettings = {
                        source: skipInteractivePrompts ? 'pac-cli' : 'standalone',
                        fileConfig: fileConfig,
                        cliFs: cliFs,
                        appConfig: appConfig,
                    };
                    return [2 /*return*/, _cliSettings];
            }
        });
    });
}
exports.initializeCliSettings = initializeCliSettings;
function setCliLogger(logger) {
    _logger = logger;
}
exports.setCliLogger = setCliLogger;
function getCliLogger() {
    if (!_logger) {
        // return a no-op logger if not initialized to prevent crashes
        /* eslint-disable no-empty-function */
        return {
            trackActivityEvent: function (eventName, eventData) { },
            trackErrorEvent: function (eventName, eventData) { },
            trackScenario: function (name, scenarioData) {
                return {
                    scenarioId: '',
                    complete: function (endScenarioData) { },
                    failure: function (failureData) { },
                    completeWithError: function (completeWithErrorData) { },
                };
            },
            stringifyError: function (err) {
                return null;
            },
        };
    }
    /* eslint-enable no-empty-function */
    return _logger;
}
exports.getCliLogger = getCliLogger;
function getSettings() {
    if (!_cliSettings) {
        throw new Error('CLI settings have not been initialized. Please call initializeCliSettings first.');
    }
    return _cliSettings;
}
exports.getSettings = getSettings;
//# sourceMappingURL=CliSettings.js.map
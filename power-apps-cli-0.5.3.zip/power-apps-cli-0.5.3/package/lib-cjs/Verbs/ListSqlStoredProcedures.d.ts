/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function listSqlStoredProceduresAsync(argumentProvider: ArgumentProvider): Promise<void>;

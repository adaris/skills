/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export { getClient } from './powerAppsData';
export type { DataClient } from './Data.types';
export type { IOperationOptions, IOperationResult } from '../internal/data/core/types';
//# sourceMappingURL=index.d.ts.map
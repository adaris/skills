/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function pushAsync(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=Push.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { DataSourcesInfo, IOperationResult } from '../types';
/**
 * Creates a new record in the specified table.
 * @param dataSourcesInfo - The data sources information.
 * @param tableName - The name of the table to create the record in.
 * @param record - The record to create.
 * @returns A promise that resolves to the created record.
 */
export declare function createRecordAsync<TInput, TResult>(dataSourcesInfo: DataSourcesInfo, tableName: string, record: TInput): Promise<IOperationResult<TResult>>;
//# sourceMappingURL=createRecord.d.ts.map
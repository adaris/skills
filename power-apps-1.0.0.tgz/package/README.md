# Power Apps client library

This project contains the APIs needed to:

- Initialize apps that can be hosted in the Power Platform.
- Enable developers to interact with data sources including multiple connectors and Dataverse.

## Getting Started

Go to the [instructions](https://github.com/microsoft/PowerAppsCodeApps) to get samples, tutorials and more information about code apps.

## Installation

```bash
npm install @microsoft/power-apps
```

## Usage

Install the package using npm.

The following APIs and types are available:

```typescript
import { initialize } from '@microsoft/power-apps/app';
```

Make sure the initialize API is the first thing your app calls. Failing to do so will result in the app failing to load. If data calls are made before initialize is completed this will cause the data retrieval to be unsuccessful.

```typescript
import {
  createRecordAsync,
  retrieveRecordAsync,
  retrieveMultipleRecordsAsync,
  updateRecordAsync,
  deleteRecordAsync,
  executeAsync,
  type IOperationOptions,
  type IOperationResult,
} from '@microsoft/power-apps/data';
```

This package works seamlessly with the Power Apps code generation tools to create strongly typed models and services. The code generator automatically creates TypeScript interfaces and service classes based on your data sources.

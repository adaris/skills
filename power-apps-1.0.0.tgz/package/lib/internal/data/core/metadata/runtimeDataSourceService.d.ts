/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IPowerDataSourcesInfoProvider } from '../common/types';
import { DataSourcesInfo, IDataSourceInfo } from '../types';
/**
 * Error types specific to RuntimeDataSourceService
 */
export declare enum DataSourceServiceError {
}
/**
 * RuntimeDataSourceService provides functionality for managing and retrieving
 * data source information.
 */
export declare class RuntimeDataSourceService {
    private _powerDataSourcesInfoProvider;
    /**
     * Data source information
     */
    private _dataSourcesInfo;
    /**
     * Indicates whether the service has been initialized
     */
    private _isInitialized;
    /**
     * Creates a new instance of RuntimeDataSourceService
     */
    constructor(_powerDataSourcesInfoProvider: IPowerDataSourcesInfoProvider);
    /**
     * Initializes the service by loading user data sources
     * @throws PowerDataRuntimeError if initialization fails
     */
    initialize(): Promise<void>;
    /**
     * Gets all user data sources
     * @returns Array of data source information
     * @throws PowerDataRuntimeError if service is not initialized
     */
    getUserDataSources(): Promise<DataSourcesInfo>;
    /**
     * Gets information for a specific data source
     * @param dataSource - The ID of the data source
     * @returns Data source information
     * @throws PowerDataRuntimeError if data source is not found or service is not initialized
     */
    getDataSource(dataSource: string): Promise<IDataSourceInfo>;
    /**
     * Checks if a data source exists
     * @param dataSourceId - The ID of the data source to check
     * @returns True if the data source exists, false otherwise
     * @throws PowerDataRuntimeError if service is not initialized
     */
    hasDataSource(dataSource: string): Promise<boolean>;
    /**
     * Ensures the service is initialized
     * @throws PowerDataRuntimeError if service is not initialized
     */
    private _ensureInitialized;
    /**
     * Gets user data sources from the provided data source schemas
     * @returns Promise resolving to array of data source information
     */
    private _getUserDataSources;
}
//# sourceMappingURL=runtimeDataSourceService.d.ts.map
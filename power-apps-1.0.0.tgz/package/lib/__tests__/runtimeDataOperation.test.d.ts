/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export {};
//# sourceMappingURL=runtimeDataOperation.test.d.ts.map
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInMemoryFs = void 0;
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var globals_1 = require("@jest/globals");
var path = __importStar(require("path"));
function createInMemoryFs() {
    var files = {};
    var directories = new Set();
    var module = {
        existsSync: globals_1.jest.fn(function (target) { return target in files || directories.has(target); }),
        readFileSync: globals_1.jest.fn(function (target) {
            if (!(target in files)) {
                throw new Error("ENOENT: no such file or directory, open '".concat(target, "'"));
            }
            return files[target];
        }),
        writeFileSync: globals_1.jest.fn(function (target, contents) {
            files[target] = contents;
            directories.add(path.dirname(target));
        }),
        mkdirSync: globals_1.jest.fn(function (target) {
            directories.add(target);
        }),
    };
    return {
        module: module,
        reset: function () {
            var e_1, _a;
            try {
                for (var _b = __values(Object.keys(files)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var key = _c.value;
                    delete files[key];
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            directories.clear();
            module.existsSync.mockClear();
            module.readFileSync.mockClear();
            module.writeFileSync.mockClear();
            module.mkdirSync.mockClear();
        },
        seedFile: function (filePath, content) {
            files[filePath] = content;
            directories.add(path.dirname(filePath));
        },
        readFile: function (filePath) { return files[filePath]; },
        ensureDirectory: function (dirPath) {
            directories.add(dirPath);
        },
        getDirectories: function () { return Array.from(directories.values()); },
    };
}
exports.createInMemoryFs = createInMemoryFs;
//# sourceMappingURL=inMemoryFs.js.map
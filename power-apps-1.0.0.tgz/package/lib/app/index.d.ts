/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export { initialize } from './Lifecycle';
//# sourceMappingURL=index.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IOperationContext, IRuntimeDataClient } from '../common/types';
import { HttpMethod } from '../common/types';
import { IOperationResult, IPowerOperationExecutor } from '../types';
/**
 * RuntimeDataClient handles data operations through PowerOperationExecutor
 */
export declare class RuntimeDataClient implements IRuntimeDataClient {
    private readonly _powerOperationExecutor;
    private static readonly SERVICES;
    private static readonly ACTIONS;
    private static readonly REQUEST_SOURCE;
    constructor(_powerOperationExecutor: IPowerOperationExecutor);
    /**
     * Creates a new instance of RuntimeDataClient
     */
    static createInstanceAsync(powerOperationExecutor: IPowerOperationExecutor): Promise<IRuntimeDataClient>;
    /**
     * Creates data using POST method
     * @param url - The URL for the request
     * @param apiId - The API ID for authentication
     * @param tableName - The name of the table to access
     * @param body - The request body for the POST method
     * @param operationName - Optional operation name for telemetry
     * @return Promise resolving to the response data
     * @throws Error if the request fails or the response is invalid
     * @throws Error if the request body is invalid
     */
    createDataAsync<TRequest, TResponse>(url: string, apiId: string, tableName: string, body: TRequest, context?: IOperationContext): Promise<IOperationResult<TResponse>>;
    /**
     * Updates data using PATCH method
     * @param url - The URL for the request
     * @param apiId - The API ID for authentication
     * @param tableName - The name of the table to access
     * @param body - The request body for the PATCH method
     * @param operationName - Optional operation name for telemetry
     * @return Promise resolving to the response data
     * @throws Error if the request fails or the response is invalid
     * @throws Error if the request body is invalid
     */
    updateDataAsync<TRequest, TResponse>(url: string, apiId: string, tableName: string, body: TRequest, context?: IOperationContext): Promise<IOperationResult<TResponse>>;
    /**
     * Deletes data using DELETE method
     * @param url - The URL for the request
     * @param connectionApi - The API ID for authentication
     * @param serviceNamespace - The name of the service namespace
     * @param operationName - Optional operation name for telemetry
     * @return Promise resolving to the response data
     * @throws Error if the request fails or the response is invalid
     */
    deleteDataAsync(url: string, connectionApi: string, serviceNamespace: string, context?: IOperationContext): Promise<IOperationResult<void>>;
    /**
     * Retrieves data using GET or POST method
     * @param url - The URL for the request
     * @param apiId - The API ID for authentication
     * @param tableName - The name of the table to access
     * @param method - The HTTP method
     * @param body - Optional request body for POST method
     * @param context - Optional operation context
     * @param operationName - Optional operation name for telemetry
     * @return Promise resolving to the response data
     * @throws Error if the request fails or the response is invalid
     */
    retrieveDataAsync<TRequest, TResponse>(url: string, apiId: string, tableName: string, method: HttpMethod, headers?: {
        [key: string]: string;
    }, body?: unknown, context?: IOperationContext): Promise<IOperationResult<TResponse>>;
    /**
     * Gets an access token for the specified API.
     * If the API is Dataverse, retrieves a dynamic resource token; otherwise, retrieves a standard appservice API token.
     * @param apiId - The API ID for authentication
     * @param datasetName - Optional dataset name for Dataverse
     * @returns Promise resolving to the access token
     * @throws Error if token acquisition fails
     */
    private _getAccessToken;
    private _mergePreferHeaders;
    /**
     * Creates headers for the HTTP request.
     * Combines default headers with any custom headers provided in the config.
     * Custom headers are optional and take precedence over default headers.
     * @param token - The access token for authentication
     * @param config - The HTTP request configuration
     * @return The headers for the request
     * @throws Error if header creation fails
     */
    private _createHeaders;
    /**
     * Executes an HTTP request with the given configuration
     * @param config - The HTTP request configuration
     * @param context - Optional operation context
     * @return Promise resolving to the response data
     * @throws Error if the request fails or the response is invalid
     * @throws Error if the response content type is invalid
     */
    private _executeRequest;
    private _ensureContext;
    /**
     * Checks if the given URL is a Dataverse API call
     * @param url - The URL to check
     * @returns True if the URL is a Dataverse API call, false otherwise
     */
    private _isDataverseCall;
    /**
     * Decodes ArrayBuffer to string, handling both browser and Node.js environments
     * @param buffer - The ArrayBuffer to decode
     * @returns The decoded string
     */
    private _decodeArrayBuffer;
}
//# sourceMappingURL=runtimeDataClient.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 * This file is auto-generated. Do not modify it manually.
 * Changes to this file may be overwritten.
 */
export declare const dataSourcesInfo: {
    contacts: {
        tableId: string;
        version: string;
        primaryKey: string;
        dataSourceType: string;
        apis: {};
    };
    translatorv2: {
        tableId: string;
        version: string;
        primaryKey: string;
        dataSourceType: string;
        apis: {
            Languages: {
                path: string;
                method: string;
                parameters: ({
                    name: string;
                    in: string;
                    required: boolean;
                    type: string;
                    default: null;
                } | {
                    name: string;
                    in: string;
                    required: boolean;
                    type: string;
                    default: string;
                })[];
                responseInfo: {
                    '200': {
                        type: string;
                        format: null;
                    };
                };
            };
            Translate: {
                path: string;
                method: string;
                parameters: {
                    name: string;
                    in: string;
                    required: boolean;
                    type: string;
                    default: null;
                }[];
                responseInfo: {
                    '200': {
                        type: string;
                        format: null;
                    };
                };
            };
            Detect: {
                path: string;
                method: string;
                parameters: {
                    name: string;
                    in: string;
                    required: boolean;
                    type: string;
                    default: null;
                }[];
                responseInfo: {
                    '200': {
                        type: string;
                        format: null;
                    };
                };
            };
        };
    };
    paruntimedb: {
        tableId: string;
        version: string;
        primaryKey: string;
        dataSourceType: string;
        apis: {
            GetRecordById: {
                path: string;
                method: string;
                parameters: {
                    name: string;
                    in: string;
                    required: boolean;
                    type: string;
                    default: null;
                }[];
                responseInfo: {};
            };
        };
    };
};

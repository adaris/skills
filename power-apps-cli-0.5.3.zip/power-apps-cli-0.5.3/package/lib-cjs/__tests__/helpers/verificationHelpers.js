"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.countConnectionEntries = exports.hasGeneratedReference = void 0;
/**
 * Helper functions for verifying CLI command results and file system state
 */
/**
 * Check if a power.config.json has generated connection or database references
 */
function hasGeneratedReference(config) {
    var connectionReferences = config.connectionReferences;
    var databaseReferences = config.databaseReferences;
    return (Boolean(connectionReferences && Object.keys(connectionReferences).length > 0) ||
        Boolean(databaseReferences && Object.keys(databaseReferences).length > 0));
}
exports.hasGeneratedReference = hasGeneratedReference;
/**
 * Count the number of connection reference entries in a config
 */
function countConnectionEntries(config) {
    var connectionReferences = config.connectionReferences;
    if (!connectionReferences) {
        return 0;
    }
    return Object.keys(connectionReferences).length;
}
exports.countConnectionEntries = countConnectionEntries;
//# sourceMappingURL=verificationHelpers.js.map
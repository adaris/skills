"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pushAsync = void 0;
var powerapps_player_actions_1 = require("@microsoft/powerapps-player-actions");
var prompts = __importStar(require("@clack/prompts"));
var CliSettings_1 = require("../CliSettings");
var powerapps_player_services_1 = require("@pa-client/powerapps-player-services");
var PowerAppsRpService_1 = require("@pa-client/powerapps-player-services/lib/Services/PowerAppsRp/PowerAppsRpService");
var DataverseSystemDataService_1 = require("@pa-client/powerapps-player-services/lib/Services/Dataverse/DataverseSystemDataService");
var CliUtils_1 = require("../CliUtils");
var HelpStrings_1 = require("../Constants/HelpStrings");
function pushAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var settings, appConfig, fileConfig, cliFs, playerServiceConfig, authenticationProvider, pushConfig, app;
        var _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    settings = (0, CliSettings_1.getSettings)();
                    appConfig = settings.appConfig, fileConfig = settings.fileConfig, cliFs = settings.cliFs;
                    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs.Push.Description);
                    playerServiceConfig = (0, powerapps_player_services_1.getPlayerServiceConfig)();
                    createOptionSchema(argumentProvider, playerServiceConfig.httpClient, appConfig === null || appConfig === void 0 ? void 0 : appConfig.environmentId, appConfig === null || appConfig === void 0 ? void 0 : appConfig.appId);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _c.sent();
                    if (!appConfig) {
                        throw new Error('power.config.json is required to push an app');
                    }
                    if (!appConfig.environmentId) {
                        throw new Error('Environment ID is required in power.config.json to push an app');
                    }
                    if (!appConfig.region) {
                        appConfig.region = 'prod';
                    }
                    authenticationProvider = argumentProvider.getAuthenticationProvider();
                    _a = {
                        vfs: cliFs
                    };
                    _b = {};
                    return [4 /*yield*/, argumentProvider.getOption('solutionId')];
                case 2:
                    pushConfig = (_a.actionsParams = (_b.solutionId = _c.sent(),
                        _b.appName = appConfig.appId,
                        _b),
                        _a.environmentName = appConfig.environmentId,
                        _a.region = appConfig.region || 'prod',
                        _a.authProvider = authenticationProvider,
                        _a.localFilePaths = fileConfig,
                        _a.logger = (0, CliSettings_1.getCliLogger)(),
                        _a.httpClient = playerServiceConfig.httpClient,
                        _a);
                    return [4 /*yield*/, (0, powerapps_player_actions_1.pushApp)(pushConfig)];
                case 3:
                    app = _c.sent();
                    console.log("App pushed successfully. You can play your app at ".concat(app.properties.appPlayUri));
                    return [2 /*return*/];
            }
        });
    });
}
exports.pushAsync = pushAsync;
function createOptionSchema(argumentProvider, httpClient, environmentId, appId) {
    var _this = this;
    argumentProvider.addOption({
        flags: {
            key: 'solutionId',
            alias: 's',
        },
        env: 'SOLUTION_NAME',
        description: HelpStrings_1.HelpStrings.Verbs.Push.Options.SolutionName,
        customPrompt: function () { return __awaiter(_this, void 0, void 0, function () {
            var inPreferredSolution, environmentDetails, dvService, orgUrl, preferredSolutionId, solutionName_1, environmentDetails, dvService, orgUrl, solutions, solutionId;
            var _a, _b, _c;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        if (!environmentId) {
                            throw new Error('Environment ID is required');
                        }
                        if (!!appId) return [3 /*break*/, 8];
                        return [4 /*yield*/, prompts.select({
                                message: 'Do you want this app in the preferred solution, a specific solution, or no solution?',
                                options: [
                                    { value: 'preferred', label: 'Preferred Solution' },
                                    { value: 'specific', label: 'Specific Solution' },
                                    { value: 'none', label: 'No Solution' },
                                ],
                            })];
                    case 1:
                        inPreferredSolution = _d.sent();
                        if (!(inPreferredSolution === 'preferred')) return [3 /*break*/, 4];
                        return [4 /*yield*/, (0, PowerAppsRpService_1.getEnvironmentByName)(environmentId)];
                    case 2:
                        environmentDetails = _d.sent();
                        dvService = new DataverseSystemDataService_1.DataverseSystemDataService(httpClient);
                        orgUrl = (_a = environmentDetails.properties.linkedEnvironmentMetadata) === null || _a === void 0 ? void 0 : _a.instanceUrl;
                        if (!orgUrl) {
                            throw new Error('Organization URL is not available for the specified environment.');
                        }
                        return [4 /*yield*/, dvService.getPreferredSolution(orgUrl)];
                    case 3:
                        preferredSolutionId = _d.sent();
                        if (!preferredSolutionId) {
                            throw new Error('No preferred solution found in the specified environment.');
                        }
                        return [2 /*return*/, preferredSolutionId];
                    case 4:
                        if (!(inPreferredSolution === 'specific')) return [3 /*break*/, 8];
                        return [4 /*yield*/, prompts.text({
                                message: 'Please enter the solution name or ID:',
                            })];
                    case 5:
                        solutionName_1 = (_d.sent());
                        // If it is a GUID, return as is
                        if ((0, CliUtils_1.isGuid)(solutionName_1)) {
                            return [2 /*return*/, solutionName_1];
                        }
                        return [4 /*yield*/, (0, PowerAppsRpService_1.getEnvironmentByName)(environmentId)];
                    case 6:
                        environmentDetails = _d.sent();
                        dvService = new DataverseSystemDataService_1.DataverseSystemDataService(httpClient);
                        orgUrl = (_b = environmentDetails.properties.linkedEnvironmentMetadata) === null || _b === void 0 ? void 0 : _b.instanceUrl;
                        if (!orgUrl) {
                            throw new Error('Organization URL is not available for the specified environment.');
                        }
                        return [4 /*yield*/, dvService.getSolutions(orgUrl)];
                    case 7:
                        solutions = _d.sent();
                        solutionId = (_c = solutions.find(function (solution) {
                            return solution.friendlyname.toLowerCase() === solutionName_1.toLowerCase() ||
                                solution.uniquename.toLowerCase() === solutionName_1.toLowerCase();
                        })) === null || _c === void 0 ? void 0 : _c.solutionid;
                        if (!solutionId) {
                            throw new Error("Solution with name '".concat(solutionName_1, "' not found."));
                        }
                        return [2 /*return*/, solutionId];
                    case 8: 
                    // If none, return empty
                    return [2 /*return*/, ''];
                }
            });
        }); },
    });
}
//# sourceMappingURL=Push.js.map
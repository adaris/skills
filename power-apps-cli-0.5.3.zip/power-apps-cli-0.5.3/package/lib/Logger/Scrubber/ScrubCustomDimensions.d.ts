/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare function getScrubbedCustomDimensions(eventName: string, operationName: string, customDimensions: object): object;
//# sourceMappingURL=ScrubCustomDimensions.d.ts.map
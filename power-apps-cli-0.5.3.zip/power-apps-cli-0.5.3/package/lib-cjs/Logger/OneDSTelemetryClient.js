"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OneDSTelemetryClient = void 0;
// This module is a copy of the OneDSTelemetryClient from powerapps-webplayer-telemetry,
// modified to work in the CLI environment - without browser dependencies.
var _1ds_analytics_js_1 = require("@microsoft/1ds-analytics-js");
var OneDSPropertyStorageOverride_1 = require("./OneDSPropertyStorageOverride");
var ScrubCustomDimensions_1 = require("./Scrubber/ScrubCustomDimensions");
var TelemetryTableName = 'event';
var PropertyToColumn = {
    operationName: 'operation_Name',
    tenantId: 'tenantId',
    oid: 'objectId',
    scenarioName: 'scenarioName',
    scenarioGuid: 'scenarioGuid',
    scenarioResult: 'scenarioResult',
    sequenceNumber: 'sequenceNumber',
    environmentId: 'environmentId',
    duration: 'duration',
    latencyInMs: 'duration',
    elapsedTime: 'duration',
    apiId: 'apiId',
    updateCadence: 'updateCadence',
    url: 'url',
    requestedUrl: 'url',
    status: 'httpStatus',
    httpStatus: 'httpStatus',
    statusCode: 'httpStatus',
    httpMethod: 'httpMethod',
    webPlayerUrl: 'webPlayerUrl',
    playerAppId: 'playerAppId',
    appSequenceNumber: 'appSequenceNumber',
};
// See: https://github.com/microsoft/ApplicationInsights-JS/blob/main/shared/AppInsightsCore/src/JavaScriptSDK.Enums/EventsDiscardedReason.ts
var DiscardReasons = [
    'Unknown',
    'NonRetryableStatus',
    'InvalidEvent',
    'SizeLimitExceeded',
    'KillSwitch',
    'QueueFull',
];
var OneDSTelemetryClient = /** @class */ (function () {
    /**
     *
     * @param region: The region
     * @param telemetryLocation: The telemetry location
     * @param tenantId: The tenant ID
     * @param ariaProjectIds: The aria project id's
     */
    function OneDSTelemetryClient(region, telemetryLocation, tenantId, ariaProjectIds) {
        var _this = this;
        this._sequenceNumber = 1;
        this._expectedCoreSequenceNumber = 1;
        this._discardedBatches = [];
        this._defaultCustomDimensions = {};
        this._telemetryLocation = telemetryLocation;
        var config = this._getOneDSConfig(region, ariaProjectIds);
        this._analytics = new _1ds_analytics_js_1.ApplicationInsights();
        // Initialize SDK
        this._analytics.initialize(config, []);
        this._analytics.addNotificationListener({
            eventsSent: function () {
                try {
                    if (_this._discardedBatches.length > 0) {
                        // Send a separate discard summary for each batch
                        _this._discardedBatches.forEach(function (batch) {
                            _this.trackDiscardedTelemetrySummary(batch.summary, batch.totalEvents);
                        });
                    }
                }
                catch (error) {
                    console.error('Error logging dropped telemetry summary:', error);
                }
                // Clear discarded batches. If the discard summary then gets dropped, it will
                // show up in the summary for the next drop, so we at least know we dropped
                // the discard summary though will lose the details, but in aggregate we
                // should be able to get information on systemically dropped telemetry
                _this._discardedBatches = [];
            },
            eventsDiscarded: function (events, reason) {
                try {
                    // See maxEventRetryAttempts comment below to test drop handling.
                    var discardReason_1 = reason < DiscardReasons.length ? DiscardReasons[reason] : "Reason-".concat(reason);
                    var discardSummary_1 = {};
                    events.forEach(function (event) {
                        var _a, _b, _c, _d;
                        var discardKey = "".concat(event.name, ":").concat(((_a = event.data) === null || _a === void 0 ? void 0 : _a.event_Name) || '', ":").concat(((_b = event.data) === null || _b === void 0 ? void 0 : _b.operation_Name) || '', ":").concat(((_c = event.data) === null || _c === void 0 ? void 0 : _c.scenarioName) || '', ":").concat(((_d = event.data) === null || _d === void 0 ? void 0 : _d.scenarioResult) || '', ":").concat(discardReason_1);
                        // Estimate event size as JSON string length
                        var eventSize = 0;
                        try {
                            eventSize = JSON.stringify(event).length;
                        }
                        catch (_e) {
                            // If JSON.stringify fails, use max safe integer to flag as problematic
                            eventSize = Number.MAX_SAFE_INTEGER;
                        }
                        // Increment the discard count and track max size for this event
                        if (!discardSummary_1[discardKey]) {
                            discardSummary_1[discardKey] = { count: 1, maxSize: eventSize };
                        }
                        else {
                            discardSummary_1[discardKey].count += 1;
                            if (eventSize > discardSummary_1[discardKey].maxSize) {
                                discardSummary_1[discardKey].maxSize = eventSize;
                            }
                        }
                    });
                    // Add this batch to the discarded batches array
                    _this._discardedBatches.push({
                        summary: discardSummary_1,
                        totalEvents: events.length,
                    });
                }
                catch (error) {
                    console.error('Error capturing discarded telemetry events:', error);
                }
            },
        });
        this._propertyManager = this._analytics.getPropertyManager();
        // The 1DS SDK is populating MicrosoftApplicationsTelemetryDeviceId into sdk.installId eg: ext.sdk.installId.
        // Populating it into ext.device.localId requires a prefix -
        //
        // https://msazure.visualstudio.com/DefaultCollection/One/_git/CommonSchema?path=/v4.0/Types/DeviceId.md&_a=preview
        //
        // ... but MicrosoftApplicationsTelemetryDeviceId does not work with c: (triggers InvalidHashIdentifiersFlag
        // error from collector) and is not well-aligned to d: (deidentified)
        //
        // The work-around is to read it manually and write it to DeviceInfo_Id as a part C property, which
        // provides compatibility with what the aria SDK was doing.
        //
        // See also:
        // https://msazure.visualstudio.com/One/_git/1DS.JavaScript?path=/extensions/properties/README.md&_a=preview
        // https://msazure.visualstudio.com/DefaultCollection/One/_git/CommonSchema?path=/v4.0/Types/DeviceId.md&_a=preview
        //
        // The cookie manager is replaced by a property storage override for the CLI.
        var cookieMgr = this._propertyManager.core.getCookieMgr();
        var deviceId = cookieMgr.get('MicrosoftApplicationsTelemetryDeviceId');
        // Telemetry initializers are used to modify the contents of collected
        // telemetry before being sent from the user's browser.
        // More Info here: https://github.com/Microsoft/ApplicationInsights-JS#example-setting-cloud-role-name
        // We use the telemetry initializer here to modify the names of the fields
        this._analytics.addTelemetryInitializer(function (envelope) {
            var _a, _b, _c, _d, _e, _f;
            var data = (_a = envelope.data) !== null && _a !== void 0 ? _a : {};
            var ext = (_b = envelope.ext) !== null && _b !== void 0 ? _b : {};
            // Set some common properties for backwards compatibility with the aria SDK implementation
            data.timestamp = envelope.time || 0;
            data.app_Name =
                region === 'preprod' || region === 'test' || region === 'local' || region === 'dev'
                    ? 'powerappsclientnonprod'
                    : 'powerappsclient';
            data.device_Id = 'browser';
            // Aria will map Part A columns like UserInfo, DeviceInfo from data.ext, see:
            // https://aka.ms/CommonSchema
            // https://msazure.visualstudio.com/DefaultCollection/One/_git/CommonSchema?path=/v4.0/Mappings/Aria.md&_a=preview
            //
            // For anonymous events, selectively populate key columns
            if (data.anonymous) {
                // Don't setup UserInfo / DeviceInfo / Session_Id for anonymous events
                data = {
                    app_Name: data.app_Name,
                    app_Version: data.app_Version,
                    clientType: data.clientType,
                    clusterCategory: data.clusterCategory,
                    clusterEnvironment: data.clusterEnvironment,
                    customDimensions: data.customDimensions,
                    device_Id: data.device_Id,
                    DeviceInfo_Id: 'anonymous',
                    event_Name: data.event_Name,
                    operation_Name: data.operation_Name,
                    timestamp: data.timestamp,
                    serverLocation: data.serverLocation,
                    session_Id: 'anonymous',
                };
                // Set a subset of ext for anonymous events as this will get logged as Part A CommonSchema columns
                ext = {
                    app: {
                        locale: (_c = ext.app) === null || _c === void 0 ? void 0 : _c.locale,
                    },
                    loc: {
                        tz: (_d = ext.loc) === null || _d === void 0 ? void 0 : _d.tz,
                    },
                    sdk: {
                        ver: (_e = ext.sdk) === null || _e === void 0 ? void 0 : _e.ver,
                    },
                    user: {
                        locale: (_f = ext.user) === null || _f === void 0 ? void 0 : _f.locale,
                    },
                };
            }
            else {
                // See MicrosoftApplicationsTelemetryDeviceId comment above
                data.DeviceInfo_Id = deviceId;
            }
            // Sync 1DS session id with CLI session id
            ext.app = ext.app || {};
            ext.app.sesId = _this.sessionId;
            // Sync the installId with DeviceInfo_Id
            ext.sdk = ext.sdk || {};
            ext.sdk.installId = deviceId;
            // Update the envelope
            envelope.ext = ext;
            envelope.data = data;
            // Clear baseData as this will get logged as Part B columns which we don't use.
            envelope.baseData = undefined;
            envelope.baseType = 'custom';
        });
    }
    Object.defineProperty(OneDSTelemetryClient.prototype, "sessionId", {
        get: function () {
            return this._sessionId || '';
        },
        set: function (value) {
            this._sessionId = value;
            this.setDefaultProperty('session_Id', value);
        },
        enumerable: false,
        configurable: true
    });
    /**
     * This function logs user id/geo information to the common context
     * @param tenantId
     * @param oid
     * @returns true if we can log user information, false if we cannot log user information.
     */
    OneDSTelemetryClient.prototype.identifyUser = function (tenantId, oid) {
        this._addToTopLevelContext('objectId', oid);
        this._addToTopLevelContext('tenantId', tenantId);
        this._addToTopLevelContext('distinct_id', tenantId + oid);
        return true;
    };
    /**
     * This public method logs properties into data.context object
     *
     * @param propertyName: Any valid JSON string key
     *
     * @param propertyValue: Any valid string value
     */
    OneDSTelemetryClient.prototype.setDefaultProperty = function (propertyName, propertyValue, isCustomDimension) {
        if (isCustomDimension) {
            this._defaultCustomDimensions[propertyName] = propertyValue;
        }
        else {
            this._propertyManager.setProperty(propertyName, propertyValue);
        }
    };
    /**
     * This private method logs properties directly into data object - these
     * properties are logged as context i.e. once they're set, they show up
     * in each log entry
     *
     * @param propertyName: Any valid JSON string key
     *
     * @param propertyValue: Any valid string value
     */
    OneDSTelemetryClient.prototype._addToTopLevelContext = function (propertyName, propertyValue) {
        this._propertyManager.setProperty(propertyName, propertyValue);
    };
    OneDSTelemetryClient.prototype.trackEvent = function (eventName, eventData) {
        var data = this._getProperties(eventName, eventData);
        // Web Player does not log through the Core Logger. Core Logger
        // adds a sequence number, web player does not, but it is desirable
        // to have sequence numbers on all webplayer-telemetry messages, so
        // add sequencing in here at the telemetry provider layer.
        if (data.sequenceNumber !== undefined && typeof data.sequenceNumber === 'number') {
            if (data.sequenceNumber === this._expectedCoreSequenceNumber) {
                // Core set a sequence number, and was in sequence with our expectations
                this._expectedCoreSequenceNumber++;
            }
            else {
                // Core set a sequence number, but it was out of sequence, store this in
                // unexpectedSequenceNumber and reset our expectations
                data.unexpectedSequenceNumber = data.sequenceNumber;
                this._expectedCoreSequenceNumber = data.sequenceNumber + 1;
            }
        }
        data.sequenceNumber = this._sequenceNumber++;
        var telemetryItem = {
            name: TelemetryTableName,
            data: data,
        };
        this._analytics.track(telemetryItem);
    };
    /**
     * Track an anonymous telemetry event with no EUPI for the given data
     * @param eventName The name of the event.
     * @param data The event data to send.
     */
    OneDSTelemetryClient.prototype.trackAnonymousEvent = function (eventName, eventData) {
        var data = {};
        var operationName = eventData.operationName || '';
        // Set a few key properties, like the previous aria implementation
        data.event_Name = eventName;
        data.operation_Name = operationName;
        data.customDimensions = JSON.stringify((0, ScrubCustomDimensions_1.getScrubbedCustomDimensions)(eventName, operationName, eventData));
        // This is checked & removed in the addTelemetryInitializer code above.
        data.anonymous = true;
        var telemetryItem = {
            name: TelemetryTableName,
            data: data,
        };
        this._analytics.track(telemetryItem);
    };
    OneDSTelemetryClient.prototype.flush = function () {
        var asyncFlush = false; // Flush synchronously
        this._analytics.flush(asyncFlush);
    };
    /**
     * Tracks a summary of discarded telemetry events, reporting the top 10 most frequent discard reasons by count and by size.
     *
     * @param discardSummary - A record where the key is a string describing the discard reason and the value contains count and maxSize.
     * @param totalEvents - The total number of events in the discarded batch.
     */
    OneDSTelemetryClient.prototype.trackDiscardedTelemetrySummary = function (discardSummary, totalEvents) {
        var entries = Object.entries(discardSummary);
        // Sort by count (descending) and take top 10
        var top10ByCount = entries
            .sort(function (_a, _b) {
            var _c = __read(_a, 2), a = _c[1];
            var _d = __read(_b, 2), b = _d[1];
            return b.count - a.count;
        })
            .slice(0, 10)
            .map(function (_a) {
            var _b = __read(_a, 2), key = _b[0], obj = _b[1];
            return ({ key: key, count: obj.count, maxSize: obj.maxSize });
        });
        // Sort by maxSize (descending) and take top 10
        var top10BySize = entries
            .sort(function (_a, _b) {
            var _c = __read(_a, 2), a = _c[1];
            var _d = __read(_b, 2), b = _d[1];
            return b.maxSize - a.maxSize;
        })
            .slice(0, 10)
            .map(function (_a) {
            var _b = __read(_a, 2), key = _b[0], obj = _b[1];
            return ({ key: key, count: obj.count, maxSize: obj.maxSize });
        });
        // trackEvent will promote operationName to a top-level operation_Name property
        // via PropertyToColumn mapping, operationName is correct for property name.
        this.trackEvent('PowerAppsClient.Error', {
            operationName: 'TelemetryProvider.DiscardedTelemetrySummary',
            totalEvents: totalEvents,
            top10ByCount: top10ByCount,
            top10BySize: top10BySize,
        });
    };
    OneDSTelemetryClient.prototype._getProperties = function (eventName, eventData) {
        var data = {
            event_Name: eventName,
        };
        var customDimensions = (0, ScrubCustomDimensions_1.getScrubbedCustomDimensions)(eventName, eventData.operationName || '', __assign(__assign({}, this._defaultCustomDimensions), eventData));
        Object.entries(customDimensions).forEach(function (_a) {
            var _b = __read(_a, 2), key = _b[0], value = _b[1];
            // Promote some custom dimensions to top level columns
            var column = PropertyToColumn[key];
            if (column) {
                data[column] = value;
            }
        });
        data.customDimensions = JSON.stringify(customDimensions);
        return data;
    };
    OneDSTelemetryClient.prototype._getOneDSConfig = function (region, ariaProjectIds) {
        var instrumentationKey;
        var collectorUrl;
        switch (region) {
            case 'preview':
            case 'prod':
                instrumentationKey = ariaProjectIds.Production;
                collectorUrl = this._getCollectorEndpoint(this._telemetryLocation);
                break;
            case 'mooncake':
                instrumentationKey = ariaProjectIds.Mooncake;
                collectorUrl = 'https://collector.azure.cn/OneCollector/1.0/';
                break;
            case 'gccmoderate':
                instrumentationKey = ariaProjectIds.GccModerate;
                collectorUrl = 'https://tb.events.data.microsoft.com/OneCollector/1.0/';
                break;
            case 'gcchigh':
                instrumentationKey = ariaProjectIds.GccHigh;
                collectorUrl = 'https://tb.events.data.microsoft.com/OneCollector/1.0/';
                break;
            case 'dod':
                instrumentationKey = ariaProjectIds.DoD;
                collectorUrl = 'https://pf.events.data.microsoft.com/OneCollector/1.0/';
                break;
            case 'ex':
                instrumentationKey = ariaProjectIds.Production;
                collectorUrl = 'https://collector.azure.eaglex.ic.gov/OneCollector/1.0/';
                break;
            case 'rx':
                instrumentationKey = ariaProjectIds.Production;
                collectorUrl = 'https://collector.azure.microsoft.scloud/OneCollector/1.0/';
                break;
            default:
                instrumentationKey = ariaProjectIds.NonProduction;
                collectorUrl = this._getCollectorEndpoint(this._telemetryLocation);
                break;
        }
        var channelConfiguration = {
            // Limits: https://microsoft.github.io/ApplicationInsights-JS/webSdk/1ds-post-js/interfaces/IChannelConfiguration.html
            // Explicitly setting these for clarity and any future tuning
            maxEvtPerBatch: 500,
            maxEventRetryAttempts: 6,
            eventsLimitInMem: 10000,
            requestLimit: {
                requestLimit: [
                    3145728,
                    65000, // sync, default: 65000
                ],
                recordLimit: [
                    2000000,
                    65000, // sync, default: 65000
                ],
            },
            // Disable Mc1 / Ms0 cookie processing as we don't use them, and we don't want these for anonymous events
            ignoreMc1Ms0CookieProcessing: true,
            // Note: When beacon is enabled, 1DS will have no visibility into the browser dropping telemetry.
            // https://w3c.github.io/beacon/#return-value
            // "... since the actual data transfer happens asynchronously, this method does not provide any information whether
            // the data transfer has succeeded or not."
            //
            // Disable beacon to avoid gaps in telemetry, especially with visibilitychange "PageUnloadEvents"
            // where the user may switch away and back from the power app mid-session.
            useSendBeacon: false,
        };
        var config = {
            instrumentationKey: instrumentationKey,
            endpointUrl: collectorUrl,
            // Enable cookies so we can set Device_Id to the value of MicrosoftApplicationsTelemetryDeviceId
            disableCookiesUsage: true,
            propertyStorageOverride: new OneDSPropertyStorageOverride_1.OneDSPropertyStorageOverride(),
            // Disable Mc1 / Ms0 cookie processing as we don't use them, and we don't want these for anonymous events
            channelConfiguration: channelConfiguration,
            // Properties Plugin configuration
            propertyConfiguration: {
                serviceName: 'WebPlayer',
                env: region,
                populateBrowserInfo: true,
                populateOperatingSystemInfo: true,
                // Hashes the identifiable Part A properties - last octet of the client IP Address is hidden
                // https://1dsdocs.azurewebsites.net/api/webSDK/ext/properties/3.0/f/interfaces/ipropertyconfiguration.html#hashidentifiers
                hashIdentifiers: true,
                // Disabling the 1DS data sharing for all users by default
                // https://msasg.visualstudio.com/Shared%20Data/_git/1DS.JavaScript?path=%2Fextensions%2Fproperties%2FEUCC.md&_a=preview
                gpcDataSharingOptIn: false,
            },
        };
        return config;
    };
    OneDSTelemetryClient.prototype._getCollectorEndpoint = function (telemetryLocation) {
        if (telemetryLocation === 'eu') {
            // Taken from: https://www.aria.ms/developers/deep-dives/eudb-routing/
            return 'https://eu-mobile.events.data.microsoft.com/OneCollector/1.0/';
        }
        // Documentation on collector endpoints:
        // https://eng.ms/docs/products/geneva/collect/clientingestion/onboardingsteps/endpoints/configureuploaddestination
        //
        // Per this documentation, we should not use the direct EMEA, NOAM, or APAC urls
        //
        // We use the US endpoint for ROW so data lands in US kusto and MDS.
        // Geneva has a Geneva Distribution Service capability which could allow for more flexible
        // telemetry routing, as a future solution, but this needs to be adopted by PAClient telemetry
        return 'https://us-mobile.events.data.microsoft.com/OneCollector/1.0/';
    };
    return OneDSTelemetryClient;
}());
exports.OneDSTelemetryClient = OneDSTelemetryClient;
//# sourceMappingURL=OneDSTelemetryClient.js.map
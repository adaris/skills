"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.HelpStrings = void 0;
exports.HelpStrings = {
    Global: {
        ProgramDescription: 'Power Apps CLI for managing Power Apps code apps.',
        Region: 'Cloud instance region to use (e.g., prod, test, etc.).',
        EnvironmentId: 'Environment ID to connect to.',
    },
    Verbs: {
        'Add-data-source': {
            Description: 'Add a data source to the current Power Apps code app.',
            Options: {
                ApiId: 'API identifier.',
                ConnectionId: 'Connection identifier.',
                ConnectionRef: 'Connection reference name.',
                ResourceName: 'Table or resource name.',
                Dataset: 'Dataset identifier.',
                EnvUrl: 'Environment URL.',
                SqlStoredProcedure: 'SQL stored procedure name.',
                SolutionId: 'Solution identifier.',
            },
        },
        'Delete-data-source': {
            Description: 'Remove a data source from the Power Apps code app.',
            Options: {
                ApiId: 'API identifier associated with the data source.',
                DataSourceName: 'Data source or table name to remove.',
                SqlStoredProcedure: 'SQL stored procedure name to remove.',
            },
        },
        Init: {
            Description: 'Initialize a new Power Apps code app.',
            Options: {
                EnvironmentId: 'Environment ID to connect to.',
                Region: 'Cloud instance region (e.g., prod, preview).',
                DisplayName: 'Display name for the app.',
                Description: 'App description.',
                BuildPath: 'Build output path (default: ./dist).',
                FileEntryPoint: 'Entry point file for the app.',
                AppUrl: 'Local URL where the app is hosted.',
                LogoPath: 'Path to the app logo file.',
            },
        },
        'List-codeapps': {
            Description: 'List all code apps in the environment.',
        },
        'List-connection-references': {
            Description: 'List all connection references in the environment.',
            Options: {
                SolutionId: 'Solution identifier to filter by.',
                EnvUrl: 'Environment URL.',
            },
        },
        'List-datasets': {
            Description: 'List all datasets for a connection.',
            Options: {
                ApiId: 'API identifier.',
                ConnectionId: 'Connection identifier.',
            },
        },
        'List-environment-variables': {
            Description: 'List all environment variables in the environment.',
            Options: {
                EnvUrl: 'Environment URL.',
            },
        },
        'List-sqlStoredProcedures': {
            Description: 'List all SQL stored procedures for a dataset.',
            Options: {
                ConnectionId: 'Connection identifier.',
                Dataset: 'Dataset name.',
            },
        },
        'List-tables': {
            Description: 'List all tables for a dataset.',
            Options: {
                ApiId: 'API identifier.',
                ConnectionId: 'Connection identifier.',
                Dataset: 'Dataset name.',
            },
        },
        Logout: {
            Description: 'Log out the current user.',
        },
        Push: {
            Description: 'Push the code app to the Power Apps environment.',
            Options: {
                SolutionName: 'Solution name to add the app to.',
            },
        },
        Run: {
            Description: 'Run the code app locally.',
            Options: {
                Port: 'Port number for the local server.',
                LocalAppUrl: 'Local URL where the app is hosted.',
            },
        },
        Telemetry: {
            Description: 'Manage telemetry settings.',
            Options: {
                Enable: 'Enable telemetry.',
                Disable: 'Disable telemetry.',
                ShowSettings: 'Show current telemetry settings.',
                ConsoleOnly: 'Output telemetry to console only.',
                OutputToConsole: 'Output telemetry to console in addition to sending it.',
            },
        },
    },
};
//# sourceMappingURL=HelpStrings.js.map
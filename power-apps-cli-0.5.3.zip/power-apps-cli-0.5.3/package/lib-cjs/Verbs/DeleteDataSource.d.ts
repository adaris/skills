/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function deleteDataSourceAsync(argumentProvider: ArgumentProvider): Promise<boolean>;

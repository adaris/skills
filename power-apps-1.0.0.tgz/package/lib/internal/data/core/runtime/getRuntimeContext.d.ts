/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { DataSourcesInfo } from '../types';
import { PowerDataRuntime } from './powerDataRuntime';
/**
 * Builds (or retrieves) a singleton runtime context based on provided data sources.
 * Must be called after initializeRuntime() has injected the OperationExecutor.
 */
export declare function getPowerSdkInstance(dataSourcesInfo: DataSourcesInfo): PowerDataRuntime;
//# sourceMappingURL=getRuntimeContext.d.ts.map
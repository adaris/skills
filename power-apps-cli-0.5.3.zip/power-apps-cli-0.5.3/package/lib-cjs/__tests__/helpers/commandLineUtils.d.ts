/// <reference types="node" />
export declare const testDir: string;
interface CommandOptions {
    workingDirectory?: string;
    timeout?: number;
}
type CliCommandResult = {
    stdout: string;
    stderr: string;
    command: string;
};
type CliCommandResultWithExitCode = CliCommandResult & {
    exitCode: number | string;
};
type CliCommandOptions = {
    cliPath: string;
    verb: string;
    cwd: string;
    args?: string[];
    env?: NodeJS.ProcessEnv;
    timeoutMs?: number;
    maxBuffer?: number;
};
declare const DEFAULT_COMMAND_TIMEOUT_MS = 300000;
declare const DEFAULT_COMMAND_MAX_BUFFER: number;
/**
 * Runs an npm command in a specific directory
 * @param {string[]} args - The npm command to run (without 'npm' prefix)
 * @param {CommandOptions} [options={}] - Options for running the command
 * @returns {Promise<string>} - Promise resolving with command output
 */
declare function runNpmCommandInDirectory(args: string[], options?: CommandOptions): Promise<string>;
/**
 * Runs an npx command in a specific directory
 * @param {string[]} args - The npx command to run (without 'npx' prefix)
 * @param {CommandOptions} [options={}] - Options for running the command
 * @returns {Promise<string>} - Promise resolving with command output
 */
declare function runNpxCommandInDirectory(args: string[], options?: CommandOptions): Promise<string>;
declare function verifyCanRunNPM(): boolean;
declare function formatCliInvocation(cliPath: string, verb: string, args?: string[]): string;
/**
 * Executes a CLI command and returns the result along with the stdout and stderr.
 *
 * @param options - The CLI command options containing execution parameters
 * @param options.cliPath - The path to the CLI executable
 * @param options.verb - The CLI verb/command to execute
 * @param options.cwd - The current working directory for the command execution
 * @param options.args - Optional array of command-line arguments (defaults to empty array)
 * @param options.env - Optional environment variables to merge with process.env
 * @param options.timeoutMs - Optional timeout in milliseconds (defaults to DEFAULT_COMMAND_TIMEOUT_MS)
 * @param options.maxBuffer - Optional maximum buffer size (defaults to DEFAULT_COMMAND_MAX_BUFFER)
 * @returns A {@link CliCommandResult} object containing stdout, stderr, the formatted invocation command
 */
declare function runCliCommand(options: CliCommandOptions): CliCommandResult;
/**
 * Executes a CLI command and returns the result along with the exit code, allowing for command failures.
 *
 * @param options - The CLI command options containing execution parameters
 * @param options.cliPath - The path to the CLI executable
 * @param options.verb - The CLI verb/command to execute
 * @param options.cwd - The current working directory for the command execution
 * @param options.args - Optional array of command-line arguments (defaults to empty array)
 * @param options.env - Optional environment variables to merge with process.env
 * @param options.timeoutMs - Optional timeout in milliseconds (defaults to DEFAULT_COMMAND_TIMEOUT_MS)
 * @param options.maxBuffer - Optional maximum buffer size (defaults to DEFAULT_COMMAND_MAX_BUFFER)
 * @returns A {@link CliCommandResultWithExitCode} object containing stdout, stderr, the formatted invocation command, and the exit code
 */
declare function runCliCommandAllowFailure(options: CliCommandOptions): CliCommandResultWithExitCode;
export { DEFAULT_COMMAND_MAX_BUFFER, DEFAULT_COMMAND_TIMEOUT_MS, formatCliInvocation, runCliCommand, runCliCommandAllowFailure, runNpmCommandInDirectory, runNpxCommandInDirectory, verifyCanRunNPM, type CliCommandOptions, type CliCommandResult, type CliCommandResultWithExitCode, type CommandOptions, };

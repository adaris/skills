/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
/**
 * Argument definitions for CLI verbs.
 */
export declare const SharedArguments: {
    Help: {
        name: string;
        alias: string;
    };
    ApiId: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    SolutionId: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    EnvironmentUrl: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    ConnectionId: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    Dataset: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    SqlStoredProcedure: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    ResourceName: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
};
export declare const AddDataSourceArguments: {
    ConnectionRef: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
};
export declare const DeleteDataSourceArguments: {
    DataSourceName: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
};
export declare const InitArguments: {
    EnvironmentId: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    Region: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    DisplayName: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    Description: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
    };
    BuildPath: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
        initialValue: string;
    };
    FileEntryPoint: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
        initialValue: string;
    };
    AppUrl: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
        initialValue: string;
    };
    LogoPath: {
        name: string;
        alias: string;
        promptMessage: string;
        envVar: string;
        initialValue: string;
    };
};
//# sourceMappingURL=VerbConstants.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NodeMsalAuthenticationProvider = void 0;
var msal_node_1 = require("@azure/msal-node");
var msal_node_extensions_1 = require("@azure/msal-node-extensions");
var open_1 = __importDefault(require("open"));
var Constants_1 = require("../Constants");
var NodeMsalAuthenticationProvider = /** @class */ (function () {
    function NodeMsalAuthenticationProvider() {
    }
    NodeMsalAuthenticationProvider.prototype.initAsync = function () {
        return __awaiter(this, void 0, void 0, function () {
            var persistenceConfiguration, persistence, authConfig;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        persistenceConfiguration = {
                            cachePath: Constants_1.AUTH_CACHE_DIRECTORY + '/msal_cache.json',
                            dataProtectionScope: msal_node_extensions_1.DataProtectionScope.CurrentUser,
                            serviceName: 'power-apps',
                            accountName: 'power-apps',
                            usePlaintextFileOnLinux: false,
                        };
                        return [4 /*yield*/, msal_node_extensions_1.PersistenceCreator.createPersistence(persistenceConfiguration)];
                    case 1:
                        persistence = _a.sent();
                        authConfig = {
                            auth: {
                                clientId: '9cee029c-6210-4654-90bb-17e6e9d36617',
                            },
                            cache: {
                                cachePlugin: new msal_node_extensions_1.PersistenceCachePlugin(persistence),
                            },
                        };
                        this._msalClient = new msal_node_1.PublicClientApplication(authConfig);
                        return [2 /*return*/];
                }
            });
        });
    };
    NodeMsalAuthenticationProvider.prototype.getAccessTokenForResource = function (resource) {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this._acquireTokenInternal(resource + '/.default')];
                    case 1:
                        result = _a.sent();
                        this._tenantId = result.tenantId;
                        return [2 /*return*/, result.accessToken];
                }
            });
        });
    };
    NodeMsalAuthenticationProvider.prototype.getUserTenantId = function () {
        return this._tenantId;
    };
    NodeMsalAuthenticationProvider.prototype._acquireTokenInternal = function (resource) {
        return __awaiter(this, void 0, void 0, function () {
            var accounts, silentRequest, result, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this._msalClient) {
                            throw new Error('Authentication not initialized yet');
                        }
                        return [4 /*yield*/, this._msalClient.getTokenCache().getAllAccounts()];
                    case 1:
                        accounts = _a.sent();
                        if (!(accounts.length === 1)) return [3 /*break*/, 6];
                        silentRequest = {
                            account: accounts[0],
                            scopes: [resource],
                        };
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 4, , 5]);
                        return [4 /*yield*/, this._msalClient.acquireTokenSilent(silentRequest)];
                    case 3:
                        result = _a.sent();
                        return [2 /*return*/, result];
                    case 4:
                        error_1 = _a.sent();
                        if (error_1 instanceof msal_node_1.InteractionRequiredAuthError) {
                            return [2 /*return*/, this._msalClient.acquireTokenInteractive(this._getInteractiveLoginRequest(resource))];
                        }
                        throw error_1;
                    case 5: return [3 /*break*/, 7];
                    case 6:
                        if (accounts.length > 1) {
                            accounts.forEach(function (account) {
                                console.log(account.username);
                            });
                            return [2 /*return*/, Promise.reject('Multiple accounts found. Please use the logout command to remove existing accounts.')];
                        }
                        else {
                            return [2 /*return*/, this._msalClient.acquireTokenInteractive(this._getInteractiveLoginRequest(resource))];
                        }
                        _a.label = 7;
                    case 7: return [2 /*return*/];
                }
            });
        });
    };
    NodeMsalAuthenticationProvider.prototype._getInteractiveLoginRequest = function (resource) {
        var _this = this;
        var openBrowser = function (url) { return __awaiter(_this, void 0, void 0, function () {
            var error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, (0, open_1.default)(url, { wait: false })];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 3];
                    case 2:
                        error_2 = _a.sent();
                        console.error('Failed to open browser:', error_2);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        }); };
        return {
            scopes: [resource],
            openBrowser: openBrowser,
            successTemplate: 'You can close this window now.',
        };
    };
    return NodeMsalAuthenticationProvider;
}());
exports.NodeMsalAuthenticationProvider = NodeMsalAuthenticationProvider;
//# sourceMappingURL=NodeMsalAuthenticationProvider.js.map
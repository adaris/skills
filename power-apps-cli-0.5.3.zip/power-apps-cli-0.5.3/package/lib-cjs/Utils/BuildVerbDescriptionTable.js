"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildVerbDescriptionTable = void 0;
var VerbRegistry_1 = require("../Constants/VerbRegistry");
/**
 * Formats the verb registry into a table for help output.
 * Uses simple text-based table formatting suitable for terminal display.
 */
function buildVerbDescriptionTable() {
    var verbEntries = Object.entries(VerbRegistry_1.VERB_HELP_REGISTRY);
    if (verbEntries.length === 0) {
        return '';
    }
    // Calculate column width based on longest verb name
    var maxVerbLength = Math.max.apply(Math, __spreadArray([], __read(verbEntries.map(function (_a) {
        var _b = __read(_a, 1), verb = _b[0];
        return verb.length;
    })), false));
    var verbColumnWidth = Math.max(maxVerbLength + 2, 10);
    var lines = [];
    lines.push('Available Commands:');
    lines.push('');
    lines.push("  ".concat('Command'.padEnd(verbColumnWidth), "  Description"));
    lines.push("  ".concat('-'.repeat(verbColumnWidth), "  ").concat('-'.repeat(60)));
    // Format each verb as a table row
    verbEntries.forEach(function (_a) {
        var _b = __read(_a, 2), verb = _b[0], verbMetadata = _b[1];
        var verbColumn = verb.padEnd(verbColumnWidth);
        lines.push("  ".concat(verbColumn, "  ").concat(verbMetadata.description));
    });
    return lines.join('\n');
}
exports.buildVerbDescriptionTable = buildVerbDescriptionTable;
//# sourceMappingURL=BuildVerbDescriptionTable.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { PowerDataRuntime } from './powerDataRuntime';
import { IPowerDataSourcesInfoProvider, IXrmContext } from '../common/types';
import { IPowerOperationExecutor } from '../types';
/**
 * Gets or creates a singleton instance of PowerDataRuntime
 * @param powerDataSourcesInfoProvider - Data sources info provider to initialize the PowerDataRuntime
 * @param powerOperationExecutor - Optional power operation executor to initialize the PowerDataRuntime
 * @param xrm - Optional xrm object to initialize the PowerDataRuntime
 * @returns PowerDataRuntime instance
 */
export declare function getPowerDataRuntime(powerDataSourcesInfoProvider: IPowerDataSourcesInfoProvider, powerOperationExecutor: IPowerOperationExecutor, xrm?: IXrmContext): PowerDataRuntime;
/**
 * Resets the PowerDataRuntime singleton instance.
 * Useful for testing or reinitialization.
 */
export declare function resetPowerDataRuntimeInstance(): void;
//# sourceMappingURL=powerDataRuntimeInstance.d.ts.map
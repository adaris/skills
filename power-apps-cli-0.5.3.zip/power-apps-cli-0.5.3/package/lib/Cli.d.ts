export declare function boot(): Promise<void>;
//# sourceMappingURL=Cli.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveUserTelemetrySettings = void 0;
var fs = __importStar(require("fs"));
var path = __importStar(require("path"));
var Constants_1 = require("../Constants");
/**
 * Checks if a string represents a truthy value (1, true, yes, on).
 */
function isTruthy(value) {
    if (!value) {
        return false;
    }
    var normalized = value.trim().toLowerCase();
    return normalized === '1' || normalized === 'true' || normalized === 'yes' || normalized === 'on';
}
/**
 * Checks if a string represents a falsy value (0, false, no, off).
 */
function isFalsy(value) {
    if (!value) {
        return false;
    }
    var normalized = value.trim().toLowerCase();
    return normalized === '0' || normalized === 'false' || normalized === 'no' || normalized === 'off';
}
/**
 * Determines whether PAC CLI telemetry is enabled by checking environment variables and PAC CLI config.
 *
 * Checks in order:
 * 1. PAC_CLI_TELEMETRY_OPTOUT environment variable (if truthy, returns false)
 * 2. PAC CLI usersettings.json file in %LOCALAPPDATA%\Microsoft\PowerAppsCli
 *
 * @returns `false` if explicitly disabled, `true` if explicitly enabled, `undefined` if not configured
 */
function isPacCliTelemetryEnabled() {
    if (isTruthy(process.env.PAC_CLI_TELEMETRY_OPTOUT)) {
        return false;
    }
    var localAppData = process.env.LOCALAPPDATA;
    if (!localAppData) {
        return undefined;
    }
    var userSettingsPath = path.join(localAppData, 'Microsoft', 'PowerAppsCli', 'usersettings.json');
    if (!fs.existsSync(userSettingsPath)) {
        return undefined;
    }
    try {
        var raw = fs.readFileSync(userSettingsPath, 'utf-8');
        var parsed = JSON.parse(raw);
        return typeof parsed.telemetryEnabled === 'boolean' ? parsed.telemetryEnabled : undefined;
    }
    catch (error) {
        console.warn('Failed to read PAC CLI telemetry settings:', error.message);
        return undefined;
    }
}
/**
 * Resolves the effective user telemetry settings by merging defaults, user config file, and environment overrides.
 *
 * Resolution priority (highest to lowest):
 * 1. Environment variable overrides:
 *    - POWERAPPS_CLI_TELEMETRY=0/false/no/off forces `enabled: false`
 *    - PAC_CLI_TELEMETRY_OPTOUT or PAC CLI usersettings.json `telemetryEnabled: false` forces `enabled: false`
 * 2. PowerApps CLI user settings file (~/.powerapps-cli/settings.json)
 * 3. Default values: `{ enabled: true, consoleOnly: false, outputToConsole: false }`
 *
 * @returns Resolved telemetry configuration with enabled, consoleOnly, and outputToConsole flags
 */
function resolveUserTelemetrySettings() {
    var _a, _b, _c;
    var resolved = { enabled: true, consoleOnly: false, outputToConsole: false };
    var cliUserSettingsPath = path.join(Constants_1.CLI_CONFIG_DIRECTORY, Constants_1.USER_SETTINGS_FILE);
    if (fs.existsSync(cliUserSettingsPath)) {
        try {
            var fileContents = fs.readFileSync(cliUserSettingsPath, 'utf-8');
            var parsed = JSON.parse(fileContents);
            resolved.enabled = (_a = parsed.enabled) !== null && _a !== void 0 ? _a : resolved.enabled;
            resolved.consoleOnly = (_b = parsed.consoleOnly) !== null && _b !== void 0 ? _b : resolved.consoleOnly;
            resolved.outputToConsole = (_c = parsed.outputToConsole) !== null && _c !== void 0 ? _c : resolved.outputToConsole;
        }
        catch (error) {
            console.warn('Failed to read CLI telemetry settings:', error.message);
        }
    }
    if (process.env.POWERAPPS_CLI_TELEMETRY !== undefined && isFalsy(process.env.POWERAPPS_CLI_TELEMETRY)) {
        resolved.enabled = false;
    }
    var pacCliSetting = isPacCliTelemetryEnabled();
    if (typeof pacCliSetting === 'boolean' && pacCliSetting === false) {
        resolved.enabled = false;
    }
    return resolved;
}
exports.resolveUserTelemetrySettings = resolveUserTelemetrySettings;
//# sourceMappingURL=LoggerSettings.js.map
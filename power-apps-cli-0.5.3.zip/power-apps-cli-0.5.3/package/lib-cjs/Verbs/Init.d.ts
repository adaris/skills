/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function initAsync(argumentProvider: ArgumentProvider): Promise<void>;

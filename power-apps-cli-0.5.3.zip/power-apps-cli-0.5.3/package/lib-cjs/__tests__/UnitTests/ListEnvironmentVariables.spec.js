"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var globals_1 = require("@jest/globals");
var HttpClient_mocks_1 = require("@pa-client/powerapps-player-services/lib/__tests__/mocks/HttpClient.mocks");
var Logger_mocks_1 = require("@pa-client/powerapps-player-services/lib/__tests__/mocks/Logger.mocks");
var powerapps_player_services_1 = require("@pa-client/powerapps-player-services");
var ArgumentProvider_1 = require("../../ArgumentProvider");
var CliSettings_1 = require("../../CliSettings");
var ListEnvironmentVariables_1 = require("../../Verbs/ListEnvironmentVariables");
var silentConsole_1 = require("../mocks/silentConsole");
var AuthenticationProvider_mocks_1 = require("../mocks/AuthenticationProvider.mocks");
var _a = (0, silentConsole_1.silenceConsole)(), consoleMock = _a.mocks, restoreConsole = _a.restore;
var ORIGINAL_ARGV = process.argv.slice();
var config = {
    powerConfigPath: '',
    schemaPath: 'C:\\temp\\schema',
    codeGenPath: 'C:\\temp\\src',
};
var logger = (0, Logger_mocks_1.getMockLogger)();
var successfulDataverseResponse = {
    data: {
        '@odata.context': 'https://contosso.com/$metadata#environmentvariabledefinitions(type,schemaname,displayname,environmentvariabledefinition_environmentvariablevalue(value))',
        value: [
            {
                '@odata.etag': 'W/"13073711"',
                displayname: 'AppConnectivitySharepointSite',
                type: 100000004,
                schemaname: 'crd3f_AppConnectivitySharepointSite',
                environmentvariabledefinitionid: '519f5ab0-4f79-f011-b4cc-002248040a29',
                environmentvariabledefinition_environmentvariablevalue: [
                    {
                        '@odata.etag': 'W/"13073726"',
                        _environmentvariabledefinitionid_value: '519f5ab0-4f79-f011-b4cc-002248040a29',
                        environmentvariablevalueid: '559f5ab0-4f79-f011-b4cc-002248040a29',
                        value: 'https://contosso.com/sites/AppConnectivity',
                    },
                ],
                'environmentvariabledefinition_environmentvariablevalue@odata.nextLink': 'https://contosso.com/api/data/v9.0/environmentvariabledefinitions(519f5ab0-4f79-f011-b4cc-002248040a29)/environmentvariabledefinition_environmentvariablevalue?$select=value',
            },
            {
                '@odata.etag': 'W/"13073787"',
                displayname: 'AllSharepointDataTypes',
                type: 100000004,
                schemaname: 'new_shared_sharepointonline_854d50d6fcc74a5fa9e5bf8d7dbba9a5',
                environmentvariabledefinitionid: 'de7d3b11-5d79-f011-b4cc-002248044001',
                environmentvariabledefinition_environmentvariablevalue: [
                    {
                        '@odata.etag': 'W/"13073780"',
                        _environmentvariabledefinitionid_value: 'de7d3b11-5d79-f011-b4cc-002248044001',
                        environmentvariablevalueid: 'e17d3b11-5d79-f011-b4cc-002248044001',
                        value: 'cfaa22f1-81e0-4346-9033-340e3f4c2685',
                    },
                ],
                'environmentvariabledefinition_environmentvariablevalue@odata.nextLink': 'https://contosso.com/api/data/v9.0/environmentvariabledefinitions(de7d3b11-5d79-f011-b4cc-002248044001)/environmentvariabledefinition_environmentvariablevalue?$select=value',
            },
        ],
    },
    status: 200,
    headers: {},
};
(0, globals_1.describe)('list environment variables verb tests', function () {
    (0, globals_1.afterAll)(function () {
        restoreConsole();
    });
    (0, globals_1.beforeEach)(function () { return __awaiter(void 0, void 0, void 0, function () {
        var _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    delete process.env.API_ID;
                    delete process.env.CONNECTION_ID;
                    delete process.env.TABLE;
                    delete process.env.DATASET;
                    delete process.env.ENV_URL;
                    delete process.env.SQL_STORED_PROCEDURE;
                    (0, powerapps_player_services_1.initializePlayerServices)({
                        httpClient: (0, HttpClient_mocks_1.getMockHttpClient)(successfulDataverseResponse),
                        logger: (0, Logger_mocks_1.getMockLogger)(),
                        region: 'local',
                        environmentName: '',
                    });
                    return [4 /*yield*/, (0, CliSettings_1.initializeCliSettings)(true, config)];
                case 1:
                    _c.sent();
                    (0, CliSettings_1.setCliLogger)(logger);
                    // Ensure Commander parsing tests do not see Jest flags
                    process.argv = [
                        (_a = ORIGINAL_ARGV[0]) !== null && _a !== void 0 ? _a : 'node',
                        (_b = ORIGINAL_ARGV[1]) !== null && _b !== void 0 ? _b : 'power-apps',
                        'list-environment-variables',
                    ];
                    return [2 /*return*/];
            }
        });
    }); });
    (0, globals_1.afterEach)(function () {
        process.argv = ORIGINAL_ARGV.slice();
    });
    (0, globals_1.it)('should retrieve environment variables', function () { return __awaiter(void 0, void 0, void 0, function () {
        var mockArgumentProvider;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    // Arrange
                    process.env.ENV_URL = 'https://test.crm.dynamics.com';
                    mockArgumentProvider = new ArgumentProvider_1.ArgumentProvider((0, HttpClient_mocks_1.getMockHttpClient)(successfulDataverseResponse), (0, Logger_mocks_1.getMockLogger)(), (0, AuthenticationProvider_mocks_1.getMockAuthenticationProvider)());
                    // Act
                    return [4 /*yield*/, (0, ListEnvironmentVariables_1.listAllEnvironmentVariablesAsync)(mockArgumentProvider)];
                case 1:
                    // Act
                    _a.sent();
                    // Assert
                    (0, silentConsole_1.expectConsoleSequence)(consoleMock.log, [
                        '\nEnvironment Variables:',
                        '────────────────────────────────────────────────────────────────────────────────────────────────────',
                        'Schema Name: crd3f_AppConnectivitySharepointSite',
                        'Display Name: AppConnectivitySharepointSite',
                        'Type: 100000004',
                        'Value: https://contosso.com/sites/AppConnectivity',
                        '────────────────────────────────────────────────────────────────────────────────────────────────────',
                        'Schema Name: new_shared_sharepointonline_854d50d6fcc74a5fa9e5bf8d7dbba9a5',
                        'Display Name: AllSharepointDataTypes',
                        'Type: 100000004',
                        'Value: cfaa22f1-81e0-4346-9033-340e3f4c2685',
                        '────────────────────────────────────────────────────────────────────────────────────────────────────',
                    ]);
                    return [2 /*return*/];
            }
        });
    }); });
});
//# sourceMappingURL=ListEnvironmentVariables.spec.js.map
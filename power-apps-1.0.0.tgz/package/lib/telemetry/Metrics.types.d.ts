/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export type AppLoadClientState = 'healthy' | 'unhealthy' | 'throttled' | 'unknown';
export type AppLoadResult = 'optimal' | 'other';
export type AppLoadNonOptimalReason = 'interactionRequired' | 'throttled' | 'screenNavigatedAway' | 'other';
export type AppLoadUnsuccessfulReason = 'AppConnectionsFailed' | 'AppForbidden' | 'AppForbiddenAppIsInQuarantine' | 'AppForbiddenPlansIssue' | 'AppIsPackaging' | 'AppLoadFailed' | 'AppNotFound' | 'CookiesBlocked' | 'InvokeScriptBlocked' | 'NetworkError' | 'PlatformError' | 'PopupError' | 'ProxyError' | 'StorageBlocked' | 'Unknown' | 'UserCancelAppConnections' | 'UserCancelled' | 'UserNotLoggedIn' | 'UserUnauthorized' | 'UserUnsupportedAppVersion' | 'UserUnsupportedBrowser';
export type SessionLoadSummaryMetricData = {
    /** Whether this app launch was successful */
    successfulAppLaunch: boolean;
    /** The reason the app launch was not successful */
    unsuccessfulReason?: AppLoadUnsuccessfulReason;
    /** The type of state the client loaded in. */
    appLoadClientState: AppLoadClientState;
    /** The type of app load */
    appLoadResult: AppLoadResult;
    /** The reason the app load was not considered optimal */
    appLoadNonOptimalReason?: AppLoadNonOptimalReason;
    /** The type of app */
    appType?: string;
    /** Time in milliseconds for the app to become interactive */
    timeToAppInteractive?: number;
    /** Time in milliseconds for the app to be fully loaded (including data) */
    timeToAppFullLoad?: number;
    /** Date this app was last published */
    lastPublishedDate?: string;
    /** Number of data calls made prior to full load */
    numDataCallsBeforeFullLoad?: number;
    /** [Canvas only] Time in milliseconds for the OnStart property rule to complete */
    onStartRuleDuration?: number;
};
export type SessionLoadSummaryMetric = {
    data: SessionLoadSummaryMetricData;
    type: 'sessionLoadSummary';
};
export type NetworkRequestMetricData = {
    /** The URL of the network request */
    url: string;
    /** The HTTP method of the request */
    method: string;
    /** The status code of the response */
    statusCode: number;
    /** The time taken for the request in milliseconds */
    duration: number;
    /** The size of the response in bytes */
    responseSize?: number;
};
export type NetworkRequestMetric = {
    data: NetworkRequestMetricData;
    type: 'networkRequest';
};
export type Metric = SessionLoadSummaryMetric | NetworkRequestMetric;
//# sourceMappingURL=Metrics.types.d.ts.map
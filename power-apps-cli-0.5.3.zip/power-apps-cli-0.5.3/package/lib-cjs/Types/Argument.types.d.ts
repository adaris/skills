/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export type DefaultStringOption = CliOption & {
    message: string;
    initialValue?: string;
};
export type Flags = {
    key: string;
    alias: string;
};
export interface CliOption<T = unknown> {
    flags: Flags;
    env: string;
    description?: string;
    default?: T;
    customPrompt?: () => Promise<T>;
}

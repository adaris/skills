/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export {};
//# sourceMappingURL=powerDataRuntimeInstance.test.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { Region } from '@pa-client/powerapps-player-services';
import { ITelemetryWriter } from '../Types/LoggerTypes.types';
import { TelemetryLocation } from './Constants';
export declare class OneDSWriter implements ITelemetryWriter {
    private _telemetryClient;
    constructor(sessionId: string, region: Region, telemetryLocation: TelemetryLocation, environmentId: string, appId: string, geoLocation: string | undefined);
    trackActivityEvent(operationName: string, eventData?: object): void;
    trackErrorEvent(operationName: string, eventData?: object): void;
    startScenario(scenarioName: string, startData?: object): void;
    completeScenario(scenarioName: string, completeData?: object): void;
    scenarioFailed(scenarioName: string, failureData?: object): void;
    scenarioCompletedWithError(scenarioName: string, completeWithErrorData?: object): void;
    flush(): void;
    setCustomDimension(_key: string, _value: string): void;
}
//# sourceMappingURL=OneDSWriter.d.ts.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function runAsync(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=Run.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getScrubbedCustomDimensions = void 0;
var ScrubCustomDimensionsConfig_1 = require("./ScrubCustomDimensionsConfig");
// note: This code is copied from powerapps-telemetry-utils package
// to avoid adding that package as a dependency to powerapps-player-cli package
// powerapps-player-cli is a published package, and powerapps-telemetry-utils is not => pa-client-build does not support this scenario yet
function getScrubbedCustomDimensions(eventName, operationName, customDimensions) {
    var e_1, _a;
    var _b, _c;
    // To avoid the performance impact of scrubbing all events, we want to target specific events to scrub
    var eventConfig = ScrubCustomDimensionsConfig_1.EventsToScrubConfig[eventName];
    if (eventConfig) {
        var scenarioName = customDimensions.scenarioName || '';
        var scrubConfigList = eventConfig['*'] || ((_b = eventConfig.operations) === null || _b === void 0 ? void 0 : _b[operationName]) || ((_c = eventConfig.scenarios) === null || _c === void 0 ? void 0 : _c[scenarioName]);
        if (scrubConfigList) {
            var currentScrubberName = void 0;
            try {
                var value = JSON.stringify(customDimensions);
                try {
                    for (var scrubConfigList_1 = __values(scrubConfigList), scrubConfigList_1_1 = scrubConfigList_1.next(); !scrubConfigList_1_1.done; scrubConfigList_1_1 = scrubConfigList_1.next()) {
                        var _d = scrubConfigList_1_1.value, scrubberName = _d.scrubberName, shouldScrubValue = _d.shouldScrubValue;
                        currentScrubberName = scrubberName;
                        if (shouldScrubValue(value)) {
                            return {
                                eventName: eventName,
                                operationName: operationName,
                                scenarioName: scenarioName,
                                scrubber: currentScrubberName,
                                message: '_scrubbedByPowerAppsTelemetryUtils_: Custom dimensions were scrubbed by host',
                            };
                        }
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (scrubConfigList_1_1 && !scrubConfigList_1_1.done && (_a = scrubConfigList_1.return)) _a.call(scrubConfigList_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
            }
            catch (error) {
                return {
                    eventName: eventName,
                    operationName: operationName,
                    scenarioName: scenarioName,
                    scrubber: currentScrubberName,
                    message: '_scrubbedByPowerAppsTelemetryUtils_: Failed to parse custom dimensions while scrubbing',
                };
            }
        }
    }
    return customDimensions;
}
exports.getScrubbedCustomDimensions = getScrubbedCustomDimensions;
//# sourceMappingURL=ScrubCustomDimensions.js.map
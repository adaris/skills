/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { ArgumentProvider } from '../../ArgumentProvider';
type OptionsMap = Record<string, unknown>;
export declare class MockArgumentProvider implements Pick<ArgumentProvider, 'addSwitches' | 'addOptions' | 'runVerb' | 'getOption' | 'setDescription'> {
    private _options;
    constructor(initialOptions?: OptionsMap);
    addSwitches: ArgumentProvider['addSwitches'];
    addOptions: ArgumentProvider['addOptions'];
    runVerb: ArgumentProvider['runVerb'];
    getOption: ArgumentProvider['getOption'];
    setOption(key: string, value: unknown): void;
    setDescription(description: string): void;
}
export {};
//# sourceMappingURL=MockArgumentProvider.d.ts.map
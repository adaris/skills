/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
interface DataverseDataSource {
    entitySetName: string;
    logicalName: string;
    isHidden: boolean;
}
interface DataSet {
    dataSources: Record<string, {
        tableName?: string;
    }>;
    datasetOverride?: {
        environmentVariableName: string;
    };
}
interface ConnectionReference {
    id: string;
    displayName: string;
    dataSources: string[];
    authenticationType?: string;
    sharedConnectionId?: string;
    dataSets?: Record<string, DataSet>;
    xrmConnectionReferenceLogicalName?: string | undefined;
}
interface TabularMetadata {
    dataset: string;
    resourceName: string;
    isProcedure: boolean;
    friendlyName?: string;
    datasetOverride?: string;
    resourceNameOverride?: string;
}
interface DatabaseReference {
    state: string;
    instanceUrl: string;
    webApiVersion: string;
    dataSources: Record<string, DataverseDataSource>;
    version: string;
    environmentVariableName: string;
}
export type { ConnectionReference, DatabaseReference, DataSet, DataverseDataSource, TabularMetadata };
//# sourceMappingURL=Datasource.types.d.ts.map
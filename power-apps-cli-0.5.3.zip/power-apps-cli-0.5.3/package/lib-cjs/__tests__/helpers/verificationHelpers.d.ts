/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
/**
 * Helper functions for verifying CLI command results and file system state
 */
/**
 * Check if a power.config.json has generated connection or database references
 */
export declare function hasGeneratedReference(config: Record<string, unknown>): boolean;
/**
 * Count the number of connection reference entries in a config
 */
export declare function countConnectionEntries(config: Record<string, unknown>): number;

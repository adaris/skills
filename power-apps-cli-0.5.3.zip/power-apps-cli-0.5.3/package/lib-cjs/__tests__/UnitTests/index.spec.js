"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
var globals_1 = require("@jest/globals");
(0, globals_1.describe)('index', function () {
    (0, globals_1.it)('works as expected', function () {
        (0, globals_1.expect)(2).toBe(2);
    });
});
//# sourceMappingURL=index.spec.js.map
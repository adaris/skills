/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function listDatasetsAsync(argumentProvider: ArgumentProvider): Promise<void>;

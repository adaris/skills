/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { DataSourcesInfo, IOperationOptions, IOperationResult } from '../types';
/**
 * Retrieves multiple records from the specified table.
 * @param dataSourcesInfo - The data sources information.
 * @param tableName - The name of the table to create the record in.
 * @param options - Optional operation options.
 * @returns - A promise that resolves to the created record.
 */
export declare function retrieveMultipleRecordsAsync<TResult>(dataSourcesInfo: DataSourcesInfo, tableName: string, options?: IOperationOptions): Promise<IOperationResult<TResult[]>>;
//# sourceMappingURL=retrieveMultipleRecords.d.ts.map
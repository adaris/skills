/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { Logger } from '../telemetry/Logger.types';
export declare function initialize(options?: {
    logger?: Logger;
}): Promise<void>;
export declare function getAppLoadedPerformanceData(): string;
//# sourceMappingURL=Lifecycle.d.ts.map
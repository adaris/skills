/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
/**
 * Type-safe argument objects for CLI verbs based on VerbConstants
 * Each interface is derived from the VerbConstants to ensure consistency
 *
 * Note: Argument names are taken directly from VerbConstants (e.g., InitArguments.EnvironmentId.name = 'environmentId')
 * These types mirror what each verb's createOptionSchema expects
 */
export type InitArgs = {
    environmentId?: string;
    region?: string;
    displayName?: string;
    description?: string;
    buildPath?: string;
    fileEntryPoint?: string;
    appUrl?: string;
    logoPath?: string;
};
export type AddDataSourceArgs = {
    apiId?: string;
    connectionId?: string;
    connectionRef?: string;
    resourceName?: string;
    dataset?: string;
    envUrl?: string;
};
export type DeleteDataSourceArgs = {
    dataSourceName?: string;
    apiId?: string;
    sqlStoredProcedure?: string;
};
export type ListDatasetsArgs = {
    apiId?: string;
    connectionId?: string;
};
export type ListTablesArgs = {
    apiId?: string;
    connectionId?: string;
    dataset?: string;
};
export type ListSqlStoredProceduresArgs = {
    connectionId?: string;
    dataset?: string;
};
export type ListConnectionReferencesArgs = {
    solutionId?: string;
    envUrl?: string;
};
export type ListEnvironmentVariablesArgs = {
    envUrl?: string;
};
export type ListCodeAppsArgs = Record<string, never>;
export type LogoutArgs = Record<string, never>;
/**
 * Build CLI arguments for init verb
 */
export declare function buildInitArgs(args: InitArgs): string[];
/**
 * Build CLI arguments for add-data-source verb
 */
export declare function buildAddDataSourceArgs(args: AddDataSourceArgs): string[];
/**
 * Build CLI arguments for delete-data-source verb
 */
export declare function buildDeleteDataSourceArgs(args: DeleteDataSourceArgs): string[];
/**
 * Build CLI arguments for list-datasets verb
 */
export declare function buildListDatasetsArgs(args: ListDatasetsArgs): string[];
/**
 * Build CLI arguments for list-tables verb
 */
export declare function buildListTablesArgs(args: ListTablesArgs): string[];
/**
 * Build CLI arguments for list-sql-stored-procedures verb
 */
export declare function buildListSqlStoredProceduresArgs(args: ListSqlStoredProceduresArgs): string[];
/**
 * Build CLI arguments for list-connection-references verb
 */
export declare function buildListConnectionReferencesArgs(args: ListConnectionReferencesArgs): string[];
/**
 * Build CLI arguments for list-environment-variables verb
 */
export declare function buildListEnvironmentVariablesArgs(args?: ListEnvironmentVariablesArgs): string[];
/**
 * Build CLI arguments for list-code-apps verb
 */
export declare function buildListCodeAppsArgs(args?: ListCodeAppsArgs): string[];
/**
 * Build CLI arguments for logout verb
 */
export declare function buildLogoutArgs(args?: LogoutArgs): string[];
//# sourceMappingURL=argumentBuilder.d.ts.map
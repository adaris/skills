"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initAsync = void 0;
var CliSettings_1 = require("../CliSettings");
var CliUtils_1 = require("../CliUtils");
var HelpStrings_1 = require("../Constants/HelpStrings");
var VerbConstants_1 = require("./VerbConstants");
var ConfigManager_1 = require("@microsoft/powerapps-player-actions/lib/Config/ConfigManager");
var Schema_1 = require("@microsoft/powerapps-player-actions/lib/Config/V1/Schema");
function initAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var settings, environmentId, _a, region, displayName, description, buildPath, fileEntryPoint, appUrl, logoPath, appConfig;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    settings = (0, CliSettings_1.getSettings)();
                    if (settings.appConfig) {
                        throw new Error('App configuration already exists.');
                    }
                    createOptionSchema(argumentProvider);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _b.sent();
                    _a = argumentProvider.getEnvironmentId();
                    if (_a) return [3 /*break*/, 3];
                    return [4 /*yield*/, argumentProvider.getOption('environmentId')];
                case 2:
                    _a = (_b.sent());
                    _b.label = 3;
                case 3:
                    environmentId = _a;
                    return [4 /*yield*/, argumentProvider.getOption('region')];
                case 4:
                    region = _b.sent();
                    return [4 /*yield*/, argumentProvider.getOption('displayName')];
                case 5:
                    displayName = _b.sent();
                    return [4 /*yield*/, argumentProvider.getOption('description')];
                case 6:
                    description = _b.sent();
                    return [4 /*yield*/, argumentProvider.getOption('buildPath')];
                case 7:
                    buildPath = _b.sent();
                    return [4 /*yield*/, argumentProvider.getOption('fileEntryPoint')];
                case 8:
                    fileEntryPoint = _b.sent();
                    return [4 /*yield*/, argumentProvider.getOption('appUrl')];
                case 9:
                    appUrl = _b.sent();
                    return [4 /*yield*/, argumentProvider.getOption('logoPath')];
                case 10:
                    logoPath = _b.sent();
                    appConfig = {
                        version: Schema_1.VERSION,
                        appId: null,
                        appDisplayName: displayName,
                        region: region,
                        environmentId: environmentId,
                        description: description,
                        buildPath: buildPath,
                        buildEntryPoint: fileEntryPoint,
                        localAppUrl: appUrl,
                        logoPath: logoPath,
                        connectionReferences: {},
                        databaseReferences: {},
                    };
                    return [4 /*yield*/, (0, ConfigManager_1.writeRepoConfig)(settings.fileConfig.powerConfigPath, appConfig)];
                case 11:
                    _b.sent();
                    console.log("Created power.config.json for ".concat(displayName, "."));
                    return [2 /*return*/];
            }
        });
    });
}
exports.initAsync = initAsync;
function createOptionSchema(argumentProvider) {
    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs.Init.Description);
    argumentProvider.addOptions([
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.InitArguments.DisplayName.name,
                alias: VerbConstants_1.InitArguments.DisplayName.alias,
            },
            env: VerbConstants_1.InitArguments.DisplayName.envVar,
            message: VerbConstants_1.InitArguments.DisplayName.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs.Init.Options.DisplayName,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.InitArguments.Description.name,
                alias: VerbConstants_1.InitArguments.Description.alias,
            },
            env: VerbConstants_1.InitArguments.Description.envVar,
            default: ' ',
            message: VerbConstants_1.InitArguments.Description.promptMessage,
            description: HelpStrings_1.HelpStrings.Verbs.Init.Options.Description,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.InitArguments.BuildPath.name,
                alias: VerbConstants_1.InitArguments.BuildPath.alias,
            },
            env: VerbConstants_1.InitArguments.BuildPath.envVar,
            message: VerbConstants_1.InitArguments.BuildPath.promptMessage,
            initialValue: VerbConstants_1.InitArguments.BuildPath.initialValue,
            default: './dist',
            description: HelpStrings_1.HelpStrings.Verbs.Init.Options.BuildPath,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.InitArguments.FileEntryPoint.name,
                alias: VerbConstants_1.InitArguments.FileEntryPoint.alias,
            },
            env: VerbConstants_1.InitArguments.FileEntryPoint.envVar,
            message: VerbConstants_1.InitArguments.FileEntryPoint.promptMessage,
            initialValue: VerbConstants_1.InitArguments.FileEntryPoint.initialValue,
            default: 'index.html',
            description: HelpStrings_1.HelpStrings.Verbs.Init.Options.FileEntryPoint,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.InitArguments.AppUrl.name,
                alias: VerbConstants_1.InitArguments.AppUrl.alias,
            },
            env: VerbConstants_1.InitArguments.AppUrl.envVar,
            message: VerbConstants_1.InitArguments.AppUrl.promptMessage,
            initialValue: VerbConstants_1.InitArguments.AppUrl.initialValue,
            default: 'http://localhost:3000',
            description: HelpStrings_1.HelpStrings.Verbs.Init.Options.AppUrl,
        }),
        (0, CliUtils_1.createDefaultStringOption)({
            flags: {
                key: VerbConstants_1.InitArguments.LogoPath.name,
                alias: VerbConstants_1.InitArguments.LogoPath.alias,
            },
            env: VerbConstants_1.InitArguments.LogoPath.envVar,
            message: VerbConstants_1.InitArguments.LogoPath.promptMessage,
            initialValue: VerbConstants_1.InitArguments.LogoPath.initialValue,
            default: 'Default',
            description: HelpStrings_1.HelpStrings.Verbs.Init.Options.LogoPath,
        }),
    ]);
}
//# sourceMappingURL=Init.js.map
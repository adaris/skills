/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
/**
 * Adds a data source based on the provided environment variables.
 * It supports both Dataverse and connector data sources.
 * Expects the following environment variables:
 * - API_ID: The ID of the API (e.g., 'dataverse' or a connector ID)
 * - CONNECTION_ID?: The ID of the connection (for connector data sources)
 * - TABLE?: The table name for Dataverse or tabular connector data sources
 * - ENV_URL?: The environment URL for Dataverse data sources
 * - DATASET?: The dataset name for tabular/stored proc connector data sources
 * - SQL_STORED_PROCEDURE?: The name of the SQL stored procedure for connector data sources
 * @param config - Local file paths configuration
 * @returns Promise<void>
 */
export declare function addDataSourceAsync(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=AddDataSource.d.ts.map
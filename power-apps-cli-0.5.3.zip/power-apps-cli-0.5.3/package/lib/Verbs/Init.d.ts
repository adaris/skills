/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ArgumentProvider } from '../ArgumentProvider';
export declare function initAsync(argumentProvider: ArgumentProvider): Promise<void>;
//# sourceMappingURL=Init.d.ts.map
"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.VERB_HELP_REGISTRY = void 0;
var HelpStrings_1 = require("./HelpStrings");
/**
 * Central registry of all CLI verbs with their descriptions.
 * This array is used to generate the verb table in --help output.
 *
 * IMPORTANT: When adding a new verb, you must:
 * 1. Add to Verb type in Cli.types.ts
 * 2. Add case to executeVerb() switch in Cli.ts
 * 3. Add entry to this VERB_REGISTRY array
 * 4. Add entry to HelpStrings.Verbs in HelpStrings.ts
 */
exports.VERB_HELP_REGISTRY = {
    init: { description: HelpStrings_1.HelpStrings.Verbs.Init.Description },
    push: { description: HelpStrings_1.HelpStrings.Verbs.Push.Description },
    run: { description: HelpStrings_1.HelpStrings.Verbs.Run.Description },
    'add-data-source': { description: HelpStrings_1.HelpStrings.Verbs['Add-data-source'].Description },
    'list-codeapps': { description: HelpStrings_1.HelpStrings.Verbs['List-codeapps'].Description },
    'list-datasets': { description: HelpStrings_1.HelpStrings.Verbs['List-datasets'].Description },
    'list-tables': { description: HelpStrings_1.HelpStrings.Verbs['List-tables'].Description },
    'list-sqlStoredProcedures': { description: HelpStrings_1.HelpStrings.Verbs['List-sqlStoredProcedures'].Description },
    'delete-data-source': { description: HelpStrings_1.HelpStrings.Verbs['Delete-data-source'].Description },
    'list-environment-variables': { description: HelpStrings_1.HelpStrings.Verbs['List-environment-variables'].Description },
    'list-connection-references': { description: HelpStrings_1.HelpStrings.Verbs['List-connection-references'].Description },
    logout: { description: HelpStrings_1.HelpStrings.Verbs.Logout.Description },
    telemetry: { description: HelpStrings_1.HelpStrings.Verbs.Telemetry.Description },
};
//# sourceMappingURL=VerbRegistry.js.map
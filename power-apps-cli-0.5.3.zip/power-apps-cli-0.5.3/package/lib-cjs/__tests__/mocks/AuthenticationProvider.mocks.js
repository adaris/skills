"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMockAuthenticationProvider = void 0;
var globals_1 = require("@jest/globals");
function getMockAuthenticationProvider() {
    return {
        initAsync: function () {
            return Promise.resolve();
        },
        getAccessTokenForResource: globals_1.jest
            .fn()
            .mockResolvedValue('mock-access-token'),
        getUserTenantId: globals_1.jest.fn().mockReturnValue('mock-tenant-id'),
    };
}
exports.getMockAuthenticationProvider = getMockAuthenticationProvider;
//# sourceMappingURL=AuthenticationProvider.mocks.js.map
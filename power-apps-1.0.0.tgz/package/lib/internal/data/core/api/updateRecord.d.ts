/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { DataSourcesInfo, IOperationResult } from '../types';
/**
 * Updates an existing record in the specified table.
 * @param dataSourcesInfo - The data sources information.
 * @param tableName - The name of the table to create the record in.
 * @param recordId - The ID of the record to update.
 * @param changes - The changes to apply to the record.
 * @returns - A promise that resolves to the created record.
 */
export declare function updateRecordAsync<TInput, TResult>(dataSourcesInfo: DataSourcesInfo, tableName: string, recordId: string, changes: TInput): Promise<IOperationResult<TResult>>;
//# sourceMappingURL=updateRecord.d.ts.map
"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OneDSWriter = void 0;
var Constants_1 = require("./Constants");
var OneDSTelemetryClient_1 = require("./OneDSTelemetryClient");
var OneDSWriter = /** @class */ (function () {
    function OneDSWriter(sessionId, region, telemetryLocation, environmentId, appId, geoLocation) {
        var _this = this;
        this._telemetryClient = new OneDSTelemetryClient_1.OneDSTelemetryClient(region, telemetryLocation, undefined, Constants_1.AriaProjectIds);
        var defaultCustomDimensions = {
            environmentId: environmentId,
            isOnePlayer: 'false',
            webPlayerScenario: 'CodeApp_CLI_Authoring',
            cloud: region === 'preview' ? 'prod' : region,
            sessionStartTime: new Date().toISOString(),
            station: 'Unknown',
            telemetryLocation: telemetryLocation,
        };
        if (appId) {
            defaultCustomDimensions.playerAppId = "/providers/Microsoft.PowerApps/apps/".concat(appId);
        }
        if (geoLocation) {
            defaultCustomDimensions.geoLocation = geoLocation;
        }
        Object.entries(defaultCustomDimensions).forEach(function (_a) {
            var _b;
            var _c = __read(_a, 2), key = _c[0], value = _c[1];
            _this._telemetryClient.setDefaultProperty(key, (_b = value === null || value === void 0 ? void 0 : value.toString()) !== null && _b !== void 0 ? _b : '', true);
        });
        this._telemetryClient.sessionId = sessionId;
    }
    OneDSWriter.prototype.trackActivityEvent = function (operationName, eventData) {
        this._telemetryClient.trackEvent(Constants_1.OneDSEventNames.ActivityEvent, __assign(__assign({}, eventData), { operationName: operationName }));
    };
    OneDSWriter.prototype.trackErrorEvent = function (operationName, eventData) {
        this._telemetryClient.trackEvent(Constants_1.OneDSEventNames.ErrorEvent, __assign(__assign({}, eventData), { operationName: operationName }));
    };
    OneDSWriter.prototype.startScenario = function (scenarioName, startData) {
        this._telemetryClient.trackEvent(Constants_1.OneDSEventNames.StartScenario, __assign(__assign({ operationName: scenarioName }, startData), { scenarioName: scenarioName }));
    };
    OneDSWriter.prototype.completeScenario = function (scenarioName, completeData) {
        this._telemetryClient.trackEvent(Constants_1.OneDSEventNames.EndScenario, __assign(__assign({ operationName: scenarioName }, completeData), { scenarioName: scenarioName, scenarioResult: Constants_1.ScenarioResults.Success }));
    };
    OneDSWriter.prototype.scenarioFailed = function (scenarioName, failureData) {
        this._telemetryClient.trackEvent(Constants_1.OneDSEventNames.EndScenario, __assign(__assign({ operationName: scenarioName }, failureData), { scenarioName: scenarioName, scenarioResult: Constants_1.ScenarioResults.Failed }));
    };
    OneDSWriter.prototype.scenarioCompletedWithError = function (scenarioName, completeWithErrorData) {
        this._telemetryClient.trackEvent(Constants_1.OneDSEventNames.EndScenario, __assign(__assign({ operationName: scenarioName }, completeWithErrorData), { scenarioName: scenarioName, scenarioResult: Constants_1.ScenarioResults.SuccessWithErrors }));
    };
    OneDSWriter.prototype.flush = function () {
        return this._telemetryClient.flush();
    };
    OneDSWriter.prototype.setCustomDimension = function (_key, _value) {
        this._telemetryClient.setDefaultProperty(_key, _value, true);
    };
    return OneDSWriter;
}());
exports.OneDSWriter = OneDSWriter;
//# sourceMappingURL=OneDSWriter.js.map
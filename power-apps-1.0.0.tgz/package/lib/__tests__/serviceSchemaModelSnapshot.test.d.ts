export {};
//# sourceMappingURL=serviceSchemaModelSnapshot.test.d.ts.map
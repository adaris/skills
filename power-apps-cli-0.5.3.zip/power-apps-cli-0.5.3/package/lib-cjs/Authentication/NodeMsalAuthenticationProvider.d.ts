/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IAuthenticationProvider } from '../Types/Cli.types';
export declare class NodeMsalAuthenticationProvider implements IAuthenticationProvider {
    private _msalClient;
    private _tenantId;
    initAsync(): Promise<void>;
    getAccessTokenForResource(resource: string): Promise<string>;
    getUserTenantId(): string | undefined;
    private _acquireTokenInternal;
    private _getInteractiveLoginRequest;
}

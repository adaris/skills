/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare function arrayBufferToBase64(buffer: ArrayBuffer): string;
export declare function convertArrayBufferToString(buf: ArrayBuffer): string;
/**
 * Strict encode: encodeURIComponent, but also encode ( and )
 */
export declare function strictEncode(str: string): string;
/**
 * Extracts the Dataverse base URL and encoded path from a full Dataverse API URL.
 * @param url - The full Dataverse API URL (should contain /api/data/v9.0/)
 * @returns An object with baseUrl (up to /api/data/v9.0) and encodedPath (strict encoded path after /api/data/v9.0/)
 */
export declare function extractDataverseUrlParts(url: string): {
    baseUrl: string;
    encodedPath: string;
};
//# sourceMappingURL=utils.d.ts.map
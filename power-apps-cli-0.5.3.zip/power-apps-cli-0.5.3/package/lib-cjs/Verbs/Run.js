"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runAsync = void 0;
var http = __importStar(require("http"));
var fs = __importStar(require("fs"));
var CliSettings_1 = require("../CliSettings");
var CliUtils_1 = require("../CliUtils");
var HelpStrings_1 = require("../Constants/HelpStrings");
function runAsync(argumentProvider) {
    return __awaiter(this, void 0, void 0, function () {
        var settings, appConfig, fileConfig, powerConfigPath, port, appUrl;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    settings = (0, CliSettings_1.getSettings)();
                    appConfig = settings.appConfig, fileConfig = settings.fileConfig;
                    createOptionSchema(argumentProvider, appConfig === null || appConfig === void 0 ? void 0 : appConfig.localAppUrl);
                    return [4 /*yield*/, argumentProvider.runVerb()];
                case 1:
                    _a.sent();
                    if (!appConfig) {
                        throw new Error('power.config.json is required to run an app');
                    }
                    if (!appConfig.environmentId) {
                        throw new Error('Environment ID is required in power.config.json to run an app');
                    }
                    if (!appConfig.region) {
                        appConfig.region = 'prod';
                    }
                    powerConfigPath = fileConfig.powerConfigPath;
                    return [4 /*yield*/, argumentProvider.getOption('port')];
                case 2:
                    port = _a.sent();
                    return [4 /*yield*/, argumentProvider.getOption('localAppUrl')];
                case 3:
                    appUrl = _a.sent();
                    // Start the local server
                    return [4 /*yield*/, startLocalServer(powerConfigPath, parseInt(port, 10), appConfig, appUrl)];
                case 4:
                    // Start the local server
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.runAsync = runAsync;
function startLocalServer(powerConfigPath, port, appConfig, localAppUrl) {
    return __awaiter(this, void 0, void 0, function () {
        var _this = this;
        return __generator(this, function (_a) {
            return [2 /*return*/, new Promise(function (resolve, reject) {
                    var server = http.createServer(function (req, res) {
                        res.setHeader('Access-Control-Allow-Origin', '*');
                        res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
                        res.setHeader('Access-Control-Allow-Headers', '*');
                        if (req.method === 'OPTIONS') {
                            res.writeHead(200);
                            res.end();
                            return;
                        }
                        try {
                            if (!fs.existsSync(powerConfigPath)) {
                                res.writeHead(404, { 'Content-Type': 'application/json' });
                                res.end(JSON.stringify({ error: 'power.config.json not found' }));
                                return;
                            }
                            var fileContent = fs.readFileSync(powerConfigPath, 'utf8');
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.end(fileContent);
                        }
                        catch (error) {
                            console.error('Error serving power.config.json:', error);
                            res.writeHead(500, { 'Content-Type': 'application/json' });
                            res.end(JSON.stringify({ error: 'Internal server error' }));
                        }
                    });
                    server.listen(port, 'localhost', function () { return __awaiter(_this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    console.log("Your power.config.json to setup connections is available at http://localhost:".concat(port));
                                    console.log("\nYou can play your app locally at ".concat((0, CliUtils_1.createPlayUrl)(appConfig.region, appConfig.environmentId, 'local', localAppUrl, "http://localhost:".concat(port))));
                                    // Check if localAppUrl is running
                                    return [4 /*yield*/, checkLocalAppUrl(localAppUrl)];
                                case 1:
                                    // Check if localAppUrl is running
                                    _a.sent();
                                    return [2 /*return*/];
                            }
                        });
                    }); });
                    server.on('error', function (error) {
                        console.error('Server error:', error);
                        reject(error);
                    });
                    process.on('SIGINT', function () {
                        console.log('\nShutting down server...');
                        server.close(function () {
                            console.log('Server stopped');
                            process.exit(0);
                        });
                    });
                })];
        });
    });
}
function createOptionSchema(argumentProvider, localAppUrl) {
    argumentProvider.setDescription(HelpStrings_1.HelpStrings.Verbs.Run.Description);
    argumentProvider.addOptions([
        {
            flags: {
                key: 'port',
                alias: '-p',
            },
            env: 'PORT',
            default: '8080',
            description: HelpStrings_1.HelpStrings.Verbs.Run.Options.Port,
        },
        {
            flags: {
                key: 'localAppUrl',
                alias: '-l',
            },
            env: 'LOCAL_APP_URL',
            default: localAppUrl || 'http://localhost:3000',
            description: HelpStrings_1.HelpStrings.Verbs.Run.Options.LocalAppUrl,
        },
    ]);
}
function checkLocalAppUrl(localAppUrl) {
    return __awaiter(this, void 0, void 0, function () {
        var controller_1, timeoutId, response, error_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    controller_1 = new AbortController();
                    timeoutId = setTimeout(function () { return controller_1.abort(); }, 5000);
                    return [4 /*yield*/, fetch(localAppUrl, {
                            method: 'HEAD',
                            signal: controller_1.signal,
                        })];
                case 1:
                    response = _a.sent();
                    clearTimeout(timeoutId);
                    if (response.ok || response.status < 500) {
                        // No-op
                        return [2 /*return*/];
                    }
                    else {
                        console.warn("\nWarning: Your local app running at ".concat(localAppUrl, " returned status ").concat(response.status, ", which is unexpected. Check your app code for exceptions."));
                    }
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.warn("\nWarning: Your local app is NOT currently running at ".concat(localAppUrl));
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    });
}
//# sourceMappingURL=Run.js.map
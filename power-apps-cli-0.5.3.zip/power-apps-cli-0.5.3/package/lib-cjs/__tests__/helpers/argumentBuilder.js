"use strict";
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildLogoutArgs = exports.buildListCodeAppsArgs = exports.buildListEnvironmentVariablesArgs = exports.buildListConnectionReferencesArgs = exports.buildListSqlStoredProceduresArgs = exports.buildListTablesArgs = exports.buildListDatasetsArgs = exports.buildDeleteDataSourceArgs = exports.buildAddDataSourceArgs = exports.buildInitArgs = void 0;
var VerbConstants_1 = require("../../Verbs/VerbConstants");
/**
 * Convert an argument value object to CLI flag array
 * Uses VerbConstants metadata to map property names to CLI flags
 */
function buildCliArgs(argValues, argDefs) {
    var e_1, _a;
    var args = [];
    var _loop_1 = function (key, value) {
        if (value !== undefined) {
            var argDef = Object.values(argDefs).find(function (def) { return def.name === key; });
            if (argDef) {
                args.push("--".concat(argDef.name), value);
            }
        }
    };
    try {
        for (var _b = __values(Object.entries(argValues)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var _d = __read(_c.value, 2), key = _d[0], value = _d[1];
            _loop_1(key, value);
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return args;
}
/**
 * Build CLI arguments for init verb
 */
function buildInitArgs(args) {
    return buildCliArgs(args, VerbConstants_1.InitArguments);
}
exports.buildInitArgs = buildInitArgs;
/**
 * Build CLI arguments for add-data-source verb
 */
function buildAddDataSourceArgs(args) {
    return buildCliArgs(args, __assign(__assign({}, VerbConstants_1.SharedArguments), VerbConstants_1.AddDataSourceArguments));
}
exports.buildAddDataSourceArgs = buildAddDataSourceArgs;
/**
 * Build CLI arguments for delete-data-source verb
 */
function buildDeleteDataSourceArgs(args) {
    return buildCliArgs(args, __assign(__assign({}, VerbConstants_1.SharedArguments), VerbConstants_1.DeleteDataSourceArguments));
}
exports.buildDeleteDataSourceArgs = buildDeleteDataSourceArgs;
/**
 * Build CLI arguments for list-datasets verb
 */
function buildListDatasetsArgs(args) {
    return buildCliArgs(args, VerbConstants_1.SharedArguments);
}
exports.buildListDatasetsArgs = buildListDatasetsArgs;
/**
 * Build CLI arguments for list-tables verb
 */
function buildListTablesArgs(args) {
    return buildCliArgs(args, VerbConstants_1.SharedArguments);
}
exports.buildListTablesArgs = buildListTablesArgs;
/**
 * Build CLI arguments for list-sql-stored-procedures verb
 */
function buildListSqlStoredProceduresArgs(args) {
    return buildCliArgs(args, VerbConstants_1.SharedArguments);
}
exports.buildListSqlStoredProceduresArgs = buildListSqlStoredProceduresArgs;
/**
 * Build CLI arguments for list-connection-references verb
 */
function buildListConnectionReferencesArgs(args) {
    return buildCliArgs(args, VerbConstants_1.SharedArguments);
}
exports.buildListConnectionReferencesArgs = buildListConnectionReferencesArgs;
/**
 * Build CLI arguments for list-environment-variables verb
 */
function buildListEnvironmentVariablesArgs(args) {
    if (args === void 0) { args = {}; }
    return buildCliArgs(args, VerbConstants_1.SharedArguments);
}
exports.buildListEnvironmentVariablesArgs = buildListEnvironmentVariablesArgs;
/**
 * Build CLI arguments for list-code-apps verb
 */
function buildListCodeAppsArgs(args) {
    if (args === void 0) { args = {}; }
    return [];
}
exports.buildListCodeAppsArgs = buildListCodeAppsArgs;
/**
 * Build CLI arguments for logout verb
 */
function buildLogoutArgs(args) {
    if (args === void 0) { args = {}; }
    return [];
}
exports.buildLogoutArgs = buildLogoutArgs;
/* eslint-enable @typescript-eslint/no-explicit-any */
//# sourceMappingURL=argumentBuilder.js.map
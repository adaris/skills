"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OneDSPropertyStorageOverride = void 0;
/**
 * The property storage override that should be used to store internal SDK properties, otherwise stored as cookies.
 * It is needed where cookies are not available.
 */
var OneDSPropertyStorageOverride = /** @class */ (function () {
    function OneDSPropertyStorageOverride() {
        var _this = this;
        this._storage = new Map();
        this.setProperty = function (key, value) {
            if (!key) {
                return;
            }
            if (value === undefined || value === null) {
                _this._storage.delete(key);
                return;
            }
            _this._storage.set(key, value);
        };
        this.getProperty = function (key) {
            var _a;
            if (!key) {
                return '';
            }
            return (_a = _this._storage.get(key)) !== null && _a !== void 0 ? _a : '';
        };
    }
    return OneDSPropertyStorageOverride;
}());
exports.OneDSPropertyStorageOverride = OneDSPropertyStorageOverride;
//# sourceMappingURL=OneDSPropertyStorageOverride.js.map
/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export {};
//# sourceMappingURL=runtimeMetadataClient.test.d.ts.map
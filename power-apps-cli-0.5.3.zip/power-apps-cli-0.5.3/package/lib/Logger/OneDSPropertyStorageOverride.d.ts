/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IPropertyStorageOverride } from '@microsoft/1ds-analytics-js';
/**
 * The property storage override that should be used to store internal SDK properties, otherwise stored as cookies.
 * It is needed where cookies are not available.
 */
export declare class OneDSPropertyStorageOverride implements IPropertyStorageOverride {
    private _storage;
    setProperty: (key: string, value: string | undefined | null) => void;
    getProperty: (key: string) => string;
}
//# sourceMappingURL=OneDSPropertyStorageOverride.d.ts.map
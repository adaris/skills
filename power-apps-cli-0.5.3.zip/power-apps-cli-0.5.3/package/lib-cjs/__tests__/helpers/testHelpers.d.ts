/// <reference types="node" />
/**
 * Creates a test folder relative to the current working directory.
 *
 * @param {string} folderName
 * @returns {string}
 */
export declare function createTestFolder(folderName: string): string;
/**
 * Cleans up the test folder by removing it and all its contents.
 *
 * @param {string} folderName
 */
export declare function cleanupTestFolder(folderName: string): void;
/**
 * Copies a host template app from source to destination directory.
 *
 * @param {string} source - Source directory path
 * @param {string} destination - Destination directory path
 */
export declare function copyHostTemplateApp(source: string, destination: string): void;
export declare function readJson(filePath: string): Record<string, unknown>;
/**
 * Recursively copies a directory and its contents from source to destination.
 *
 * @param {string} src - Source directory path
 * @param {string} dest - Destination directory path
 */
export declare function copyDirRecursive(src: string, dest: string): void;
/**
 * Validates that generated model and service files exist for a given data source.
 * Generated files follow the pattern: {DataSourceName}Model.ts and {DataSourceName}Service.ts
 * located in the generated/models and generated/services directories respectively.
 *
 * @param {string} projectRoot - Root directory of the test project
 * @param {string} dataSourceName - Name of the data source (will be capitalized for file names)
 * @throws {AssertionError} if files don't exist or have invalid content
 */
export declare function validateGeneratedFiles(projectRoot: string, dataSourceName: string): void;
/**
 * Sets up an E2E test project by creating a temporary directory and copying host template files.
 * Performs CLI and npm availability checks.
 *
 * @param {object} config - Configuration object
 * @param {string} config.cliPath - Path to the CLI entry point
 * @param {string} config.tempBaseDir - Base directory for temporary test folders (e.g., 'C:\\tmp\\...')
 * @param {string} config.testFolderName - Name/prefix for the test folder
 * @param {string} config.hostTemplateFolder - Path to the host template folder to copy to the test folder
 * @returns {string} The path to the created project root directory
 * @throws {Error} if CLI path doesn't exist or npm is not available
 */
export declare function setupE2eTestProject(config: {
    cliPath?: string;
    tempBaseDir: string;
    testFolderName: string;
    hostTemplateFolder: string;
}): string;
/**
 * Cleans up an E2E test project by removing the temporary directory and all its contents.
 *
 * @param {string} projectRoot - Root directory of the test project to clean up
 */
export declare function cleanupE2eTestProject(projectRoot: string): void;
/**
 * Creates a function that executes CLI commands with predefined configuration.
 * Isolates the stdout and stderr for each executor instance.
 *
 * @param {object} options - Configuration options for command execution
 * @param {string} [options.cliPath] - Path to the CLI entry point (defaults to dist/nomodule/powerapps-player-cli.js)
 * @param {string} options.workingDirectory - Working directory for command execution
 * @param {NodeJS.ProcessEnv} [options.envOverrides] - Environment variable overrides
 *
 * @returns {(verb: string, args?: string[]) => CliCommandResult} Command executor function
 */
export declare function createExecuteCodeCommand(options: {
    cliPath?: string;
    workingDirectory: string;
    envOverrides?: NodeJS.ProcessEnv;
}): (verb: string, args?: string[]) => import("./commandLineUtils").CliCommandResult;
/**
 * Creates a command executor that allows CLI command failures without throwing.
 * Useful for testing error scenarios and validating error handling.
 *
 * @param {object} options - Configuration object
 * @param {string} [options.cliPath] - Path to the CLI entry point (defaults to dist/nomodule/powerapps-player-cli.js)
 * @param {string} options.workingDirectory - Working directory for command execution
 * @param {NodeJS.ProcessEnv} [options.envOverrides] - Environment variable overrides
 * @returns {(verb: string, args?: string[]) => CliCommandResultWithExitCode  executor function
 */
export declare function createExecuteCodeCommandAllowFailure(options: {
    cliPath?: string;
    workingDirectory: string;
    envOverrides?: NodeJS.ProcessEnv;
}): (verb: string, args?: string[]) => import("./commandLineUtils").CliCommandResultWithExitCode;
